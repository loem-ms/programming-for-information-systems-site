# Python Basics reference package

Open learning_materials/Python_Basics.ipynb. Keep its programs, data and assets together. For weekly work, download the Week 1 ZIP from the course website.
