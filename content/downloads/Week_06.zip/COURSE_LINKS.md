# Week 6 learning package

[Open the notebook](learning_materials/Week_06.ipynb) · [Setup](SETUP.md) · [Instructor](INSTRUCTOR.md)

Keep the learning_materials folder, its programs, data and assets together. Keep your own saved work and a backup.

[Lesson PDF](slides/Week_06_Slides.pdf) · [Task briefing PDF](assignments/Week_06_Assignments.pdf) · [Python Basics reference](learning_materials/Python_Basics.ipynb)

⚠️ **Khmer text is automatically translated and may contain errors.** Use the English text as a reference and ask the instructor if meaning is unclear.

⚠️ **អត្ថបទខ្មែរបកប្រែដោយស្វ័យប្រវត្តិ ហើយអាចមានកំហុស។** សូមយោងអត្ថបទអង់គ្លេស ហើយសួរគ្រូបើអត្ថន័យមិនច្បាស់។

Course contact and assessed submissions: [submit.progmis@gmail.com](mailto:submit.progmis@gmail.com). Deadlines and exact file names are announced separately. Do not post personal matters or assessed work in shared Issues.

[Weekly reflection and feedback](https://forms.gle/Z3JhR3GHmHDWKxuN7): select the correct teaching week and submit a new response each week. Responses are not anonymous and do not automatically prove attendance.
