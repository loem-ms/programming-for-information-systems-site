"""Start the web page for your own FoodBridge system.

    python run_web.py            # keeps your saved data between runs
    python run_web.py --fresh    # forget saved data and replay the sample day
    python run_web.py --empty    # start with no offers at all

Then open http://localhost:8000 in your browser. Press Ctrl+C to stop.
"""
import sys

from foodbridge.loader import load_my_system
from foodbridge.web import serve


def main():
    system = load_my_system(fresh="--fresh" in sys.argv, empty="--empty" in sys.argv)
    serve(system, port=8000)


if __name__ == "__main__":
    main()
