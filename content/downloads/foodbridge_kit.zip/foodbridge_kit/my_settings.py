"""My decisions.

Remove the # in front of a line, change the value, and save. Every line you
change should also appear in your decision log with your reason.
Defaults and explanations: foodbridge/settings.py
"""

# SYSTEM_NAME = "Campus FoodBridge"
# TEAM_PICKUP_MIN_PORTIONS = 20
# URGENT_HOURS = 3
# SOON_HOURS = 12
# CATEGORIES = ["bread", "rice meals", "fruit", "vegetables", "snacks"]
# PARTNERS = ["Hope Children's Centre", "Riverside Community Kitchen", "Old Market Elders' Group"]
# REQUIRED_FIELDS = ["donor", "food", "category", "portions", "hours_left"]
# MIN_PORTIONS = 1
# MAX_PORTIONS = 200
# REJECT_IF_HOURS_LEFT_BELOW = 1
# REQUIRE_APPROVAL = True
# LOG_EVENTS = ["added", "input_rejected", "moved"]
# PUBLIC_FIELDS = ["id", "food", "category", "portions", "status"]
# REPORT_SORT = "urgency"
# LANGUAGE = "en"
