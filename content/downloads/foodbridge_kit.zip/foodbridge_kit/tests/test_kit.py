"""Tests for the FoodBridge kit. Run them all with:  python run_tests.py

Each test checks one behaviour with assert. Normal cases, boundary cases
and refusals are all tested, because a system is only as trustworthy as
its worst case.
"""
import contextlib
import io
import os
import tempfile

import foodbridge as bridge
from foodbridge import models, records, reports, rules, storage, validation


def test_pickup_label_boundaries():
    assert rules.pickup_label(19, True) == "standard"
    assert rules.pickup_label(20, True) == "team"
    assert rules.pickup_label(21, True) == "team"
    assert rules.pickup_label(20, False) == "hold"


def test_urgency_boundaries():
    assert rules.urgency(3) == "urgent"
    assert rules.urgency(4) == "soon"
    assert rules.urgency(12) == "soon"
    assert rules.urgency(13) == "later"


def test_records_helpers():
    sample = bridge.sample_records()
    assert records.total_portions(sample) == 100
    assert records.find_offer(sample, "F003")["food"] == "Bananas"
    assert records.find_offer(sample, "F999") is None
    assert records.next_id(sample) == "F005"
    assert records.next_id([]) == "F001"
    assert records.portions_by_category(sample)["rice meals"] == 30


def test_clean_offer_accepts_and_tidies_a_good_row():
    raw = {"donor": " Sunrise Bakery ", "food": "Bread", "category": "Bread ",
           "portions": " 30", "hours_left": "5"}
    offer, errors = validation.clean_offer(raw, bridge.make_settings())
    assert errors == []
    assert offer["donor"] == "Sunrise Bakery"
    assert offer["category"] == "bread"
    assert offer["portions"] == 30


def test_clean_offer_refuses_bad_rows_with_messages():
    settings = bridge.make_settings()
    good = {"donor": "A", "food": "B", "category": "bread", "portions": "5", "hours_left": "5"}
    for field, value in [("portions", "many"), ("portions", "0"), ("portions", "201"),
                         ("hours_left", "0"), ("category", "soup"), ("donor", " ")]:
        row = dict(good)
        row[field] = value
        offer, errors = validation.clean_offer(row, settings)
        assert offer is None and errors, (field, value)


def test_lifecycle_moves():
    assert models.can_move("new", "approved")
    assert not models.can_move("new", "delivered")
    assert not models.can_move("delivered", "new")
    assert models.can_move("new", "picked_up", models.allowed_moves(False))


def test_record_round_trip():
    offer = models.Offer("F001", "Donor", "Rice", "rice meals", 10, 4, "x@example.org")
    offer.status, offer.partner = "approved", "Hope Children's Centre"
    again = models.from_record(offer.to_record())
    assert again.to_record() == offer.to_record()


def test_safe_save_and_history():
    with tempfile.TemporaryDirectory() as folder:
        path = os.path.join(folder, "offers.json")
        storage.save_records([{"id": "F001"}], path)
        assert storage.load_records(path) == [{"id": "F001"}]
        assert not os.path.exists(path + ".tmp")
        log = os.path.join(folder, "history.jsonl")
        storage.append_event(log, {"step": 1})
        storage.append_event(log, {"step": 2})
        assert [e["step"] for e in storage.read_events(log)] == [1, 2]


def test_sample_day_numbers():
    system = bridge.System(quiet=True)
    numbers = system.run_day(show=False)
    assert numbers["portions_offered"] == 100
    assert numbers["portions_delivered"] == 18
    assert numbers["inputs_refused"] == 5


def test_refusals_change_nothing():
    system = bridge.System(quiet=True)
    system.run_day(show=False)
    before = system.records()
    assert system.move("F004", "delivered")[0] is False
    assert system.move("F999", "approved")[0] is False
    assert system.add_offer({"donor": "X", "food": "Y", "category": "bread",
                             "portions": "-3", "hours_left": "4"})[0] is None
    assert system.records() == before


def test_public_board_hides_contacts():
    system = bridge.System(quiet=True)
    system.run_day(show=False)
    public = system.report("public")
    assert "@example.org" not in public
    assert "@example.org" in system.report("coordinator")


def test_broken_hook_falls_back_to_default():
    def broken(portions, approved):
        return portions / 0
    system = bridge.System(hooks={"pickup_label": broken}, quiet=True)
    system.run_day(show=False)
    report = system.report()
    assert "pickup_label" in system.fallbacks
    assert "team" in report and "ZeroDivisionError" in system.fallbacks["pickup_label"]


def test_custom_settings_change_the_rule():
    system = bridge.System({"TEAM_PICKUP_MIN_PORTIONS": 35}, quiet=True)
    system.run_day(show=False)
    assert system.label(system.get("F001")) == "standard"


def test_persistence_between_runs():
    with tempfile.TemporaryDirectory() as folder:
        first = bridge.System(data_dir=folder, quiet=True)
        first.run_day(show=False)
        second = bridge.System(data_dir=folder, quiet=True)
        assert second.records() == first.records()
        assert len(second.history) == len(first.history)


def test_text_menu_with_script():
    system = bridge.System(quiet=True)
    system.run_day(show=False)
    bridge.run_menu(system, script=["6", "F004", "picked_up", "", "q"])
    assert system.get("F004").status == "picked_up"


def test_kit_verify_passes():
    assert bridge.System(quiet=True).verify(show=False) is True


def test_report_sorting():
    sample = bridge.sample_records()
    assert [r["id"] for r in reports.sort_records(sample, "urgency")] == ["F002", "F004", "F001", "F003"]
    assert [r["id"] for r in reports.sort_records(sample, "portions")][0] == "F003"


def test_midterm_checks_follow_the_constant():
    def volunteers_needed(portions):
        return (portions + 9) // 10
    assert bridge.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 10})
    assert not bridge.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 15})


def test_midterm_catch_bugs_counts_caught_bugs():
    namespace = {"PORTIONS_PER_VOLUNTEER": 15}
    code = (
        "def volunteers_needed(portions):\n"
        "    return (portions + PORTIONS_PER_VOLUNTEER - 1) // PORTIONS_PER_VOLUNTEER\n"
        "def plan_day(offers):\n"
        "    approved = [o for o in offers if o['approved']]\n"
        "    return {'offers': len(offers), 'approved_portions': sum(o['portions'] for o in approved),\n"
        "            'volunteers': sum(volunteers_needed(o['portions']) for o in approved),\n"
        "            'waiting': [o['id'] for o in offers if not o['approved']]}\n"
        "def test_boundary():\n"
        "    assert volunteers_needed(PORTIONS_PER_VOLUNTEER) == 1\n"
        "    assert volunteers_needed(PORTIONS_PER_VOLUNTEER + 1) == 2\n"
        "def test_nothing():\n"
        "    pass\n")
    exec(code, namespace)
    assert bridge.check("plan_day", namespace["plan_day"])
    assert bridge.catch_bugs([namespace["test_boundary"]]) == 2
    assert bridge.catch_bugs([namespace["test_nothing"]]) == 0


BONUS_WORDS = ["old"]


def _mentions_old(food):
    return any(word in food.lower() for word in BONUS_WORDS)


def _strict_clean_offer(raw):
    offer, errors = validation.clean_offer(raw, bridge.make_settings({}, quiet=True))
    if _mentions_old(raw.get("food", "")):
        errors.append("old food")
    return (None if errors else offer), errors


def test_export_copies_helpers_constants_and_imports():
    text = bridge.export.rules_file_text({"clean_offer": _strict_clean_offer})
    assert "def _mentions_old(food):" in text
    assert "BONUS_WORDS = ['old']" in text
    assert "from foodbridge import validation" in text
    namespace = {}
    exec(text, namespace)
    offer, errors = namespace["clean_offer"]({"donor": "A", "contact": "a@x.org", "food": "Old bread",
                                              "category": "bread", "portions": "10", "hours_left": "5"})
    assert offer is None and errors == ["old food"]


def test_khmer_screens_keep_english_codes():
    s = bridge.System({"LANGUAGE": "km"}, quiet=True)
    s.run_day(show=False)
    assert "ស្ថានភាព" in s.report("public")              # the heading "status" in Khmer
    assert s.get("F002").status == "delivered"             # the stored code stays English
    offer_id, errors = s.add_offer({"donor": "A", "contact": "a@x.org", "food": "Rice",
                                    "category": "rice meals", "portions": "many", "hours_left": "5"})
    assert offer_id is None and "portions" in errors[0] and "ចំនួនគត់" in errors[0]
    assert "public board" in bridge.System(quiet=True).report("public")  # English is unchanged


def test_khmer_history_stores_english_codes_and_shows_khmer_words():
    import html
    from foodbridge import messages, web
    from foodbridge.parts import inspect_folder
    from foodbridge.show import view_history

    def km(code):                                   # the Khmer screen word for a code
        return messages.word(code, "km")

    def km_for(partner):
        return messages.t(" for {partner}", "km", partner=partner)

    row = {"donor": "Cafe A", "contact": "a@example.org", "food": "Rice", "category": "rice meals",
           "portions": "12", "hours_left": "5"}
    odd, note = "North -> South for Kids", "late -> early for rain"     # " -> " and " for " inside the text
    with tempfile.TemporaryDirectory() as folder:
        s = bridge.System({"LANGUAGE": "km", "PARTNERS": [odd]}, data_dir=folder, quiet=True)
        s.add_offer(row)
        ok, message = s.move("F001", "approved", odd, note)
        stored = "new -> approved for " + odd + " (" + note + ")"         # codes and "for": the same in both editions
        screen = km("new") + " -> " + km("approved") + km_for(odd + " (" + note + ")")
        assert km("approved") != "approved" and km_for("X") != " for X"   # the screen really is Khmer
        assert ok and message == "F001: " + screen
        assert s.history[-1]["detail"] == stored
        log = os.path.join(folder, "history.jsonl")
        assert storage.read_events(log)[-1]["detail"] == stored
        assert s.history_text(1) == "#2 " + km("moved") + " F001 " + screen
        page = web.history_page(s)
        assert "<td>" + html.escape(km("moved")) + "</td><td>F001</td><td>" + html.escape(screen) + "</td>" in page
        # a line written by the old kit (2026.11.7) with Khmer words still shows as it was
        old = km("new") + " -> " + km("approved") + km_for("Hope")
        storage.append_event(log, {"step": 3, "event": "moved", "offer": "F001", "detail": old, "time": ""})
        again = bridge.System({"LANGUAGE": "km", "PARTNERS": [odd]}, data_dir=folder, quiet=True)
        assert again.history_text(1) == "#3 " + km("moved") + " F001 " + old
    # English: the message and the stored detail are unchanged
    english = bridge.System(quiet=True)
    english.add_offer(row)
    partner = english.settings["PARTNERS"][0]
    ok, message = english.move("F001", "approved", partner, note)
    assert ok and message == "F001: new -> approved for " + partner + " (" + note + ")"
    assert english.history[-1]["detail"] == "new -> approved for " + partner + " (" + note + ")"
    assert english.history_text(1) == "#2 moved F001 new -> approved for " + partner + " (" + note + ")"
    # show("history") in Khmer: the HTML and the text timeline of the saved sample day
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    try:
        bridge.set_language("km")
        page, text = view_history(inspect_folder(folder))
        _, printed = _quiet(bridge.show, "history", folder=folder)
    finally:
        bridge.set_language("en")
    approved = km("new") + " -> " + km("approved") + km_for(bridge.DEFAULTS["PARTNERS"][0])     # step 11: F001
    picked_up = km("approved") + " -> " + km("picked_up")                                       # step 16: F001
    for step, detail in [(11, approved), (16, picked_up)]:
        line = "     ➡️ #" + str(step) + " " + km("moved") + " F001 " + detail
        assert line in text.splitlines() and line in printed.splitlines()
        assert ("<b>#" + str(step) + "</b> " + html.escape(km("moved")) + ' F001 <span style="color:#5f6b76">'
                + html.escape(detail) + "</span></div>") in page


def _write(folder, name, text):
    with open(os.path.join(folder, name), "w", encoding="utf-8") as file:
        file.write(text)


def test_folder_reads_settings_functions_and_typos():
    from foodbridge import folder as parts
    folder = tempfile.mkdtemp()
    _write(folder, "data_model.py", "MIN_PORTIONS = 2\nMIN_PORTION = 3\nRICE_HOURS = 4\n\n"
                                    "def tidy(text):\n    return text.strip()\n\n"
                                    "def clean_offer(raw):\n    return None, ['no']\n")
    found = parts.load_folder(folder)
    assert found["settings"] == {"MIN_PORTIONS": 2}
    assert sorted(found["functions"]) == ["clean_offer", "tidy"]
    assert len(found["problems"]) == 1 and "MIN_PORTION " in found["problems"][0]   # a typo, not RICE_HOURS
    system = bridge.System.from_folder(folder, quiet=True)
    assert system.settings["MIN_PORTIONS"] == 2
    # this clean_offer refuses every row, so it fails its check: the model version is used instead
    assert list(system.custom_hooks()) == []
    assert [p["state"] for p in system.folder["parts"] if p["name"] == "clean_offer"] == ["needs_work"]


def test_folder_check_uses_the_files():
    folder = tempfile.mkdtemp()
    _write(folder, "data_model.py", "def clean_offer(raw):\n    return None, ['no']\n")
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        assert bridge.check("clean_offer", folder=folder) is False      # it refuses the good row
        _write(folder, "data_model.py", "from foodbridge import validation, DEFAULTS\n"
                                        "def clean_offer(raw):\n    return validation.clean_offer(raw, DEFAULTS)\n")
        assert bridge.check("clean_offer", folder=folder) is True
        assert bridge.check("urgency", folder=folder) is False          # not in the folder
    assert "No function called urgency" in printed.getvalue()


def test_a_broken_file_is_reported_never_raised():
    folder = tempfile.mkdtemp()
    _write(folder, "data_model.py", "def clean_offer(raw)\n    return None, []\n")
    _write(folder, "rules.py", "x = 1 / 0\n")
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        bridge.my_folder(folder)
        bridge.try_part("clean_offer", {}, folder=folder)
        bridge.System.from_folder(folder).run_day(show=False)
    text = printed.getvalue()
    assert "data_model.py, line 1" in text and "rules.py, line 1: ZeroDivisionError" in text


def test_try_part_shows_the_answer():
    folder = tempfile.mkdtemp()
    _write(folder, "rules.py", "def urgency(hours_left):\n    print('hi')\n    return 'urgent'\n")
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        bridge.try_part("urgency", 2, folder=folder)
    assert "urgency(2)" in printed.getvalue() and "→ 'urgent'" in printed.getvalue()
    assert "printed: hi" in printed.getvalue()


def test_parsons_prints_shuffled_lines_outside_a_notebook():
    from foodbridge import puzzles
    for name, puzzle in puzzles.PUZZLES.items():
        order = puzzles._shuffled(name, puzzle)
        keys = [key for key, _ in order if key != "wrong"]
        assert sorted(keys) == sorted(str(i) for i in range(len(puzzle["lines"])))
        assert keys != [str(i) for i in range(len(puzzle["lines"]))]   # never already solved
        assert "</script" not in puzzles._html(puzzle, order).split("<script>")[1].rsplit("</script>", 1)[0]
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        bridge.parsons("category_check")
        bridge.parsons("category_chek")
    assert "H │" in printed.getvalue() and "Did you mean 'category_check'" in printed.getvalue()


def test_week_1_to_3_puzzles_load_and_print():
    from foodbridge import puzzles
    found = puzzles.all_puzzles()
    for name, last_line in [("share_portions", 'print(f"{each} portions each, {left_over} left over")'),
                            ("pickup_rule", '    return "standard"'),
                            ("find_by_id", "    return None")]:
        assert name in found, name
        puzzle = found[name]
        assert puzzle["lines"][-1] == last_line and puzzle["wrong"] not in puzzle["lines"]
        order = puzzles._shuffled(name, puzzle)
        assert [key for key, _ in order if key != "wrong"] != [str(i) for i in range(len(puzzle["lines"]))]
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            bridge.parsons(name)
        text = printed.getvalue()
        assert puzzle["title"] in text and puzzle["wrong"].strip() in text, name
        assert "❌" not in text and "Traceback" not in text, name


# ---- Weeks 4–10: the student's folder ------------------------------------------
MODEL_FILES = os.path.join(os.path.dirname(bridge.__file__), "model_files")


def _quiet(function, *args, **kwargs):
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        result = function(*args, **kwargs)
    return result, printed.getvalue()


def test_every_model_file_passes_its_checks():
    import shutil
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    shutil.copytree(MODEL_FILES, folder)
    ok, printed = _quiet(bridge.check, "all", folder=folder)
    assert ok, printed
    assert "15 of 15 parts are yours" in printed and "❌" not in printed


def test_model_tests_follow_the_settings_not_raw_numbers():
    import shutil
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    shutil.copytree(MODEL_FILES, folder)
    rules_text = open(os.path.join(folder, "rules.py"), encoding="utf-8").read()
    _write(folder, "rules.py", rules_text.replace("TEAM_PICKUP_MIN_PORTIONS = 20", "TEAM_PICKUP_MIN_PORTIONS = 25")
                                         .replace("URGENT_HOURS = 3", "URGENT_HOURS = 4"))
    door_text = open(os.path.join(folder, "data_model.py"), encoding="utf-8").read()
    # without "rice meals", the door test's row gets a second message: the test must still pass
    _write(folder, "data_model.py", door_text.replace('"bread", "rice meals", ', '"bread", '))
    ok, printed = _quiet(bridge.check, "all", folder=folder)
    assert ok, printed
    assert "❌" not in printed


def test_model_door_message_says_hours_left_in_words():
    import shutil
    from foodbridge import folder as parts
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    shutil.copytree(MODEL_FILES, folder)
    clean_offer = parts.load_folder(folder)["functions"]["clean_offer"][0]
    offer, errors = clean_offer({"donor": "A", "food": "Rice", "category": "rice meals",
                                 "portions": "10", "hours_left": "soon"})
    assert offer is None and errors == ["hours left must be a whole number."]


def test_every_view_runs_on_an_empty_folder_without_a_cross():
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    for view in ["map", "sheet", "lifecycle", "history", "board", "app", "gallery", "screen"]:
        _, printed = _quiet(bridge.show, view, folder=folder)
        assert printed.strip() and "❌" not in printed, view
    _, printed = _quiet(bridge.show, "lifecycle", folder=folder, status="approved")
    assert "picked_up, cancelled" in printed


def test_a_failing_part_is_replaced_by_the_model_version():
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    os.makedirs(folder)
    _write(folder, "records.py", "def open_portions(records):\n    return 0\n\n"
                                 "def total_portions(records):\n    return sum(r['portions'] for r in records)\n")
    system = bridge.System.from_folder(folder, quiet=True)
    assert "total_portions" in system.custom_hooks() and "open_portions" not in system.custom_hooks()
    system.run_day(show=False)
    assert system.numbers()["portions_open"] == 42
    _, printed = _quiet(bridge.show, folder=folder)
    assert "🔧 open_portions" in printed and "✅ total_portions" in printed


def test_fill_gaps_copies_only_missing_files_and_marks_them():
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    os.makedirs(folder)
    _write(folder, "rules.py", "TEAM_PICKUP_MIN_PORTIONS = 25\n\ndef pickup_label(p, a):\n"
                               "    return 'hold' if not a else 'team' if p >= 25 else 'standard'\n")
    _quiet(bridge.show, folder=folder, fill_gaps=True)
    assert open(os.path.join(folder, "rules.py")).read().startswith("TEAM_PICKUP")       # never overwritten
    assert open(os.path.join(folder, "storage.py")).read().startswith("# 📦")
    _, printed = _quiet(bridge.show, folder=folder)
    assert "✅ pickup_label" in printed and "📦 save_records" in printed
    assert "TEAM_PICKUP_MIN_PORTIONS = 25" in printed                                     # a decision


def test_app_imports_the_other_files_freshly():
    import shutil
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    shutil.copytree(MODEL_FILES, folder)
    _, printed = _quiet(bridge.show, "app", folder=folder, script=["2", "q"])
    assert "Portions offered: 100" in printed
    _write(folder, "records.py", open(os.path.join(MODEL_FILES, "records.py")).read().replace(
        "return total\n\n\ndef find_offer", "return total + 1\n\n\ndef find_offer"))
    _, printed = _quiet(bridge.show, "app", folder=folder, script=["2", "q"])
    assert "Portions offered: 101" in printed            # the new records.py, not a cached copy


def test_check_with_examples_never_raises():
    def area(width, height):
        print(width * height)
    ok, printed = _quiet(bridge.check, "area", area, examples=[((2, 3), 6)])
    assert ok is False and "printed but returned None" in printed
    ok, _ = _quiet(bridge.check, "shout", lambda word: word.upper() + "!", examples=[("hi", "HI!"), ("ok", "OK!")])
    assert ok is True
    ok, printed = _quiet(bridge.check, "boom", lambda word: 1 / 0, examples=[("x", 1)])
    assert ok is False and "ZeroDivisionError" in printed


def test_storage_checks_catch_append_instead_of_write():
    import json

    def save_by_appending(records, path):
        with open(path, "a") as file:
            json.dump(records, file)
    ok, printed = _quiet(bridge.check, "save_records", save_by_appending)
    assert ok is False and '"a" (append)' in printed


def test_lifecycle_view_marks_unusual_missing_and_added_moves():
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    os.makedirs(folder)
    _write(folder, "lifecycle.py", "ALLOWED_MOVES = {'new': ['approved', 'rejected'], 'approved': ['picked_up', 'reserved'],"
                                   " 'reserved': ['picked_up'], 'delivered': ['new']}\n"
                                   "def can_move(old, new):\n    return new in ALLOWED_MOVES.get(old, [])\n")
    _, printed = _quiet(bridge.show, "lifecycle", folder=folder)
    assert "Unusual: delivered → new" in printed and "Missing: picked_up → delivered" in printed
    assert "Your new state: approved → reserved" in printed


def test_menu_check_needs_the_public_board_rows():
    from foodbridge.parts import model_handle_choice

    def full(choice, records):
        return model_handle_choice(choice, records)

    def no_board(choice, records):
        return "not done yet" if choice == "3" else model_handle_choice(choice, records)
    assert _quiet(bridge.check, "handle_choice", full)[0] is True
    ok, printed = _quiet(bridge.check, "handle_choice", no_board)
    assert ok is False and "3/4" in printed


def test_example_checks_show_function_names_not_addresses():
    def fare_ok(age):
        return 1000

    def verdict(version):
        return "pass"
    ok, printed = _quiet(bridge.check, "verdict", verdict, examples=[(fare_ok, "pass")])
    assert ok is True and "fare_ok" in printed and "0x" not in printed


def test_check_all_uses_default_folder():
    import shutil
    with tempfile.TemporaryDirectory() as root:
        shutil.copytree(MODEL_FILES, os.path.join(root, "my_foodbridge"))
        here = os.getcwd()
        os.chdir(root)
        try:
            ok, printed = _quiet(bridge.check, "all")
        finally:
            os.chdir(here)
    assert ok is True and "15 of 15 parts are yours" in printed


def test_can_move_check_catches_unknown_old_status():
    def unsafe_can_move(old_status, new_status):
        return new_status in bridge.ALLOWED_MOVES[old_status]
    ok, printed = _quiet(bridge.check, "can_move", unsafe_can_move)
    assert ok is False and "KeyError" in printed


def test_show_views_report_broken_file_problems_and_gallery_includes_screen():
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "screen.py", "def make_page(records):\n    return (\n")
        _, printed = _quiet(bridge.show, "screen", folder=folder)
        assert "screen.py, line" in printed
        _write(folder, "screen.py", "def make_page(records):\n    return '<p>Hello screen</p>'\n")
        _, gallery = _quiet(bridge.show, "gallery", folder=folder)
        assert "Hello screen" in gallery


def test_show_screen_without_make_page_names_the_final_extension():
    from foodbridge import messages
    with tempfile.TemporaryDirectory() as folder:
        _, printed = _quiet(bridge.show, "screen", folder=folder)
    assert "a Final extension option" in printed and "Level 4" not in printed
    khmer = messages.t("No make_page(records) yet. It goes in {folder}/screen.py (a Final extension option).",
                       language="km", folder="my_foodbridge")
    assert "extension" in khmer and "កម្រិតទី 4" not in khmer and "my_foodbridge/screen.py" in khmer


def test_board_view_includes_category_in_hidden_fields():
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "report.py",
               "PUBLIC_FIELDS = ['food', 'portions', 'status']\n"
               "def public_row(record):\n    return {k: record[k] for k in PUBLIC_FIELDS}\n")
        _, printed = _quiet(bridge.show, "board", folder=folder)
        assert "Hidden from the public:" in printed and "category" in printed.split("Hidden from the public:")[1]


def test_lazy_import_inside_folder_function_works():
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "rules.py", "URGENT_HOURS = 5\n")
        _write(folder, "screen.py",
               "def make_page(records):\n    import rules\n    return '<p>Urgent=' + str(rules.URGENT_HOURS) + '</p>'\n")
        _, printed = _quiet(bridge.show, "screen", folder=folder)
        assert "Urgent=5" in printed


def test_link_to_target_preserves_subfolders_and_replaces_broken_symlink():
    from foodbridge import folder as folder_mod
    with tempfile.TemporaryDirectory() as root:
        local = os.path.join(root, "my_foodbridge")
        target = os.path.join(root, "drive_foodbridge")
        os.makedirs(os.path.join(local, "saved"))
        _write(os.path.join(local, "saved"), "offers.json", "[]")
        folder_mod._link_to_target(local, target)
        assert os.path.islink(local)
        assert os.path.exists(os.path.join(target, "saved", "offers.json"))
        # broken symlink is replaced cleanly
        broken = os.path.join(root, "broken_link")
        os.symlink(os.path.join(root, "does_not_exist"), broken)
        folder_mod._link_to_target(broken, target)
        assert os.path.islink(broken) and os.path.realpath(broken) == os.path.realpath(target)


def test_changed_settings_deduplicates_imports_and_skips_system_name():
    from foodbridge import parts
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "rules.py", "URGENT_HOURS = 6\nSYSTEM_NAME = 'My Bridge'\n")
        _write(folder, "app.py", "from rules import URGENT_HOURS\n")
        found = parts.inspect_folder(folder)
        assert parts.changed_settings(found) == [("URGENT_HOURS", 6, 3, "rules.py")]


def test_web_pages_follow_order_and_start_web_from_folder():
    import urllib.request
    from foodbridge import web
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "rules.py", "URGENT_HOURS = 6\n")
        try:
            _quiet(bridge.start_web, folder=folder, port=18910)
            port = web._running["server"].server_address[1]
            body = urllib.request.urlopen("http://127.0.0.1:" + str(port) + "/").read().decode("utf-8")
            public = urllib.request.urlopen("http://127.0.0.1:" + str(port) + "/public").read().decode("utf-8")
        finally:
            bridge.stop_web()
        assert body.index("F004") < body.index("F001")
        assert public.index("Fried rice boxes") < public.index("Vegetable curry with rice") < public.index("Bread rolls")


def test_start_web_says_which_parts_are_yours_and_which_are_model():
    import urllib.request
    from foodbridge import web
    with tempfile.TemporaryDirectory() as folder:
        _write(folder, "rules.py",
               "TEAM_PICKUP_MIN_PORTIONS = 20\nURGENT_HOURS = 3\nSOON_HOURS = 12\n"
               "def pickup_label(portions, approved):\n"
               "    if not approved:\n        return 'hold'\n"
               "    return 'team' if portions >= TEAM_PICKUP_MIN_PORTIONS else 'standard'\n"
               "def urgency(hours_left):\n"
               "    if hours_left <= URGENT_HOURS:\n        return 'urgent'\n"
               "    return 'soon' if hours_left <= SOON_HOURS else 'later'\n")
        _write(folder, "data_model.py", "def clean_offer(raw):\n    return None, ['not done yet']\n")
        try:
            _, printed = _quiet(bridge.start_web, folder=folder, port=18920)
            port = web._running["server"].server_address[1]
            body = urllib.request.urlopen("http://127.0.0.1:" + str(port) + "/").read().decode("utf-8")
        finally:
            bridge.stop_web()
        for text in (printed, body):
            assert "rules.py ✅" in text and "data_model.py 🔧" in text and "records.py ⬜" in text
        assert web.parts_line(bridge.System(quiet=True)) == ""    # not built from a folder: no line


def test_midterm_v2_library_checks_and_bug_catcher():
    namespace = {"MAX_LATE_DAYS": 7, "MAX_RENEWALS": 2}
    code = (
        "def loan_action(days_late, is_reserved, renewals):\n"
        "    if days_late < 0 or renewals < 0:\n"
        "        return None\n"
        "    if is_reserved and days_late >= 1:\n"
        "        return 'recall_now'\n"
        "    if days_late >= MAX_LATE_DAYS or renewals >= MAX_RENEWALS:\n"
        "        return 'return_only'\n"
        "    return 'allow_renew'\n"
        "def desk_summary(loans):\n"
        "    still_out, recall_ids, returned_ids = 0, [], []\n"
        "    for loan in loans:\n"
        "        if loan['returned']:\n"
        "            returned_ids.append(loan['id'])\n"
        "        else:\n"
        "            still_out += 1\n"
        "            if loan_action(loan['days_late'], loan['is_reserved'], loan['renewals']) == 'recall_now':\n"
        "                recall_ids.append(loan['id'])\n"
        "    return {'still_out': still_out, 'recall_ids': recall_ids, 'returned_ids': returned_ids}\n"
        "def test_short_overdue_and_empty():\n"
        "    loans = [{'id': 'B10', 'title': 'Networks', 'days_late': 2, 'returned': False}]\n"
        "    assert most_overdue_id(loans) == 'B10'\n"
        "    assert most_overdue_id([]) is None\n"
        "def test_missing_returned_and_id():\n"
        "    loans = [{'id': 'B11', 'title': 'Databases', 'days_late': 4}]\n"
        "    assert most_overdue_id(loans) == 'B11'\n"
        "def most_overdue_id(loans):\n"
        "    worst_id, worst_days = None, 0\n"
        "    for loan in loans:\n"
        "        if not loan.get('returned', False):\n"
        "            if loan['days_late'] > worst_days:\n"
        "                worst_days = loan['days_late']\n"
        "                worst_id = loan['id']\n"
        "    return worst_id\n")
    exec(code, namespace)
    assert _quiet(bridge.check, "loan_action", namespace["loan_action"],
                  {"MAX_LATE_DAYS": 7, "MAX_RENEWALS": 2})[0]
    assert _quiet(bridge.check, "desk_summary", namespace["desk_summary"],
                  {"MAX_LATE_DAYS": 7, "MAX_RENEWALS": 2})[0]
    assert _quiet(bridge.check, "most_overdue_id", namespace["most_overdue_id"])[0]
    assert _quiet(bridge.catch_library_bugs,
                  [namespace["test_short_overdue_and_empty"], namespace["test_missing_returned_and_id"]])[0] == 3
    assert _quiet(bridge.catch_library_bugs,
                  [namespace["test_short_overdue_and_empty"], namespace["test_missing_returned_and_id"]],
                  check_yours=True)[0] == 2
    # desk_summary still passes even when student's loan_action is broken (no double penalty)
    namespace["loan_action"] = lambda d, r, n: "wrong"
    assert _quiet(bridge.check, "desk_summary", namespace["desk_summary"],
                  {"MAX_LATE_DAYS": 7, "MAX_RENEWALS": 2})[0]


def test_runner_scripts_do_not_interfere_with_folder_checks():
    from foodbridge.folder import load_folder
    folder = os.path.join(tempfile.mkdtemp(), "my_foodbridge")
    os.makedirs(folder)
    # Even before rules.py exists, run_rules.py must not cause import errors or hang on input()
    _write(folder, "run_rules.py",
           "from rules import pickup_label, urgency\n"
           "def main():\n    input('Portions? ')\n"
           "if __name__ == '__main__':\n    main()\n")
    found = load_folder(folder)
    assert found["files"] == [] and found["problems"] == []
    _, printed = _quiet(bridge.show, folder=folder)
    assert "⚠️" not in printed and "❌" not in printed


def test_khmer_event_words_read_as_past_events():
    # The history timeline's event names read like the status words (បានអនុម័ត …): past or passive, all Khmer.
    from foodbridge import messages
    for code in ("added", "input_rejected", "moved"):
        word = messages.word(code, "km")
        assert word.startswith("បាន") or "ត្រូវបាន" in word, (code, word)
        assert not any("a" <= ch.lower() <= "z" for ch in word), (code, word)
