"""bridge.show(): see your system (Weeks 4–10). You do not need to read this file.

    bridge.show()                 the map: which parts of the system are yours
    bridge.show("sheet")          Week 5: the sample rows through your clean_offer
    bridge.show("lifecycle")      Week 6: the state diagram drawn from your can_move
    bridge.show("history")        Week 7: the sample day saved with your storage.py
    bridge.show("board")          Week 8: the coordinator view and the public board
    bridge.show("app")            Week 9: your menu, run with a script
    bridge.show("gallery")        Week 10: everything on one page
    bridge.show("screen")         the page your screen.py makes (a Final extension option)

In Colab or Jupyter you see coloured pictures; anywhere else, plain text.
Every picture is driven by YOUR files. A part that is missing or does not
pass its check yet is replaced by the kit's model version, and the picture
says so.
"""
import html
import json
import os

from . import models, records, reports, validation
from .check import sample_records
from .folder import FOLDER
from .messages import t, word
from .parts import FILES, PARTS, changed_settings, fill_gaps as copy_missing, inspect_folder, model_handle_choice, part
from .settings import make_settings

SAMPLE_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "offers.csv")
STATUSES = ["new", "approved", "picked_up", "delivered", "rejected", "cancelled"]
VIEWS = ["map", "sheet", "lifecycle", "history", "board", "app", "gallery", "screen"]

INK, MUTED, LINE = "#1f2933", "#5f6b76", "#d6dde4"
LOOK = {"yours": ("#e7f5ec", "#1e6b3a", "✅"), "needs_work": ("#fff4e0", "#8a5300", "🔧"),
        "missing": ("#f3f5f7", "#5f6b76", "⬜"), "copied": ("#eaf2fb", "#2f6f9f", "📦")}
BOX = ("font-family:system-ui,-apple-system,'Segoe UI',sans-serif;color:#1f2933;background:#ffffff;"
       "border:1px solid #d6dde4;border-radius:10px;padding:14px 16px;max-width:1040px;line-height:1.45;"
       "overflow-x:auto;margin:6px 0")
TABLE = "border-collapse:collapse;font-size:13px;margin:6px 0"
CELL = "border:1px solid #d6dde4;padding:4px 8px;text-align:left;vertical-align:top"


def show(view="map", folder=FOLDER, status=None, script=None, fill_gaps=False):
    """Show one picture of your system. view is one of: map, sheet, lifecycle, history, board, app, gallery, screen.

    fill_gaps=True first copies the model version of any missing Week 4–8 file (marked 📦), so app.py can import it.
    """
    if fill_gaps:
        copy_missing(folder)
    if view not in VIEWS:
        import difflib
        close = difflib.get_close_matches(str(view), VIEWS, n=1)
        print("⚠️ " + t("There is no view called {view}. Views: {views}.", view=repr(view), views=", ".join(VIEWS)) +
              (t(" Did you mean {close}?", close=repr(close[0])) if close else ""))
        return
    found = inspect_folder(folder)
    if view == "gallery":
        sub = dict(found, problems=[])
        pieces = [VIEW_FUNCTIONS["map"](found, status, script)]
        pieces += [VIEW_FUNCTIONS[name](sub, status, script) for name in ("sheet", "lifecycle", "history", "board")]
        if part(found, "handle_choice")["function"] is not None:
            pieces.append(VIEW_FUNCTIONS["app"](sub, status, script))
        if found["functions"].get("make_page") is not None:
            pieces.append(VIEW_FUNCTIONS["screen"](sub, status, script))
        _display("".join(piece[0] for piece in pieces), "\n\n".join(piece[1] for piece in pieces))
        return
    page, text = VIEW_FUNCTIONS[view](found, status, script)
    _display(page, text)


# ---- output ------------------------------------------------------------------
def _display(page, text):
    """HTML in a notebook, plain text anywhere else."""
    try:
        from IPython import get_ipython
        from IPython.display import HTML, display
        if get_ipython() is not None:
            display(HTML(page))
            return
    except ImportError:
        pass
    print(text)


def _e(value):
    return html.escape(str(value))


def _box(title, body, note=""):
    head = '<div style="font-size:16px;font-weight:600;margin-bottom:6px">' + _e(title) + "</div>"
    tail = '<div style="color:#5f6b76;font-size:12px;margin-top:8px">' + note + "</div>" if note else ""
    return '<div style="' + BOX + '">' + head + body + tail + "</div>"


def _table(columns, rows, styles=None, headers=None):
    """rows: lists of cell text (already escaped HTML). styles: per-row extra style for the <tr>."""
    headers = headers or columns
    out = ['<table style="' + TABLE + '"><tr>']
    out += ['<th style="' + CELL + ';background:#f3f5f7">' + _e(h) + "</th>" for h in headers]
    out.append("</tr>")
    for index, row in enumerate(rows):
        style = (styles or {}).get(index, "")
        out.append('<tr style="' + style + '">' + "".join('<td style="' + CELL + '">' + c + "</td>" for c in row) + "</tr>")
    return "".join(out) + "</table>"


def _pill(text, background, ink):
    return ('<span style="display:inline-block;padding:1px 8px;border-radius:999px;background:' + background +
            ";color:" + ink + ';font-size:12px;margin:1px 2px">' + _e(text) + "</span>")


def _source(item, week_word=True, drawn=False):
    """Where a part comes from, in words. drawn: this picture runs the student's own function directly."""
    if item["state"] == "yours":
        return t("yours ({file})", file=item["file"])
    if item["state"] == "copied":
        return t("model version copied into {file} (not yours yet)", file=item["file"])
    if item["state"] == "needs_work" and drawn:
        return t("yours in {file} needs work ({passed}/{total} cases). This picture shows what your version does; "
                 "the rest of the system uses the model version until it passes.",
                 file=item["file"], passed=item["passed"], total=item["total"])
    if item["state"] == "needs_work":
        return t("yours in {file} needs work ({passed}/{total} cases), so the model version is used",
                 file=item["file"], passed=item["passed"], total=item["total"])
    return t("model version (you write it in Week {week})", week=item["week"]) if week_word else t("model version")


def _banner(found, names, drawn=()):
    """Which parts this picture uses: a row of pills, and a note for each part that is not yours yet.

    drawn: parts this picture runs directly from the student's file, even when they do not pass yet.
    """
    pills, notes, text_lines = [], [], []
    for name in names:
        item = part(found, name)
        background, ink, mark = LOOK[item["state"]]
        pills.append(_pill(mark + " " + name, background, ink))
        source = _source(item, drawn=name in drawn)
        if item["state"] != "yours":
            notes.append('<div style="color:#5f6b76;font-size:12px">' + mark + " " + _e(name) + ": " + _e(source) + "</div>")
        text_lines.append("   " + mark + " " + name + ": " + source)
    problems_html, problems_text = _problems(found)
    label = '<span style="color:#5f6b76;font-size:12px">' + _e(t("Parts used:")) + "</span> "
    html_out = problems_html + "<div>" + label + "".join(pills) + "".join(notes) + "</div>"
    text_out = (problems_text + "\n" if problems_text else "") + "\n".join(text_lines)
    return html_out, text_out


def _problems(found):
    if not found["problems"]:
        return "", ""
    page = "".join('<div style="background:#fff4e0;color:#8a5300;padding:4px 8px;border-radius:6px;margin:3px 0">⚠️ ' +
                   _e(problem) + "</div>" for problem in found["problems"])
    return page, "\n".join("⚠️ " + problem for problem in found["problems"])


def _system(found, data_dir=None):
    from .system import System
    return System.from_folder(found["folder"], data_dir=data_dir, quiet=True)


# ---- map ---------------------------------------------------------------------------
def view_map(found, status=None, script=None):
    folder = found["folder"]
    yours = len([p for p in found["parts"] if p["state"] == "yours"])
    title = "📁 " + t("{folder}/ · {yours} of {total} parts are yours", folder=folder, yours=yours, total=len(PARTS))
    problems_html, problems_text = _problems(found)
    cards, text = [], [title, t("   (the model version runs every part that is not yours yet)")]
    if problems_text:
        text.append(problems_text)
    for file, week in FILES:
        items = [p for p in found["parts"] if p["file"] == file or (p["state"] == "missing" and _home(p) == file)]
        exists = os.path.exists(os.path.join(folder, file))
        states = [p["state"] for p in items]
        if file == "tests.py":
            count = len(found["tests"])
            states = ["yours"] if count else ["missing"]
        border = "#1e6b3a" if states and all(s == "yours" for s in states) else \
            "#c77700" if "needs_work" in states or ("yours" in states) else "#c9d3dc"
        lines = []
        text.append(("📄 " if exists else "▫️ ") + file + "  (" + t("Week {week}", week=week) + ")")
        if file == "tests.py":
            word = t("{count} test function(s)", count=len(found["tests"])) if found["tests"] else t("Week 10")
            lines.append('<div style="font-size:13px;color:#5f6b76">' + _e(word) + "</div>")
            text.append("   " + ("✅ " if found["tests"] else "⬜ ") + word)
        for item in items:
            background, ink, mark = LOOK[item["state"]]
            if item["state"] == "yours":
                note = t("yours · {passed}/{total} cases", passed=item["passed"], total=item["total"])
            elif item["state"] == "copied":
                note = t("model version copied by the kit · not yours yet")
            elif item["state"] == "needs_work":
                note = t("needs work · {passed}/{total} cases · model version in use",
                         passed=item["passed"], total=item["total"])
            else:
                note = t("not written yet · model version in use")
            lines.append('<div style="margin:3px 0">' + _pill(mark + " " + item["name"], background, ink) +
                         '<div style="font-size:12px;color:#5f6b76;margin-left:6px">' + _e(item["job"]) + " · " +
                         _e(note) + "</div></div>")
            text.append("   " + mark + " " + item["name"].ljust(19) + note)
        cards.append('<div style="border:2px solid ' + border + ';border-radius:10px;padding:8px 10px;min-width:200px;'
                     'flex:1 1 220px;background:#ffffff"><div style="font-family:ui-monospace,Menlo,monospace;'
                     'font-weight:600">' + ("📄 " if exists else "▫️ ") + _e(file) +
                     ' <span style="font-weight:400;color:#5f6b76;font-size:12px">' + _e(t("Week {week}", week=week)) +
                     "</span></div>" + "".join(lines) + "</div>")
    changes = changed_settings(found)
    decisions = ""
    if changes:
        decisions = '<div style="margin-top:8px;font-size:13px">🧭 ' + _e(t("Your decisions:")) + " " + ", ".join(
            "<code>" + _e(name) + " = " + _e(repr(value)) + "</code>" for name, value, _, _ in changes) + "</div>"
        text.append("🧭 " + t("Your decisions:") + " " + ", ".join(name + " = " + repr(value)
                                                                   for name, value, _, _ in changes))
    hint = ""
    needs = [p for p in found["parts"] if p["state"] == "needs_work"]
    if needs:
        call = 'bridge.check("' + needs[0]["name"] + '", folder="' + folder + '")'
        hint = _e(t("To see what needs work, run")) + " <code>" + _e(call) + "</code>"
        text.append("💡 " + t("To see what needs work, run") + " " + call)
    body = problems_html + '<div style="display:flex;flex-wrap:wrap;gap:8px">' + "".join(cards) + "</div>" + decisions
    return _box(title, body, hint or _e(t("✅ yours · 🔧 needs work · ⬜ not written yet · 📦 copied model version. "
                                           "The model version runs every part that is not yours yet."))), "\n".join(text)


def _home(item):
    for file, name, _, _ in PARTS:
        if name == item["name"]:
            return file
    return item["file"]


# ---- sheet (Week 5) ------------------------------------------------------------------
def view_sheet(found, status=None, script=None):
    item = part(found, "clean_offer")
    settings = make_settings(found["settings"], quiet=True)
    if item["function"] is not None:
        clean = item["function"]
    else:
        def clean(raw):
            return validation.clean_offer(raw, settings)
    rows = validation.read_offers_csv(SAMPLE_CSV)
    fields = ["donor", "food", "category", "portions", "hours_left"]
    table_rows, styles, text = [], {}, []
    accepted = refused = broken = 0
    for index, raw in enumerate(rows):
        try:
            result = clean(dict(raw))
            offer, errors = result
        except Exception as error:
            broken += 1
            message = t("error: {error}", error=type(error).__name__ + ": " + str(error))
            cells = [_e(raw.get(f, "")) for f in fields]
            table_rows.append([str(index + 1)] + cells + ["💥 " + _e(message)])
            styles[index] = "background:#fff4e0"
            text.append(str(index + 1).rjust(2) + "  💥 " + raw.get("donor", "") + " · " + message)
            continue
        if errors or offer is None:
            refused += 1
            errors = [str(e) for e in (errors or [t("refused")])]
            cells = []
            for field in fields:
                value = _e(repr(raw.get(field, "")) if raw.get(field, "").strip() != raw.get(field, "") or
                           raw.get(field, "") == "" else raw.get(field, ""))
                named = any(field.replace("_", " ") in e or field in e for e in errors)
                cells.append('<span style="background:#f9d6d3;padding:0 3px;border-radius:3px">' + value + "</span>"
                             if named else value)
            table_rows.append([str(index + 1)] + cells + ["🚫 " + "<br>".join(_e(e) for e in errors)])
            styles[index] = "background:#fdecea"
            text.append(str(index + 1).rjust(2) + "  🚫 " + (raw.get("donor") or "(no donor)") + " · " + "; ".join(errors))
        else:
            accepted += 1
            cells = []
            for field in fields:
                before, after = raw.get(field, ""), offer.get(field, "")
                tidy = str(after) != before
                cells.append(_e(after) + (' <span style="color:#5f6b76;font-size:11px">(' + _e(repr(before)) + ")</span>"
                                          if tidy and str(after) != before.strip() else ""))
            table_rows.append([str(index + 1)] + cells + ["✅ " + _e(t("accepted"))])
            styles[index] = "background:#e7f5ec"
            text.append(str(index + 1).rjust(2) + "  ✅ " + offer.get("donor", "") + " · " + str(offer.get("portions", "")) +
                        " " + t("portions") + " · " + str(offer.get("category", "")))
    banner_html, banner_text = _banner(found, ["clean_offer"], drawn=["clean_offer"])
    summary = t("{accepted} accepted · {refused} refused at the door", accepted=accepted, refused=refused)
    if broken:
        summary += " · " + t("{count} made your function stop with an error", count=broken)
    title = "📋 " + t("offers.csv through your door: {summary}", summary=summary)
    body = banner_html + _table(["#"] + fields + ["result"], table_rows, styles)
    note = _e(t("Every value in a CSV file arrives as text. Green rows are accepted with tidy values; "
                "red rows are refused, and the red cells are the ones your messages name."))
    return _box(title, body, note), title + "\n" + banner_text + "\n" + "\n".join(text)


# ---- lifecycle (Week 6) -------------------------------------------------------------
POSITIONS = {"new": (90, 70), "approved": (260, 70), "picked_up": (430, 70), "delivered": (600, 70),
             "rejected": (90, 200), "cancelled": (260, 200)}
SPARE = [(430, 200), (600, 200), (90, 330), (260, 330), (430, 330), (600, 330)]


def _moves(found):
    """Return (statuses, allowed moves, problem, source item, settings)."""
    item = part(found, "can_move")
    settings = make_settings(found["settings"], quiet=True)
    statuses = list(STATUSES)
    custom = found["values"].get("ALLOWED_MOVES")
    if isinstance(custom, dict):
        for key, targets in custom.items():
            for status in [key] + (list(targets) if isinstance(targets, (list, tuple, set)) else []):
                if isinstance(status, str) and status not in statuses:
                    statuses.append(status)
    if item["function"] is not None:
        function = item["function"]
    else:
        allowed = models.allowed_moves(settings["REQUIRE_APPROVAL"])

        def function(old, new):
            return models.can_move(old, new, allowed)
    moves, problem = [], None
    for old in statuses:
        for new in statuses:
            if old == new:
                continue
            try:
                if function(old, new) is True:
                    moves.append((old, new))
            except Exception as error:
                problem = t("can_move({old}, {new}) stopped with {error}", old=repr(old), new=repr(new),
                            error=type(error).__name__ + ": " + str(error))
    return statuses, moves, problem, item, settings


def _arrow_kind(move):
    if move[0] not in STATUSES or move[1] not in STATUSES:
        return "added"
    if move in [(a, b) for a, targets in models.allowed_moves(True).items() for b in targets]:
        return "normal"
    if move in [(a, b) for a, targets in models.allowed_moves(False).items() for b in targets]:
        return "decision"
    return "unusual"


def _edge(center, toward):
    """The point where the line from center toward another point leaves a 124 x 40 box."""
    (x, y), (tx, ty) = center, toward
    dx, dy = tx - x, ty - y
    if dx == 0 and dy == 0:
        return x, y
    scale = min(62 / abs(dx) if dx else 1e9, 20 / abs(dy) if dy else 1e9)
    return x + dx * scale, y + dy * scale


def view_lifecycle(found, status=None, script=None):
    statuses, moves, problem, item, settings = _moves(found)
    positions = dict(POSITIONS)
    spare = list(SPARE)
    for state in statuses:
        if state not in positions and spare:
            positions[state] = spare.pop(0)
    height = 400 if any(y > 250 for _, y in positions.values()) else 270
    colours = {"normal": "#4a5560", "decision": "#c77700", "unusual": "#c62828", "missing": "#b8c2cc", "added": "#2f6f9f"}
    expected = [(a, b) for a, targets in models.allowed_moves(settings["REQUIRE_APPROVAL"]).items() for b in targets]
    missing = [move for move in expected if move not in moves]
    svg = ['<svg viewBox="0 0 700 ' + str(height) + '" width="100%" style="max-width:700px" '
           'xmlns="http://www.w3.org/2000/svg" font-family="ui-monospace,Menlo,monospace" font-size="13">',
           "<defs>"]
    for kind, colour in colours.items():
        svg.append('<marker id="arrow-' + kind + '" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
                   'markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="' + colour + '"/></marker>')
    svg.append("</defs>")
    drawn = [(move, _arrow_kind(move)) for move in moves] + [(move, "missing") for move in missing]
    for (old, new), kind in drawn:
        if old not in positions or new not in positions:
            continue
        (ax, ay), (bx, by) = positions[old], positions[new]
        style = ' stroke-dasharray="6 4"' if kind == "unusual" else ' stroke-dasharray="2 4"' if kind == "missing" else ""
        common = 'fill="none" stroke="' + colours[kind] + '" stroke-width="2"' + style + ' marker-end="url(#arrow-' + kind + ')"'
        if ay == by and (bx - ax == 170):
            svg.append('<line x1="' + str(ax + 62) + '" y1="' + str(ay) + '" x2="' + str(bx - 64) + '" y2="' + str(by) +
                       '" ' + common + "/>")
            label_at = ((ax + bx) / 2, ay - 6)
        elif ay == by:
            lift = 40 + abs(bx - ax) * 0.12
            sign = -1 if bx > ax else 1
            y0 = ay - 20 if sign < 0 else ay + 20
            svg.append('<path d="M' + str(ax) + "," + str(y0) + " Q" + str((ax + bx) / 2) + "," + str(y0 + sign * lift) +
                       " " + str(bx) + "," + str(y0) + '" ' + common + "/>")
            label_at = ((ax + bx) / 2, y0 + sign * lift / 2)
        else:
            x1, y1 = _edge((ax, ay), (bx, by))
            x2, y2 = _edge((bx, by), (ax, ay))
            svg.append('<line x1="' + str(round(x1)) + '" y1="' + str(round(y1)) + '" x2="' + str(round(x2)) + '" y2="' +
                       str(round(y2)) + '" ' + common + "/>")
            label_at = ((x1 + x2) / 2 + 6, (y1 + y2) / 2)
        if kind in ("unusual", "missing", "decision"):
            word = {"unusual": t("unusual?"), "missing": t("missing?"), "decision": t("your decision")}[kind]
            svg.append('<text x="' + str(round(label_at[0])) + '" y="' + str(round(label_at[1])) + '" fill="' + colours[kind] +
                       '" font-size="11" font-family="system-ui,sans-serif">' + _e(word) + "</text>")
    allowed_next = [new for old, new in moves if old == status]
    for state in statuses:
        x, y = positions.get(state, (0, 0))
        fill, stroke, width = "#ffffff", "#7b8794", 1.5
        if state == status:
            fill, stroke, width = "#e7f5ec", "#1e6b3a", 3.5
        elif state in allowed_next:
            fill, stroke = "#f1faf4", "#1e6b3a"
        svg.append('<rect x="' + str(x - 62) + '" y="' + str(y - 20) + '" width="124" height="40" rx="9" fill="' + fill +
                   '" stroke="' + stroke + '" stroke-width="' + str(width) + '"/>')
        svg.append('<text x="' + str(x) + '" y="' + str(y + 5) + '" text-anchor="middle" fill="#1f2933">' + _e(state) + "</text>")
    svg.append("</svg>")
    banner_html, banner_text = _banner(found, ["can_move"], drawn=["can_move"])
    text = ["🔁 " + t("The lifecycle your can_move allows"), banner_text]
    text.append("   " + t("moves:") + " " + ", ".join(a + " → " + b for a, b in moves))
    notes = []
    for move in moves:
        if _arrow_kind(move) == "unusual":
            notes.append(("#c62828", t("Unusual: {old} → {new}. Should this ever happen?", old=move[0], new=move[1])))
        elif _arrow_kind(move) == "added":
            notes.append(("#2f6f9f", t("Your new state: {old} → {new}. Add a test for it.", old=move[0], new=move[1])))
        elif _arrow_kind(move) == "decision":
            notes.append(("#c77700", t("Your decision: {old} → {new} (no approval). Explain it in your decision log.",
                                       old=move[0], new=move[1])))
    for move in missing:
        notes.append(("#5f6b76", t("Missing: {old} → {new}. Without it, an offer can get stuck.", old=move[0], new=move[1])))
    if problem:
        notes.append(("#8a5300", "💥 " + problem))
    buttons = ""
    if status:
        if status not in statuses:
            notes.append(("#8a5300", t("{status} is not a status in this lifecycle.", status=repr(status))))
        pills = "".join(_pill(("✅ → " if s in allowed_next else "· → ") + s, "#e7f5ec" if s in allowed_next else "#f3f5f7",
                              "#1e6b3a" if s in allowed_next else "#9aa5b1") for s in statuses if s != status)
        buttons = '<div style="margin-top:6px;font-size:13px">' + _e(t("An offer that is {status} can move to:", status=status)) + \
            "<br>" + pills + "</div>"
        text.append("   " + t("An offer that is {status} can move to:", status=status) + " " +
                    (", ".join(allowed_next) or t("nothing")))
    notes_html = "".join('<div style="color:' + colour + ';font-size:13px">' + _e(note) + "</div>" for colour, note in notes)
    text += ["   " + note for _, note in notes]
    legend = _e(t("Grey arrows: the usual lifecycle · orange: your decision · blue: a state you added · "
                  "red dashes: unusual · dotted: missing."))
    return _box("🔁 " + t("The lifecycle your can_move allows"), banner_html + "".join(svg) + buttons + notes_html,
                legend), "\n".join(text)


# ---- history (Week 7) -------------------------------------------------------------
def view_history(found, status=None, script=None):
    demo = os.path.join(found["folder"], "demo_day")
    os.makedirs(demo, exist_ok=True)
    for name in ("offers.json", "history.jsonl", "offers.json.tmp"):
        path = os.path.join(demo, name)
        if os.path.exists(path):
            os.remove(path)
    system = _system(found, data_dir=demo)
    system.run_day(show=False)
    again = _system(found, data_dir=demo)
    came_back = again.records() == system.records()
    banner_html, banner_text = _banner(found, ["save_records", "load_records", "append_event", "read_events"])
    files, text = [], ["💾 " + t("The sample day, saved with your storage.py"), banner_text]
    for name in ("offers.json", "history.jsonl"):
        path = os.path.join(demo, name)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as file:
                content = file.read()
            lines = content.splitlines()
            preview = "\n".join(lines[:8]) + ("\n…" if len(lines) > 8 else "")
            files.append('<div style="flex:1 1 320px;min-width:260px"><div style="font-family:ui-monospace,Menlo,monospace;'
                         'font-weight:600">📄 ' + _e(os.path.join(demo, name)) + ' <span style="font-weight:400;color:#5f6b76;'
                         'font-size:12px">' + _e(t("{count} lines · {size} bytes", count=len(lines), size=len(content.encode()))) +
                         '</span></div><pre style="background:#f6f8fa;border:1px solid #d6dde4;border-radius:6px;padding:6px;'
                         'font-size:11px;max-height:180px;overflow:auto;white-space:pre-wrap">' + _e(preview) + "</pre></div>")
            text.append("   📄 " + os.path.join(demo, name) + "  (" + t("{count} lines", count=len(lines)) + ")")
        else:
            files.append('<div style="color:#8a5300">⚠️ ' + _e(t("{name} was not written.", name=name)) + "</div>")
            text.append("   ⚠️ " + t("{name} was not written.", name=name))
    icons = {"added": "➕", "input_rejected": "🚫", "moved": "➡️"}
    events = again.history

    def event_name(e):                        # the event's name on screen, as in history_text
        code = str(e.get("event", ""))
        return code if again.lang == "en" else word(code, again.lang)

    timeline = "".join('<div style="font-size:13px;padding:2px 0;border-left:3px solid #c9d3dc;padding-left:8px;margin-left:4px">'
                       + icons.get(e.get("event"), "•") + " <b>#" + _e(e.get("step", "?")) + "</b> " + _e(event_name(e)) +
                       " " + _e(e.get("offer", "")) + ' <span style="color:#5f6b76">' + _e(again.detail_text(e)) + "</span></div>"
                       for e in events)
    text.append("   " + t("history after a restart: {count} events", count=len(events)))
    for e in events:
        text.append("     " + icons.get(e.get("event"), "•") + " #" + str(e.get("step", "?")) + " " + event_name(e) +
                    " " + str(e.get("offer", "")) + " " + again.detail_text(e))
    logged = make_settings(found["settings"], quiet=True)["LOG_EVENTS"]
    skipped = [kind for kind in ("added", "input_rejected", "moved") if kind not in logged]
    skipped_line = ("🧭 " + t("Not kept in your history (LOG_EVENTS): {kinds}. Which question can nobody answer now?",
                             kinds=", ".join(skipped))) if skipped else ""
    if skipped_line:
        text.append("   " + skipped_line)
    restart = ("✅ " + t("Restart test: a new system loaded the saved file and got the same {count} records back.",
                         count=len(again.records()))) if came_back else \
        ("🔧 " + t("Restart test: after loading the saved file, the records were different. Check load_records."))
    text.append("   " + restart)
    body = (banner_html + '<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:6px">' + "".join(files) + "</div>" +
            '<div style="font-weight:600;margin-top:8px">' + _e(t("The history, read back after a restart")) + "</div>" +
            timeline + ('<div style="margin-top:6px;font-size:13px;color:#8a5300">' + _e(skipped_line) + "</div>"
                        if skipped_line else "") +
            '<div style="margin-top:8px;font-size:13px">' + _e(restart) + "</div>")
    note = _e(t("The files are in {folder}. They are made again each time you run this cell.", folder=demo + "/"))
    return _box("💾 " + t("The sample day, saved with your storage.py"), body, note), "\n".join(text)


# ---- board (Week 8) ---------------------------------------------------------------
def view_board(found, status=None, script=None):
    system = _system(found)
    system.run_day(show=False)
    ordered = system.ordered()
    coordinator_columns = ["id", "food", "category", "portions", "hours_left", "urgency", "pickup", "status", "partner", "donor", "contact"]
    coordinator = []
    for record in ordered:
        offer = system.get(record["id"])
        coordinator.append([_e(record["id"]), _e(record["food"]), _e(record["category"]), _e(record["portions"]), _e(record["hours_left"]),
                            _e(system.urgency(offer)), _e(system.label(offer)), _e(record["status"]), _e(record["partner"]),
                            _e(record["donor"]), _e(record["contact"])])
    public = [dict(system._call("public_row", record)) for record in ordered if record["status"] not in ("rejected", "cancelled")]
    public_columns = []
    for row in public:
        public_columns += [c for c in row if c not in public_columns]
    leaks = [c for c in public_columns if c in ("contact", "donor", "partner")]
    hidden = [c for c in coordinator_columns if c not in public_columns]
    numbers = system.numbers()
    by_status = system._call("portions_by_status", system.records())
    biggest = max([v for v in by_status.values() if isinstance(v, (int, float))] + [1])
    bars = "".join('<div style="display:flex;align-items:center;gap:6px;font-size:12px;margin:2px 0"><span style="width:80px">' +
                   _e(key) + '</span><span style="display:inline-block;height:12px;width:' +
                   str(int(200 * value / biggest) if isinstance(value, (int, float)) else 0) +
                   'px;background:#2f6f9f;border-radius:3px"></span><span>' + _e(value) + "</span></div>"
                   for key, value in by_status.items())
    banner_html, banner_text = _banner(found, ["most_urgent_first", "public_row", "total_portions", "open_portions",
                                               "portions_by_status", "pickup_label", "urgency"])
    warn = ""
    if leaks:
        warn = '<div style="background:#fdecea;color:#b3261e;padding:4px 8px;border-radius:6px">🔓 ' + \
            _e(t("The public board shows {fields}. Is that safe for the donors and partners?", fields=", ".join(leaks))) + "</div>"
    numbers_html = ('<div style="font-size:13px">' + _e(t("Portions offered")) + ": <b>" + _e(numbers["portions_offered"]) + "</b> · " +
                    _e(t("still open")) + ": <b>" + _e(numbers["portions_open"]) + "</b> · " + _e(t("picked up")) + ": <b>" +
                    _e(numbers["portions_picked_up"]) + "</b> · " + _e(t("delivered")) + ": <b>" + _e(numbers["portions_delivered"]) +
                    '</b><br><span style="color:#5f6b76">' + _e(t("Different measures: never add them together.")) + "</span></div>")
    body = (banner_html + warn +
            '<div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:6px"><div style="flex:2 1 520px">' +
            '<div style="font-weight:600">👩‍💼 ' + _e(t("Coordinator view (all records)")) + "</div>" +
            _table(coordinator_columns, coordinator) + "</div>" +
            '<div style="flex:1 1 280px"><div style="font-weight:600">📢 ' + _e(t("Public board")) + "</div>" +
            _table(public_columns, [[_e(row.get(c, "")) for c in public_columns] for row in public]) +
            '<div style="font-size:12px;color:#5f6b76">' + _e(t("Hidden from the public: {fields}", fields=", ".join(hidden) or "—")) +
            "</div></div></div>" + numbers_html + '<div style="margin-top:6px;font-weight:600;font-size:13px">' +
            _e(t("Portions by status (your portions_by_status)")) + "</div>" + bars)
    text = ["📢 " + t("Coordinator view and public board"), banner_text]
    text.append("   " + t("Coordinator view (all records)") + ":")
    text.append(_indent(reports.format_table([dict(zip(coordinator_columns, [html.unescape(c) for c in row]))
                                              for row in coordinator], coordinator_columns)))
    text.append("   " + t("Public board") + ":")
    text.append(_indent(reports.format_table(public, public_columns)))
    text.append("   " + t("Hidden from the public: {fields}", fields=", ".join(hidden) or "—"))
    if leaks:
        text.append("   🔓 " + t("The public board shows {fields}. Is that safe for the donors and partners?", fields=", ".join(leaks)))
    text.append("   " + t("Portions offered") + ": " + str(numbers["portions_offered"]) + " · " + t("still open") + ": " +
                str(numbers["portions_open"]) + " · " + t("picked up") + ": " + str(numbers["portions_picked_up"]) + " · " +
                t("delivered") + ": " + str(numbers["portions_delivered"]))
    text.append("   " + t("Different measures: never add them together."))
    text.append("   " + t("Portions by status (your portions_by_status)") + ": " + json.dumps(by_status))
    return _box("📢 " + t("Coordinator view and public board"), body), "\n".join(text)


def _indent(block):
    return "\n".join("     " + line for line in block.splitlines())


# ---- app (Week 9) ---------------------------------------------------------------
def view_app(found, status=None, script=None):
    script = list(script or ["1", "2", "3", "x", "q"])
    item = part(found, "handle_choice")
    settings = make_settings(found["settings"], quiet=True)
    if item["function"] is not None:
        handle = item["function"]
    else:
        def handle(choice, offers):
            return model_handle_choice(choice, offers, settings)
    menu = found["values"].get("MENU") if isinstance(found["values"].get("MENU"), str) else \
        "1 open offers · 2 totals · 3 public board · q quit"
    lines = [menu]
    for choice in script:
        lines.append("> " + choice)
        if choice == "q":
            lines.append("Goodbye!")
            break
        try:
            answer = handle(choice, sample_records())
        except Exception as error:
            answer = "💥 " + t("error: {error}", error=type(error).__name__ + ": " + str(error))
        lines.append(str(answer))
    banner_html, banner_text = _banner(found, ["handle_choice"], drawn=["handle_choice"])
    transcript = "\n".join(lines)
    body = (banner_html + '<pre style="background:#1f2933;color:#e6edf3;border-radius:8px;padding:10px 12px;font-size:12px;'
            'white-space:pre-wrap;margin-top:6px">' + _e(transcript) + "</pre>")
    note = _e(t('This runs your handle_choice with a script. Open the live web page with bridge.start_web(folder="{folder}"), '
                'or try the text menu with !cd {folder} && python app.py',
                folder=found["folder"]))
    return _box("🖥️ " + t("Your app, run with the script {script}", script=script), body, note), \
        "🖥️ " + t("Your app, run with the script {script}", script=script) + "\n" + banner_text + "\n" + _indent(transcript)


# ---- screen (a Final extension option) ---------------------------------------------
def view_screen(found, status=None, script=None):
    problems_html, problems_text = _problems(found)
    prefix_text = problems_text + "\n" if problems_text else ""
    make_page = found["functions"].get("make_page", (None, None))[0]
    if make_page is None:
        message = t("No make_page(records) yet. It goes in {folder}/screen.py (a Final extension option).",
                    folder=found["folder"])
        return _box("🖼️ " + t("Your screen"), problems_html + _e(message)), prefix_text + "🖼️ " + message
    system = _system(found)
    system.run_day(show=False)
    try:
        page = make_page(system.records())
    except Exception as error:
        message = "💥 " + t("error: {error}", error=type(error).__name__ + ": " + str(error))
        return _box("🖼️ " + t("Your screen"), problems_html + _e(message)), prefix_text + message
    if not isinstance(page, str):
        message = t("make_page should return the page as text (a str), not {kind}.", kind=type(page).__name__)
        return _box("🖼️ " + t("Your screen"), problems_html + _e(message)), prefix_text + "🖼️ " + message
    import re
    plain = re.sub(r"<[^>]+>", " ", page)
    plain = re.sub(r"[ \t]+", " ", html.unescape(plain))
    plain = "\n".join(line.strip() for line in plain.splitlines() if line.strip())
    return _box("🖼️ " + t("Your screen (from screen.py)"),
                problems_html + '<div style="border:1px dashed #c9d3dc;padding:8px">' + page + "</div>"), \
        prefix_text + "🖼️ " + t("Your screen (from screen.py)") + "\n" + _indent(plain[:1500])


VIEW_FUNCTIONS = {"map": view_map, "sheet": view_sheet, "lifecycle": view_lifecycle, "history": view_history,
                  "board": view_board, "app": view_app, "screen": view_screen}
