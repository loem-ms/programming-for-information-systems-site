"""The parts of your system folder (Weeks 4–10). You do not need to read this file.

Each week you add one file to my_foodbridge/. This module knows which
function belongs in which file, checks each one quietly, and supplies the
model version of any part that is missing or does not pass yet, so the
whole system always runs.
"""
import inspect
import os

from . import records, reports, rules
from .check import quiet_result
from .folder import FOLDER, load_folder
from .messages import current_language, t
from .settings import DEFAULTS, make_settings

# (file, function, week, what it does)
PARTS = [
    ("rules.py", "pickup_label", 4, "team, standard or hold"),
    ("rules.py", "urgency", 4, "urgent, soon or later"),
    ("records.py", "total_portions", 4, "all the portions offered"),
    ("records.py", "find_offer", 4, "one offer, found by its ID"),
    ("records.py", "open_portions", 4, "the portions still waiting"),
    ("data_model.py", "clean_offer", 5, "checks every row at the door"),
    ("lifecycle.py", "can_move", 6, "allows only sensible moves"),
    ("storage.py", "save_records", 7, "saves every record"),
    ("storage.py", "load_records", 7, "loads them back"),
    ("storage.py", "append_event", 7, "adds one line to the history"),
    ("storage.py", "read_events", 7, "reads the history"),
    ("report.py", "public_row", 8, "what the public may see"),
    ("report.py", "most_urgent_first", 8, "the order on both boards"),
    ("report.py", "portions_by_status", 8, "the numbers for the chart"),
    ("app.py", "handle_choice", 9, "answers one menu choice"),
]
FILES = [("rules.py", 4), ("records.py", 4), ("data_model.py", 5), ("lifecycle.py", 6), ("storage.py", 7),
         ("report.py", 8), ("app.py", 9), ("tests.py", 10)]
OPEN = ("new", "approved", "picked_up")
MODEL_FILES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model_files")
FILLABLE = ["rules.py", "records.py", "data_model.py", "lifecycle.py", "storage.py", "report.py"]
COPIED = "# 📦 MODEL VERSION copied by the kit. Replace it with your own code when you can."


def fill_gaps(folder=FOLDER):
    """Copy the kit's model version of every missing Week 4–8 file, so app.py can import it. Return the names."""
    os.makedirs(folder, exist_ok=True)
    written = []
    for name in FILLABLE:
        target = os.path.join(folder, name)
        if not os.path.exists(target):
            with open(os.path.join(MODEL_FILES, name), encoding="utf-8") as file:
                body = file.read()
            with open(target, "w", encoding="utf-8") as file:
                file.write(COPIED + "\n" + body)
            written.append(name)
    if written:
        print("📦 " + t("Copied the model version of {files} into {folder}/ (they were missing).",
                       files=", ".join(written), folder=folder))
    else:
        print("📁 " + t("No gaps: every Week 4–8 file is already in {folder}/.", folder=folder))
    return written


def copied_files(folder):
    names = []
    for name in FILLABLE:
        path = os.path.join(folder, name)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as file:
                if file.readline().startswith(COPIED[:20]):
                    names.append(name)
    return names


def inspect_folder(folder=FOLDER):
    """Read the folder and check every part quietly.

    Adds found["parts"]: one dict per part with file, name, week, job, state
    ("yours", "needs_work" or "missing"), function, passed, total and problem.
    """
    os.makedirs(folder, exist_ok=True)
    found = load_folder(folder)
    found["folder"] = folder
    found["copied"] = copied_files(folder)
    found["parts"] = []
    for file, name, week, job in PARTS:
        part = {"file": file, "name": name, "week": week, "job": job, "state": "missing", "function": None,
                "passed": 0, "total": 0, "problem": None}
        if name in found["functions"]:
            function, where = found["functions"][name]
            passed, total, problem = quiet_result(name, function, found["settings"])
            state = "yours" if passed == total else "needs_work"
            if where in found["copied"] and state == "yours":
                state = "copied"
            part.update(file=where, function=function, passed=passed, total=total, problem=problem, state=state)
        found["parts"].append(part)
    found["tests"] = [(name, function, file) for name, (function, file) in found["functions"].items()
                      if name.startswith("test_")]
    return found


def part(found, name):
    for item in found["parts"]:
        if item["name"] == name:
            return item
    return None


def changed_settings(found):
    """[(name, your value, default, file)] for every policy setting in your files that differs from the default."""
    order = {name: index for index, (name, _) in enumerate(FILES)}
    files = sorted(found["files"], key=lambda entry: (order.get(entry[0], len(FILES)), entry[0]))
    seen = set()
    changes = []
    for file, settings, _ in files:
        for name in settings:
            if name in seen or name == "SYSTEM_NAME":
                continue
            default = current_language() if name == "LANGUAGE" else DEFAULTS[name]
            if found["settings"][name] != default:
                seen.add(name)
                changes.append((name, found["settings"][name], default, file))
    return changes


# ---- model versions that the System does not already have -----------------
def model_handle_choice(choice, offers, settings=None):
    """The model menu: 1 open offers · 2 totals · 3 public board."""
    s = make_settings(settings, quiet=True)
    if choice == "1":
        lines = []
        for record in reports.most_urgent_first(offers):
            if record["status"] in OPEN:
                approved = record["status"] != "new"
                lines.append(record["id"] + "  " + record["food"] + " · " + str(record["portions"]) + " portions · " +
                             str(record["hours_left"]) + "h left · " +
                             rules.urgency(record["hours_left"], s["URGENT_HOURS"], s["SOON_HOURS"]) + " · pickup: " +
                             rules.pickup_label(record["portions"], approved, s["TEAM_PICKUP_MIN_PORTIONS"]))
        return "\n".join(lines) if lines else "No open offers."
    if choice == "2":
        return ("Portions offered:    " + str(records.total_portions(offers)) + "\n" +
                "Portions still open: " + str(records.open_portions(offers)))
    if choice == "3":
        rows = [reports.public_row(record, s["PUBLIC_FIELDS"]) for record in reports.most_urgent_first(offers)
                if record["status"] not in ("rejected", "cancelled")]
        return reports.format_table(rows, s["PUBLIC_FIELDS"])
    return "Please choose 1, 2, 3 or q."


# ---- bridge.check("all", folder=...) ----------------------------------------
def check_all(folder=FOLDER):
    """Check every part in the folder, run tests.py, and list your decisions. Return True when all pass."""
    found = inspect_folder(folder)
    print("📁 " + t("Checking everything in {folder}/ …", folder=folder))
    for problem in found["problems"]:
        print("  ⚠️ " + problem)
    all_ok = not found["problems"]
    for item in found["parts"]:
        label = item["file"] + " · " + item["name"]
        if item["state"] == "yours":
            print("  ✅ " + label + "  " + t("{passed}/{total} cases", passed=item["passed"], total=item["total"]))
        elif item["state"] == "copied":
            print("  📦 " + label + "  " + t("the model version, copied by the kit (not yours yet)"))
        elif item["state"] == "needs_work":
            all_ok = False
            print("  ❌ " + label + "  " + t("{passed}/{total} cases", passed=item["passed"], total=item["total"]) +
                  "   💡 " + t("run bridge.check({name}, folder={folder}) to see why",
                              name=repr(item["name"]), folder=repr(folder)))
        else:
            print("  ⬜ " + label + "  " + t("not written (the model version is used)"))
    if found["tests"]:
        print(t("Your tests ({count}):", count=len(found["tests"])))
        for name, function, file in found["tests"]:
            ok, message = run_test(function)
            all_ok = all_ok and ok
            print(("  ✅ " if ok else "  ❌ ") + file + " · " + name + ("" if ok else "   → " + message))
    changes = changed_settings(found)
    print(t("Your decisions (settings that differ from the defaults): {count}", count=len(changes)))
    for name, value, default, file in changes:
        print("  🧭 " + name + " = " + repr(value) + "   (" + t("default {value}", value=repr(default)) + ", " + file + ")")
    yours = len([item for item in found["parts"] if item["state"] == "yours"])
    print(t("{yours} of {total} parts are yours.", yours=yours, total=len(PARTS)) + (" 🎉" if all_ok else ""))
    return all_ok


def run_test(function):
    """Run one test function. Return (True, "") or (False, why)."""
    if inspect.signature(function).parameters:
        return False, t("a test function takes no inputs")
    try:
        function()
    except AssertionError as error:
        return False, t("an assert failed") + (": " + str(error) if str(error) else "")
    except Exception as error:
        return False, t("error: {error}", error=type(error).__name__ + ": " + str(error))
    return True, ""
