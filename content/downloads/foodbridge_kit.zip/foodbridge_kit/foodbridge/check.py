"""Friendly checks for your functions (you do not need to read this file).

    bridge.check("pickup_label", pickup_label, MY_SETTINGS)

prints ✅ or ❌ for each case, explains likely mistakes, and never stops your
notebook with an error. Boundary cases come from YOUR settings, so changing
a decision (for example the team minimum) does not make the check fail.
"""
import contextlib
import copy
import difflib
import inspect
import io
import json
import os
import shutil
import tempfile

from . import midterm, models, reports
from .messages import t
from .settings import make_settings
from .system import accepts


def sample_records():
    """Four records in different states, used by several checks (the same offers as the sample day)."""
    hope, riverside, elders = "Hope Children's Centre", "Riverside Community Kitchen", "Old Market Elders' Group"
    rows = [("F001", "Sunrise Bakery", "sunrise@example.org", "Bread rolls", "bread", 30, 5, "picked_up", hope),
            ("F002", "Campus Canteen", "canteen@example.org", "Fried rice boxes", "rice meals", 18, 2, "delivered",
             riverside),
            ("F003", "Green Market Stall", "greenstall@example.org", "Bananas", "fruit", 40, 20, "rejected", ""),
            ("F004", "Lotus Cafe", "lotus@example.org", "Vegetable curry with rice", "rice meals", 12, 4, "approved", elders)]
    result = []
    for offer_id, donor, contact, food, category, portions, hours, status, partner in rows:
        result.append({"id": offer_id, "donor": donor, "contact": contact, "food": food, "category": category,
                       "portions": portions, "hours_left": hours, "status": status, "partner": partner})
    return result


def _case(args, show, expect, why, judge=None):
    return {"args": args, "show": show, "expect": expect, "why": why, "judge": judge}


_TEMP = []


def _temp_folder():
    folder = tempfile.mkdtemp(prefix="foodbridge_check_")
    _TEMP.append(folder)
    return folder


def _clean_temp():
    while _TEMP:
        shutil.rmtree(_TEMP.pop(), ignore_errors=True)


def _pickup_label(s):
    t = s["TEAM_PICKUP_MIN_PORTIONS"]
    cases = [_case((t - 1, True), "pickup_label(" + str(t - 1) + ", True)", "standard", "one below your team minimum"),
             _case((t, True), "pickup_label(" + str(t) + ", True)", "team", "exactly your team minimum"),
             _case((t + 1, True), "pickup_label(" + str(t + 1) + ", True)", "team", "one above"),
             _case((t, False), "pickup_label(" + str(t) + ", False)", "hold", "not approved yet")]
    return cases + [_case((1, False), "pickup_label(1, False)", "hold", "small and not approved")]


def _urgency(s):
    u, n = s["URGENT_HOURS"], s["SOON_HOURS"]
    cases = [_case((0,), "urgency(0)", "urgent", "no time left"),
             _case((u,), "urgency(" + str(u) + ")", "urgent", "exactly URGENT_HOURS")]
    if u + 1 <= n:
        cases.append(_case((u + 1,), "urgency(" + str(u + 1) + ")", "soon", "one hour more"))
    return cases + [_case((n,), "urgency(" + str(n) + ")", "soon" if n > u else "urgent", "exactly SOON_HOURS"),
                    _case((n + 1,), "urgency(" + str(n + 1) + ")", "later", "beyond SOON_HOURS")]


def _records_cases(function_name, expected_all, expected_empty):
    def build(s):
        return [_case((sample_records(),), function_name + "(4 sample records)", expected_all, "the sample list"),
                _case(([],), function_name + "([])", expected_empty, "an empty list")]
    return build


def _find_offer(s):
    records = sample_records()
    return [_case((records, "F002"), "find_offer(records, 'F002')", records[1], "an ID that exists"),
            _case((records, "F999"), "find_offer(records, 'F999')", None, "an ID that does not exist"),
            _case(([], "F001"), "find_offer([], 'F001')", None, "an empty list")]


def _clean_offer(s):
    good = {"donor": " Sunrise Bakery ", "contact": "sunrise@example.org", "food": "Bread rolls",
            "category": "Bread", "portions": "30", "hours_left": "5"}
    category = s["CATEGORIES"][0]
    good["category"] = " " + category.title() + " "
    low, high, late = s["MIN_PORTIONS"], s["MAX_PORTIONS"], s["REJECT_IF_HOURS_LEFT_BELOW"]
    good["portions"] = str(max(low, min(high, 30)))
    good["hours_left"] = str(late + 4)

    def changed(field, value):
        row = dict(good)
        row[field] = value
        return row
    cases = [_case((good,), "clean_offer(a good row with extra spaces)", "valid", "a correct offer")]
    cases.append(_case((changed("portions", "many"),), "portions = 'many'", "invalid", "not a whole number"))
    cases.append(_case((changed("portions", str(low - 1)),), "portions = " + str(low - 1), "invalid", "below MIN_PORTIONS"))
    cases.append(_case((changed("portions", str(high + 1)),), "portions = " + str(high + 1), "invalid", "above MAX_PORTIONS"))
    cases.append(_case((changed("hours_left", str(late - 1)),), "hours_left = " + str(late - 1), "invalid", "too late to collect"))
    cases.append(_case((changed("category", "spaceship"),), "category = 'spaceship'", "invalid", "not in CATEGORIES"))
    if "donor" in s["REQUIRED_FIELDS"]:
        cases.append(_case((changed("donor", "  "),), "donor = '  '", "invalid", "a required field is blank"))
    return cases


def _can_move(s):
    allowed = models.allowed_moves(s["REQUIRE_APPROVAL"])
    pairs = [("new", "approved"), ("new", "delivered"), ("approved", "picked_up"),
             ("picked_up", "delivered"), ("delivered", "new"), ("rejected", "approved"), ("new", "picked_up"), ("deliverd", "new")]
    return [_case(p, "can_move(" + repr(p[0]) + ", " + repr(p[1]) + ")", models.can_move(p[0], p[1], allowed),
                  "a status that does not exist" if p[0] == "deliverd" else "follow the lifecycle arrows")
            for p in pairs]


def _to_record(s):
    offer = models.from_record(sample_records()[3])
    return [_case((offer,), "to_record(offer F004)", sample_records()[3], "every field, same values")]


def _from_record(s):
    record = sample_records()[0]
    return [_case((record,), "from_record(record F001)", "same:" + record["id"], "an Offer with the same fields")]


def _public_row(s):
    records = sample_records()
    fields = s["PUBLIC_FIELDS"]
    return [_case((records[0],), "public_row(record F001)", reports.public_row(records[0], fields), "only PUBLIC_FIELDS"),
            _case((records[3],), "public_row(record F004)", reports.public_row(records[3], fields), "only PUBLIC_FIELDS")]


def _ids_in_order(expected):
    def judge(result):
        if result is None:
            return False, "None", t("Return the new list: return sorted(records, key=your_key_function).")
        if not isinstance(result, list) or not all(isinstance(r, dict) and "id" in r for r in result):
            return False, _short(result), t("Return a list of records (dictionaries), not {kind}.",
                                            kind=type(result).__name__)
        got = [r["id"] for r in result]
        ok = got == expected
        return ok, _short(got), None if ok else t("Expected the order {expected}.", expected=expected)
    return judge


def _most_urgent_first(s):
    records = sample_records()
    return [_case((records,), "most_urgent_first(4 sample records)", None, "fewest hours left first",
                  _ids_in_order(["F002", "F004", "F001", "F003"])),
            _case((records,), "the list you passed in", "input unchanged", "build a new list; do not sort in place")]


def _text_judge(must, must_not=(), order=None, hint=""):
    def judge(result):
        if not isinstance(result, str) or not result.strip():
            return False, _short(result), t("Return the text to show (a str), not print it.")
        missing = [word for word in must if word not in result]
        extra = [word for word in must_not if word in result]
        wrong_order = order and all(word in result for word in order) and \
            [result.index(word) for word in order] != sorted(result.index(word) for word in order)
        ok = not missing and not extra and not wrong_order
        shown = _short(result)
        if missing:
            return False, shown, t("The text should include {words}.", words=", ".join(missing)) + " " + t(hint)
        if extra:
            return False, shown, t("The text should not include {words}.", words=", ".join(extra)) + " " + t(hint)
        if wrong_order:
            return False, shown, t("Show them in this order: {words}.", words=", ".join(order))
        return ok, shown, None
    return judge


def _handle_choice(s):
    records = sample_records()
    # what the public board must show: a field the student made public (food, or else the ID), most urgent first
    key = "food" if "food" in s["PUBLIC_FIELDS"] else ("id" if "id" in s["PUBLIC_FIELDS"] else None)
    board = [r[key] for r in reports.most_urgent_first(records) if r["status"] not in ("rejected", "cancelled")] if key else []
    hidden = [r[key] for r in records if r["status"] in ("rejected", "cancelled")] if key else []
    return [_case(("1", records), "handle_choice('1', records)", None, "open offers, most urgent first",
                  _text_judge(["F004", "F001"], ["F002", "F003"], ["F004", "F001"],
                              "Open means new, approved or picked up.")),
            _case(("2", records), "handle_choice('2', records)", None, "portions offered and still open",
                  _text_judge(["100", "42"])),
            _case(("3", records), "handle_choice('3', records)", None, "the public board",
                  _text_judge(board, hidden + ["@example.org"], board,
                              "One row for each offer that is not rejected or cancelled, most urgent first, "
                              "made by your public_row (so contacts stay private).")),
            _case(("x", records), "handle_choice('x', records)", "any message", "an unknown choice")]


def _json_file(path):
    with open(path, encoding="utf-8") as file:
        return json.load(file)


def _save_records(s):
    path = os.path.join(_temp_folder(), "offers.json")
    records = sample_records()

    def file_holds(expected):
        def judge(result):
            if not os.path.exists(path):
                return False, t("no file"), t('Write to a temporary file with open(path + ".tmp", "w") and json.dump, then os.replace(path + ".tmp", path).')
            try:
                data = _json_file(path)
            except ValueError:
                return False, t("the file is not valid JSON"), \
                    t('Use "w" (write), not "a" (append), and json.dump(records, file).')
            ok = data == expected
            count = len(data) if isinstance(data, list) else "?"
            return ok, t("{count} records in the file", count=count), \
                None if ok else t("The file should hold exactly the list you saved.")
        return judge
    return [_case((records, path), "save_records(4 records, 'offers.json')", None, "the file holds the 4 records",
                  file_holds(records)),
            _case((records[:2], path), "save_records(2 records, 'offers.json')", None,
                  "saving again replaces the old list", file_holds(records[:2]))]


def _load_records(s):
    folder = _temp_folder()
    path = os.path.join(folder, "offers.json")
    with open(path, "w", encoding="utf-8") as file:
        json.dump(sample_records(), file)
    return [_case((os.path.join(folder, "nothing_saved.json"),), "load_records(a file that does not exist)", [],
                  "nothing is saved yet"),
            _case((path,), "load_records('offers.json')", sample_records(), "the 4 saved records")]


EVENTS = [{"step": 1, "event": "added", "offer": "F001", "detail": "30 portions of Bread rolls"},
          {"step": 2, "event": "moved", "offer": "F001", "detail": "new -> approved"}]


def _append_event(s):
    path = os.path.join(_temp_folder(), "history.jsonl")

    def lines_are(expected):
        def judge(result):
            if not os.path.exists(path):
                return False, t("no file"), t('Open the file with open(path, "a") and write one line.')
            with open(path, encoding="utf-8") as file:
                lines = [line for line in file.read().splitlines() if line.strip()]
            try:
                events = [json.loads(line) for line in lines]
            except ValueError:
                return False, t("a line is not valid JSON"), \
                    t('Write json.dumps(event) and then "\\n", so each event is one line.')
            ok = events == expected
            return ok, t("{count} line(s) in the file", count=len(lines)), \
                None if ok else t('Open with "a" (append) so earlier lines stay, and end each line with "\\n".')
        return judge
    return [_case((path, EVENTS[0]), "append_event(path, event 1)", None, "one line", lines_are(EVENTS[:1])),
            _case((path, EVENTS[1]), "append_event(path, event 2)", None, "two lines: event 1 is kept",
                  lines_are(EVENTS))]


def _read_events(s):
    folder = _temp_folder()
    path = os.path.join(folder, "history.jsonl")
    with open(path, "w", encoding="utf-8") as file:
        file.write(json.dumps(EVENTS[0]) + "\n" + json.dumps(EVENTS[1]) + "\n\n")
    return [_case((os.path.join(folder, "nothing_logged.jsonl"),), "read_events(a file that does not exist)", [],
                  "nothing is logged yet"),
            _case((path,), "read_events(a file with 2 events)", EVENTS, "every event, oldest first")]


CASES = {"pickup_label": _pickup_label, "urgency": _urgency,
         "total_portions": _records_cases("total_portions", 100, 0),
         "open_portions": _records_cases("open_portions", 42, 0),
         "portions_by_category": _records_cases("portions_by_category",
                                                {"bread": 30, "rice meals": 30, "fruit": 40}, {}),
         "find_offer": _find_offer, "clean_offer": _clean_offer, "can_move": _can_move,
         "to_record": _to_record, "from_record": _from_record, "public_row": _public_row,
         "most_urgent_first": _most_urgent_first, "handle_choice": _handle_choice,
         "portions_by_status": _records_cases("portions_by_status",
                                              {"picked_up": 30, "delivered": 18, "rejected": 40, "approved": 12}, {}),
         "save_records": _save_records, "load_records": _load_records,
         "append_event": _append_event, "read_events": _read_events,
         "volunteers_needed": midterm.volunteers_cases, "plan_day": midterm.plan_cases,
         "loan_action": midterm.loan_action_cases, "desk_summary": midterm.desk_summary_cases,
         "most_overdue_id": midterm.most_overdue_id_cases}
INPUTS = {"find_offer": 2, "can_move": 2, "pickup_label": 2, "handle_choice": 2, "save_records": 2,
          "append_event": 2, "loan_action": 3}


def check(name, function=None, settings=None, folder=None, examples=None):
    """Print ✅/❌ for each case. Return True when every case passes.

    bridge.check("clean_offer", folder="my_foodbridge")    the function and settings come from your files
    bridge.check("all", folder="my_foodbridge")            every part in your folder, and tests.py
    bridge.check("shout", shout, examples=[("hi", "HI!")])  your own examples: (input, expected output)
    """
    if examples is not None:
        return check_examples(name, function, examples)
    if name == "all":
        from .folder import FOLDER
        from .parts import check_all
        return check_all(folder or FOLDER)
    if folder is not None and name in CASES:
        from .folder import function_from_folder
        function, folder_settings = function_from_folder(name, folder)
        if function is None:
            return False
        print("📁 " + t("{name} from {folder}/", name=name, folder=folder))
        settings = dict(settings or {}, **folder_settings)
    results, problem = run_cases(name, function, settings)
    if problem:
        print("❌ " + problem)
        return False
    passed = 0
    print(t("Checking {name} …", name=name))
    for case, ok, got, hint in results:
        passed += ok
        line = ("  ✅ " if ok else "  ❌ ") + case["show"] + " → " + got
        if not ok:
            line += "   (" + t(case["why"]) + ")"
            if hint:
                line += "\n     💡 " + hint
        print(line)
    print(t("{passed}/{total} cases passed.", passed=passed, total=len(results)) + (" 🎉" if passed == len(results) else ""))
    return passed == len(results)


def run_cases(name, function, settings=None):
    """Return ([(case, ok, shown, hint)], None), or (None, a problem that stops the check). Prints nothing."""
    if name not in CASES:
        close = difflib.get_close_matches(name, list(CASES), n=1)
        return None, t("I have no check called {name}.", name=repr(name)) + \
            (t(" Did you mean {close}?", close=repr(close[0])) if close else "")
    if not callable(function):
        return None, t("{name} must be a function. Pass its name without ( ), like check('{name}', {name}).", name=name)
    count = INPUTS.get(name, 1)
    if not accepts(function, count):
        return None, t("{name} should take {count} input(s). Check the line that starts with def.",
                       name=name, count=count)
    s = make_settings(settings, quiet=True)
    if name in midterm.NAMES:
        per = (settings or {}).get("PORTIONS_PER_VOLUNTEER", midterm.DEFAULT_PER)
        if midterm.per_problem(per):
            return None, midterm.per_problem(per)
        s["PORTIONS_PER_VOLUNTEER"] = per
    if name in midterm.LIBRARY_NAMES:
        ml = (settings or {}).get("MAX_LATE_DAYS", midterm.DEFAULT_MAX_LATE)
        mr = (settings or {}).get("MAX_RENEWALS", midterm.DEFAULT_MAX_RENEWALS)
        problem = midterm.library_settings_problem(ml, mr)
        if problem:
            return None, problem
        s["MAX_LATE_DAYS"], s["MAX_RENEWALS"] = ml, mr
    try:
        results = []
        for case in CASES[name](s):
            ok, got, hint = _run(name, function, case, s)
            results.append((case, ok, got, hint))
        return results, None
    finally:
        _clean_temp()


def quiet_result(name, function, settings=None):
    """Return (passed, total, first failing case or problem) without printing anything."""
    with contextlib.redirect_stdout(io.StringIO()):
        results, problem = run_cases(name, function, settings)
    if problem:
        return 0, 1, problem
    failing = [case["show"] + " → " + got for case, ok, got, hint in results if not ok]
    return sum(ok for _, ok, _, _ in results), len(results), (failing[0] if failing else None)


def _required_inputs(function):
    try:
        parameters = inspect.signature(function).parameters.values()
    except (TypeError, ValueError):
        return 1
    return len([p for p in parameters if p.default is p.empty and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])


def check_examples(name, function, examples):
    """Check a function against your own examples: a list of (input, expected output).

    With two or more inputs, write them as a tuple: (("bread", 30), "team").
    """
    if not callable(function):
        print("❌ " + t("{name} must be a function. Pass its name without ( ).", name=name))
        return False
    inputs = _required_inputs(function)
    passed = 0
    print(t("Checking {name} …", name=name))
    for given, expect in examples:
        args = tuple(given) if inputs != 1 and isinstance(given, (tuple, list)) else (given,)
        shown = name + "(" + ", ".join(_short(arg) for arg in args) + ")"
        if not accepts(function, len(args)):
            print("  ❌ " + shown + "   💡 " + t("{name} should take {count} input(s). Check the line that starts with def.",
                                                 name=name, count=len(args)))
            continue
        printed = io.StringIO()
        try:
            with contextlib.redirect_stdout(printed):
                result = function(*copy.deepcopy(args))
        except Exception as error:
            hint = _error_hint(error)
            print("  ❌ " + shown + " → " + t("error: {error}", error=type(error).__name__ + ": " + str(error)) +
                  ("\n     💡 " + hint if hint else ""))
            continue
        ok = result == expect or (isinstance(result, float) and isinstance(expect, (int, float))
                                  and not isinstance(expect, bool) and abs(result - expect) < 1e-9)
        passed += ok
        line = ("  ✅ " if ok else "  ❌ ") + shown + " → " + _short(result)
        if not ok:
            line += "   (" + t("expected {value}", value=_short(expect)) + ")"
            hint = _value_hint(result, expect, printed.getvalue())
            if hint and hint != t("Expected {value}.", value=_short(expect)):
                line += "\n     💡 " + hint
        print(line)
    print(t("{passed}/{total} cases passed.", passed=passed, total=len(examples)) + (" 🎉" if passed == len(examples) else ""))
    return passed == len(examples)


def _run(name, function, case, s=None):
    args = copy.deepcopy(case["args"])
    printed = io.StringIO()
    helper = contextlib.nullcontext()
    if name == "plan_day":
        helper = midterm.correct_volunteers(function, s["PORTIONS_PER_VOLUNTEER"])
    elif name == "desk_summary":
        helper = midterm.correct_loan_action(function, s["MAX_LATE_DAYS"], s["MAX_RENEWALS"])
    try:
        with contextlib.redirect_stdout(printed), helper:
            result = function(*args)
    except Exception as error:
        return False, t("error: {error}", error=type(error).__name__ + ": " + str(error)), _error_hint(error)
    if case.get("judge"):
        ok, shown, hint = case["judge"](result)
        if not ok and result is None and printed.getvalue().strip() and hint is None:
            hint = t("Your function printed but returned None. Use return instead of print.")
        return ok, shown, hint
    expect = case["expect"]
    if expect == "input unchanged":
        same = args[0] == case["args"][0]
        return same, t("unchanged") if same else t("the list was changed"), \
            None if same else t("Do not remove, add, sort or edit the records in the list you are given. Build a new list.")
    if name == "volunteers_needed" and isinstance(result, float):
        return False, _short(result), t("Volunteers are whole people. Return an int: use // and %, not /.")
    if name == "clean_offer":
        return _judge_clean(result, expect)
    if name == "from_record":
        same = getattr(result, "to_record", None) and result.to_record() == copy.deepcopy(case["args"][0])
        return bool(same), _short(result), None if same else t("Build an Offer and copy status and partner too.")
    if expect == "any message":
        ok = isinstance(result, str) and result.strip() != ""
        return ok, _short(result), None if ok else t("Return a helpful message for unknown choices.")
    ok = result == expect
    return ok, _short(result), None if ok else _value_hint(result, expect, printed.getvalue())


def _judge_clean(result, expect):
    if not isinstance(result, (tuple, list)) or len(result) != 2:
        return False, _short(result), t("Return two values: return offer, errors")
    offer, errors = result
    if expect == "valid":
        ok = isinstance(offer, dict) and errors == [] and isinstance(offer.get("portions"), int) \
            and isinstance(offer.get("hours_left"), int) and offer.get("donor", "").strip() == offer.get("donor") \
            and offer.get("category", "") == offer.get("category", "").strip().lower()
        hint = None if ok else t("A good row needs offer as a dict (numbers as int, text stripped, category lowercase) and errors == [].")
        return ok, t("offer + {count} error(s)", count=len(errors) if isinstance(errors, list) else "?"), hint
    ok = offer is None and isinstance(errors, list) and len(errors) > 0
    shown = t("refused: {errors}", errors="; ".join(map(str, errors))) if ok else _short(result)
    return ok, shown, None if ok else t("A bad row must return None and at least one clear error message.")


def _value_hint(result, expect, printed):
    if result is None and printed.strip():
        return t("Your function printed but returned None. Use return instead of print.")
    if result is None:
        return t("Your function returned None. Does every branch end with return?")
    if isinstance(result, str) and isinstance(expect, str) and result.strip().lower() == expect.lower():
        return t("Very close! Return exactly {expect} (same spelling, lowercase, no spaces).", expect=repr(expect))
    if isinstance(result, str) and not isinstance(expect, str):
        kind = {"int": "whole number", "float": "number", "list": "list", "dict": "dictionary",
                "bool": "True or False"}.get(type(expect).__name__, type(expect).__name__)
        if expect is None:
            return t("You returned text {result}. Expected a {kind}: None (no answer).", result=repr(result), kind=t(kind))
        return t("You returned text {result}. Expected a {kind}.", result=repr(result), kind=t(kind))
    if isinstance(expect, dict) and isinstance(result, dict):
        if sorted(expect) != sorted(result):
            return t("Expected keys {expected}; you returned keys {got}.", expected=list(expect), got=list(result))
        wrong = [t("{key} (expected {expected}, got {got})", key=key, expected=_short(expect[key]),
                   got=_short(result[key])) for key in expect if result[key] != expect[key]]
        return t("Check {wrong}.", wrong="; ".join(wrong))
    if expect is None:
        return t("Expected None (no answer), for example when nothing is found.")
    return t("Expected {value}.", value=_short(expect))


def _error_hint(error):
    hints = {"TypeError": "Check the types: are you mixing text and numbers, or calling with the wrong inputs?",
             "KeyError": "A dictionary key is missing or misspelled. Keys are case-sensitive.",
             "NameError": "A name is not defined. Run the cell that defines it, or check the spelling.",
             "AttributeError": "That object has no such attribute or method. Check the spelling.",
             "IndexError": "A list position does not exist. Lists start at 0.",
             "FileNotFoundError": "There is no such file. Check os.path.exists(path) first, and return [] when it is missing.",
             "JSONDecodeError": "The file is not valid JSON. Was it written with json.dump, or did you read a blank line?",
             "ZeroDivisionError": "You divided by zero. What should happen when there is nothing to count?"}
    if isinstance(error, NameError) and "____" in str(error):
        return t("Fill in the blank ____ first.")
    hint = hints.get(type(error).__name__)
    return t(hint) if hint else None


def _short(value):
    if callable(value) and hasattr(value, "__name__"):
        return value.__name__          # a function given as an input: show its name, not its memory address
    text = repr(value)
    if isinstance(value, str) and "\n" in value:
        text = repr(value.splitlines()[0] + " …")
    return text if len(text) < 80 else text[:76] + "…"
