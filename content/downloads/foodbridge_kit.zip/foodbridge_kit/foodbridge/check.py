"""Friendly checks for your functions (you do not need to read this file).

    bridge.check("pickup_label", pickup_label, MY_SETTINGS)

prints ✅ or ❌ for each case, explains likely mistakes, and never stops your
notebook with an error. Boundary cases come from YOUR settings, so changing
a decision (for example the team minimum) does not make the check fail.
"""
import contextlib
import copy
import difflib
import io

from . import midterm, models, reports
from .messages import t
from .settings import make_settings
from .system import accepts


def sample_records():
    """Four records in different states, used by several checks (the same offers as the sample day)."""
    hope, riverside, elders = "Hope Children's Centre", "Riverside Community Kitchen", "Old Market Elders' Group"
    rows = [("F001", "Sunrise Bakery", "sunrise@example.org", "Bread rolls", "bread", 30, 5, "picked_up", hope),
            ("F002", "Campus Canteen", "canteen@example.org", "Fried rice boxes", "rice meals", 18, 2, "delivered",
             riverside),
            ("F003", "Green Market Stall", "greenstall@example.org", "Bananas", "fruit", 40, 20, "rejected", ""),
            ("F004", "Lotus Cafe", "lotus@example.org", "Vegetable curry with rice", "rice meals", 12, 4, "approved", elders)]
    result = []
    for offer_id, donor, contact, food, category, portions, hours, status, partner in rows:
        result.append({"id": offer_id, "donor": donor, "contact": contact, "food": food, "category": category,
                       "portions": portions, "hours_left": hours, "status": status, "partner": partner})
    return result


def _case(args, show, expect, why):
    return {"args": args, "show": show, "expect": expect, "why": why}


def _pickup_label(s):
    t = s["TEAM_PICKUP_MIN_PORTIONS"]
    cases = [_case((t - 1, True), "pickup_label(" + str(t - 1) + ", True)", "standard", "one below your team minimum"),
             _case((t, True), "pickup_label(" + str(t) + ", True)", "team", "exactly your team minimum"),
             _case((t + 1, True), "pickup_label(" + str(t + 1) + ", True)", "team", "one above"),
             _case((t, False), "pickup_label(" + str(t) + ", False)", "hold", "not approved yet")]
    return cases + [_case((1, False), "pickup_label(1, False)", "hold", "small and not approved")]


def _urgency(s):
    u, n = s["URGENT_HOURS"], s["SOON_HOURS"]
    cases = [_case((0,), "urgency(0)", "urgent", "no time left"),
             _case((u,), "urgency(" + str(u) + ")", "urgent", "exactly URGENT_HOURS")]
    if u + 1 <= n:
        cases.append(_case((u + 1,), "urgency(" + str(u + 1) + ")", "soon", "one hour more"))
    return cases + [_case((n,), "urgency(" + str(n) + ")", "soon" if n > u else "urgent", "exactly SOON_HOURS"),
                    _case((n + 1,), "urgency(" + str(n + 1) + ")", "later", "beyond SOON_HOURS")]


def _records_cases(function_name, expected_all, expected_empty):
    def build(s):
        return [_case((sample_records(),), function_name + "(4 sample records)", expected_all, "the sample list"),
                _case(([],), function_name + "([])", expected_empty, "an empty list")]
    return build


def _find_offer(s):
    records = sample_records()
    return [_case((records, "F002"), "find_offer(records, 'F002')", records[1], "an ID that exists"),
            _case((records, "F999"), "find_offer(records, 'F999')", None, "an ID that does not exist"),
            _case(([], "F001"), "find_offer([], 'F001')", None, "an empty list")]


def _clean_offer(s):
    good = {"donor": " Sunrise Bakery ", "contact": "sunrise@example.org", "food": "Bread rolls",
            "category": "Bread", "portions": "30", "hours_left": "5"}
    category = s["CATEGORIES"][0]
    good["category"] = " " + category.title() + " "
    low, high, late = s["MIN_PORTIONS"], s["MAX_PORTIONS"], s["REJECT_IF_HOURS_LEFT_BELOW"]
    good["portions"] = str(max(low, min(high, 30)))
    good["hours_left"] = str(late + 4)

    def changed(field, value):
        row = dict(good)
        row[field] = value
        return row
    cases = [_case((good,), "clean_offer(a good row with extra spaces)", "valid", "a correct offer")]
    cases.append(_case((changed("portions", "many"),), "portions = 'many'", "invalid", "not a whole number"))
    cases.append(_case((changed("portions", str(low - 1)),), "portions = " + str(low - 1), "invalid", "below MIN_PORTIONS"))
    cases.append(_case((changed("portions", str(high + 1)),), "portions = " + str(high + 1), "invalid", "above MAX_PORTIONS"))
    cases.append(_case((changed("hours_left", str(late - 1)),), "hours_left = " + str(late - 1), "invalid", "too late to collect"))
    cases.append(_case((changed("category", "spaceship"),), "category = 'spaceship'", "invalid", "not in CATEGORIES"))
    if "donor" in s["REQUIRED_FIELDS"]:
        cases.append(_case((changed("donor", "  "),), "donor = '  '", "invalid", "a required field is blank"))
    return cases


def _can_move(s):
    allowed = models.allowed_moves(s["REQUIRE_APPROVAL"])
    pairs = [("new", "approved"), ("new", "delivered"), ("approved", "picked_up"),
             ("picked_up", "delivered"), ("delivered", "new"), ("rejected", "approved"), ("new", "picked_up"), ("approved", "deliverd")]
    return [_case(p, "can_move(" + repr(p[0]) + ", " + repr(p[1]) + ")", models.can_move(p[0], p[1], allowed),
                  "a status that does not exist" if p[1] == "deliverd" else "follow the lifecycle arrows")
            for p in pairs]


def _to_record(s):
    offer = models.from_record(sample_records()[3])
    return [_case((offer,), "to_record(offer F004)", sample_records()[3], "every field, same values")]


def _from_record(s):
    record = sample_records()[0]
    return [_case((record,), "from_record(record F001)", "same:" + record["id"], "an Offer with the same fields")]


def _public_row(s):
    records = sample_records()
    fields = s["PUBLIC_FIELDS"]
    return [_case((records[0],), "public_row(record F001)", reports.public_row(records[0], fields), "only PUBLIC_FIELDS"),
            _case((records[3],), "public_row(record F004)", reports.public_row(records[3], fields), "only PUBLIC_FIELDS")]


def _most_urgent_first(s):
    return [_case((sample_records(),), "sorted(records, key=most_urgent_first)", ["F002", "F004", "F001", "F003"],
                  "fewest hours left first")]


def _handle_choice(s):
    from .system import System
    system = System(s, quiet=True)
    system.run_day(show=False)
    return [_case(("1", system), "handle_choice('1', system)", system.report("coordinator"), "coordinator view"),
            _case(("2", system), "handle_choice('2', system)", system.report("public"), "public board"),
            _case(("3", system), "handle_choice('3', system)", system.summary_text(), "summary"),
            _case(("4", system), "handle_choice('4', system)", system.history_text(), "history"),
            _case(("q", system), "handle_choice('q', system)", "Goodbye!", "quit"),
            _case(("x", system), "handle_choice('x', system)", "any message", "an unknown choice")]


CASES = {"pickup_label": _pickup_label, "urgency": _urgency,
         "total_portions": _records_cases("total_portions", 100, 0),
         "open_portions": _records_cases("open_portions", 42, 0),
         "portions_by_category": _records_cases("portions_by_category",
                                                {"bread": 30, "rice meals": 30, "fruit": 40}, {}),
         "find_offer": _find_offer, "clean_offer": _clean_offer, "can_move": _can_move,
         "to_record": _to_record, "from_record": _from_record, "public_row": _public_row,
         "most_urgent_first": _most_urgent_first, "handle_choice": _handle_choice,
         "volunteers_needed": midterm.volunteers_cases, "plan_day": midterm.plan_cases}
INPUTS = {"find_offer": 2, "can_move": 2, "pickup_label": 2, "handle_choice": 2}


def check(name, function, settings=None):
    """Print ✅/❌ for each case. Return True when every case passes."""
    if name not in CASES:
        close = difflib.get_close_matches(name, list(CASES), n=1)
        print("❌ " + t("I have no check called {name}.", name=repr(name)) +
              (t(" Did you mean {close}?", close=repr(close[0])) if close else ""))
        return False
    if not callable(function):
        print("❌ " + t("{name} must be a function. Pass its name without ( ), like check('{name}', {name}).", name=name))
        return False
    count = INPUTS.get(name, 1)
    if not accepts(function, count):
        print("❌ " + t("{name} should take {count} input(s). Check the line that starts with def.",
                        name=name, count=count))
        return False
    s = make_settings(settings, quiet=True)
    if name in midterm.NAMES:
        per = (settings or {}).get("PORTIONS_PER_VOLUNTEER", midterm.DEFAULT_PER)
        if midterm.per_problem(per):
            print("❌ " + midterm.per_problem(per))
            return False
        s["PORTIONS_PER_VOLUNTEER"] = per
    cases = CASES[name](s)
    passed = 0
    print(t("Checking {name} …", name=name))
    for case in cases:
        ok, got, hint = _run(name, function, case, s)
        passed += ok
        line = ("  ✅ " if ok else "  ❌ ") + case["show"] + " → " + got
        if not ok:
            line += "   (" + t(case["why"]) + ")"
            if hint:
                line += "\n     💡 " + hint
        print(line)
    print(t("{passed}/{total} cases passed.", passed=passed, total=len(cases)) + (" 🎉" if passed == len(cases) else ""))
    return passed == len(cases)


def _run(name, function, case, s=None):
    args = case["args"] if name == "handle_choice" else copy.deepcopy(case["args"])
    printed = io.StringIO()
    helper = contextlib.nullcontext()
    if name == "plan_day":
        helper = midterm.correct_volunteers(function, s["PORTIONS_PER_VOLUNTEER"])
    try:
        with contextlib.redirect_stdout(printed), helper:
            if name == "most_urgent_first":
                result = [r["id"] for r in sorted(args[0], key=function)]
            else:
                result = function(*args)
    except Exception as error:
        return False, t("error: {error}", error=type(error).__name__ + ": " + str(error)), _error_hint(error)
    expect = case["expect"]
    if expect == "input unchanged":
        same = args[0] == case["args"][0]
        return same, t("unchanged") if same else t("the list was changed"), \
            None if same else t("Do not remove, add or edit offers in the list you are given. Build new values instead.")
    if name == "volunteers_needed" and isinstance(result, float):
        return False, _short(result), t("Volunteers are whole people. Return an int: use // and %, not /.")
    if name == "clean_offer":
        return _judge_clean(result, expect)
    if name == "from_record":
        same = getattr(result, "to_record", None) and result.to_record() == copy.deepcopy(case["args"][0])
        return bool(same), _short(result), None if same else t("Build an Offer and copy status and partner too.")
    if expect == "any message":
        ok = isinstance(result, str) and result.strip() != ""
        return ok, _short(result), None if ok else t("Return a helpful message for unknown choices.")
    ok = result == expect
    return ok, _short(result), None if ok else _value_hint(result, expect, printed.getvalue())


def _judge_clean(result, expect):
    if not isinstance(result, (tuple, list)) or len(result) != 2:
        return False, _short(result), t("Return two values: return offer, errors")
    offer, errors = result
    if expect == "valid":
        ok = isinstance(offer, dict) and errors == [] and isinstance(offer.get("portions"), int) \
            and isinstance(offer.get("hours_left"), int) and offer.get("donor", "").strip() == offer.get("donor") \
            and offer.get("category", "") == offer.get("category", "").strip().lower()
        hint = None if ok else t("A good row needs offer as a dict (numbers as int, text stripped, category lowercase) and errors == [].")
        return ok, t("offer + {count} error(s)", count=len(errors) if isinstance(errors, list) else "?"), hint
    ok = offer is None and isinstance(errors, list) and len(errors) > 0
    shown = t("refused: {errors}", errors="; ".join(map(str, errors))) if ok else _short(result)
    return ok, shown, None if ok else t("A bad row must return None and at least one clear error message.")


def _value_hint(result, expect, printed):
    if result is None and printed.strip():
        return t("Your function printed but returned None. Use return instead of print.")
    if result is None:
        return t("Your function returned None. Does every branch end with return?")
    if isinstance(result, str) and isinstance(expect, str) and result.strip().lower() == expect.lower():
        return t("Very close! Return exactly {expect} (same spelling, lowercase, no spaces).", expect=repr(expect))
    if isinstance(result, str) and not isinstance(expect, str):
        kind = {"int": "whole number", "float": "number", "list": "list", "dict": "dictionary",
                "bool": "True or False"}.get(type(expect).__name__, type(expect).__name__)
        if expect is None:
            return t("You returned text {result}. Expected a {kind}: None (no answer).", result=repr(result), kind=t(kind))
        return t("You returned text {result}. Expected a {kind}.", result=repr(result), kind=t(kind))
    if isinstance(expect, dict) and isinstance(result, dict):
        if sorted(expect) != sorted(result):
            return t("Expected keys {expected}; you returned keys {got}.", expected=list(expect), got=list(result))
        wrong = [t("{key} (expected {expected}, got {got})", key=key, expected=_short(expect[key]),
                   got=_short(result[key])) for key in expect if result[key] != expect[key]]
        return t("Check {wrong}.", wrong="; ".join(wrong))
    if expect is None:
        return t("Expected None (no answer), for example when nothing is found.")
    return t("Expected {value}.", value=_short(expect))


def _error_hint(error):
    hints = {"TypeError": "Check the types: are you mixing text and numbers, or calling with the wrong inputs?",
             "KeyError": "A dictionary key is missing or misspelled. Keys are case-sensitive.",
             "NameError": "A name is not defined. Run the cell that defines it, or check the spelling.",
             "AttributeError": "That object has no such attribute or method. Check the spelling.",
             "IndexError": "A list position does not exist. Lists start at 0."}
    hint = hints.get(type(error).__name__)
    return t(hint) if hint else None


def _short(value):
    text = repr(value)
    if isinstance(value, str) and "\n" in value:
        text = repr(value.splitlines()[0] + " …")
    return text if len(text) < 80 else text[:76] + "…"
