"""Khmer words for the screens and checks (LANGUAGE = "km").

Each key is the English text exactly as the code writes it; each value is what
Khmer screens show. {names} are filled in by the code, so keep them unchanged.
Programming words (function, return, list, dictionary, test, input, error, hook,
setting, ID ...) stay in English, as in the course.
To check that nothing is missing:  python3 tools/km_messages.py
"""

KM_WORDS = {
    "new": "ថ្មី", "approved": "បានអនុម័ត", "picked_up": "បានទៅយក",
    "delivered": "បានប្រគល់", "rejected": "បានបដិសេធ", "cancelled": "បានលុបចោល",
    "hold": "រង់ចាំការអនុម័ត", "team": "ទៅជាក្រុម", "standard": "ធម្មតា",
    "urgent": "បន្ទាន់", "soon": "ឆាប់ៗ", "later": "ពេលក្រោយ",
    "added": "បានបញ្ចូល", "input_rejected": "បដិសេធ input", "moved": "ប្ដូរស្ថានភាព",
}

KM_COLUMNS = {
    "food": "អាហារ", "category": "ប្រភេទ", "portions": "ចំណែក", "hours_left": "ម៉ោងនៅសល់",
    "hours left": "ម៉ោងនៅសល់", "urgency": "ភាពបន្ទាន់", "pickup": "របៀបទៅយក", "status": "ស្ថានភាព",
    "partner": "អង្គការដៃគូ", "donor": "អ្នកបរិច្ចាគ", "contact": "ទំនាក់ទំនង", "action": "សកម្មភាព",
    "step": "ជំហាន", "time": "ពេលវេលា", "event": "ព្រឹត្តិការណ៍", "offer": "សំណើ", "detail": "ព័ត៌មានលម្អិត",
}

KM = {
    # ---- the sample day (demo.py) ------------------------------------------
    "🌅 A day at {name}": "🌅 មួយថ្ងៃនៅ {name}",
    "1) Offers arrive (each row is checked at the door)":
        "1) សំណើផ្ដល់អាហារមកដល់ (ជួរនីមួយៗត្រូវបានពិនិត្យនៅមាត់ទ្វារ)",
    "(no food name)": "(គ្មានឈ្មោះអាហារ)",
    "{id} added: {food}, {portions} portions": "{id} បានបញ្ចូល: {food} {portions} ចំណែក",
    "refused {food}: {errors}": "បានបដិសេធ {food}: {errors}",
    "2) The coordinator decides, then volunteers move the food":
        "2) អ្នកសម្របសម្រួលសម្រេចចិត្ត បន្ទាប់មកអ្នកស្ម័គ្រចិត្តដឹកអាហារ",
    "no cold storage for fruit today": "ថ្ងៃនេះគ្មានកន្លែងទុកត្រជាក់សម្រាប់ផ្លែឈើ",
    "urgent, so it goes first": "បន្ទាន់ ដូច្នេះទៅយកមុនគេ",
    "⏭️ skipped: that offer was refused at the door with your settings":
        "⏭️ រំលង: សំណើនោះត្រូវបានបដិសេធនៅមាត់ទ្វារ ដោយសារ settings របស់អ្នក",
    "3) A mistake the system must refuse: deliver food that was never picked up":
        "3) កំហុសដែលប្រព័ន្ធត្រូវតែបដិសេធ: ប្រគល់អាហារដែលមិនទាន់បានទៅយក",
    "⚠️ accepted (this should not happen!) ": "⚠️ បានទទួលយក (មិនគួរកើតឡើងទេ!) ",
    "🛡️ refused as expected: ": "🛡️ បានបដិសេធ ដូចការរំពឹងទុក: ",
    "4) End of the day": "4) ចុងថ្ងៃ",

    # ---- verify (demo.py) -------------------------------------------------------
    "Kit checks (default settings — these must all pass)":
        "ការពិនិត្យ kit (default settings — ត្រូវតែជាប់ទាំងអស់)",
    "the sample day gives the expected numbers": "ថ្ងៃគំរូផ្ដល់លេខដូចការរំពឹងទុក",
    "food cannot be delivered before pickup": "មិនអាចប្រគល់អាហារ មុនពេលទៅយកបានទេ",
    "bad input is refused and changes nothing": "input មិនត្រឹមត្រូវត្រូវបានបដិសេធ ហើយគ្មានអ្វីប្រែប្រួល",
    "an offer cannot be approved without a partner": "មិនអាចអនុម័តសំណើ ដោយគ្មានអង្គការដៃគូបានទេ",
    "the public board hides contact details": "ក្ដារព័ត៌មានសាធារណៈលាក់ព័ត៌មានទំនាក់ទំនង",
    "saved records load back unchanged": "records ដែលបានរក្សាទុក load មកវិញដោយមិនប្រែប្រួល",
    "default settings are intact": "default settings នៅដដែល",
    "Your system (reported so you can explain it; not pass/fail)":
        "ប្រព័ន្ធរបស់អ្នក (បង្ហាញឱ្យអ្នកពន្យល់បាន មិនមែនជាប់ ឬធ្លាក់ទេ)",
    "all settings are the defaults": "settings ទាំងអស់ជា default",
    "your own {name} is plugged in": "{name} របស់អ្នកត្រូវបានភ្ជាប់ចូលប្រព័ន្ធ",
    "your sample day ran: {count} portions delivered": "ថ្ងៃគំរូរបស់អ្នកដំណើរការបាន: បានប្រគល់ {count} ចំណែក",
    "your sample day stopped: {error}": "ថ្ងៃគំរូរបស់អ្នកបានឈប់: {error}",
    "your {name} fell back to the default: {problem}": "{name} របស់អ្នកមិនដំណើរការ ប្រព័ន្ធបានប្រើ default: {problem}",
    "the public board shows {fields}: is that a deliberate decision?":
        "ក្ដារព័ត៌មានសាធារណៈបង្ហាញ {fields}: តើនេះជាការសម្រេចចិត្តដោយចេតនាឬទេ?",
    "approval is switched off: food can move without a coordinator's decision":
        "ការអនុម័តត្រូវបានបិទ: អាហារអាចផ្លាស់ទីដោយគ្មានការសម្រេចចិត្តពីអ្នកសម្របសម្រួល",
    "✅ Kit is healthy.": "✅ Kit ដំណើរការត្រឹមត្រូវ។",
    "❌ The kit itself is damaged: get a fresh notebook.": "❌ Kit ខ្លួនឯងខូច: សូមយក notebook ថ្មីមួយ។",

    # ---- the System (system.py) ---------------------------------------------------
    "⚠️ Risky setting: REQUIRE_APPROVAL is False, so food can be picked up without a coordinator's approval. "
    "Explain why in your decision log.":
        "⚠️ Setting មានហានិភ័យ: REQUIRE_APPROVAL គឺ False ដូច្នេះអាចទៅយកអាហារ ដោយគ្មានការអនុម័តពីអ្នកសម្របសម្រួល។ "
        "សូមពន្យល់មូលហេតុនៅក្នុងកំណត់ត្រាការសម្រេចចិត្ត (decision log) របស់អ្នក។",
    "⚠️ Not plugged in: {problem}": "⚠️ មិនបានភ្ជាប់ចូល: {problem}",
    "it raised {error}": "វាបាន raise {error}",
    "⚠️ Your {name}{args} did not work: {problem}. The system used the default rule instead.":
        "⚠️ {name}{args} របស់អ្នកមិនដំណើរការ: {problem}។ ប្រព័ន្ធបានប្រើវិធាន default ជំនួសវិញ។",
    "the offer was not accepted.": "សំណើមិនត្រូវបានទទួលយកទេ។",
    "{portions} portions of {food}": "{food} {portions} ចំណែក",
    "There is no offer with ID {id}.": "គ្មានសំណើដែលមាន ID {id} ទេ។",
    "{id} cannot move from {old} to {new}.": "{id} មិនអាចប្ដូរពី {old} ទៅ {new} បានទេ។",
    "Choose a partner first: {partners}.": "សូមជ្រើសរើសអង្គការដៃគូជាមុនសិន: {partners}។",
    " for {partner}": " សម្រាប់ {partner}",
    "not logged": "មិនបានកត់ត្រា",
    "Offers received:        {offers}\nPortions offered:       {portions_offered}\n"
    "Portions still open:    {portions_open}\nPortions picked up:     {portions_picked_up}\n"
    "Portions delivered:     {portions_delivered}\n"
    "Rejected or cancelled:  {rejected_or_cancelled}\n"
    "Inputs refused at door: {inputs_refused}":
        "សំណើដែលបានទទួល: {offers}\n"
        "ចំណែកដែលបានផ្ដល់: {portions_offered}\n"
        "ចំណែកដែលមិនទាន់បញ្ចប់: {portions_open}\n"
        "ចំណែកដែលបានទៅយក: {portions_picked_up}\n"
        "ចំណែកដែលបានប្រគល់: {portions_delivered}\n"
        "បានបដិសេធ ឬលុបចោល: {rejected_or_cancelled}\n"
        "Input ដែលបានបដិសេធនៅមាត់ទ្វារ: {inputs_refused}",
    "(nothing to show)": "(គ្មានអ្វីត្រូវបង្ហាញទេ)",
    "{name} · public board": "{name} · ក្ដារព័ត៌មានសាធារណៈ",
    "{name} · coordinator view (open offers)": "{name} · ទិដ្ឋភាពអ្នកសម្របសម្រួល (សំណើដែលមិនទាន់បញ្ចប់)",
    "(no events logged)": "(មិនទាន់មានព្រឹត្តិការណ៍ដែលបានកត់ត្រាទេ)",
    " Did you mean {close}?": " តើអ្នកចង់សំដៅលើ {close} ឬ?",
    "{name} is not a hook. Hooks: {hooks}.": "{name} មិនមែនជា hook ទេ។ Hooks: {hooks}។",
    "{name} must be a function. Pass its name without ( ).": "{name} ត្រូវតែជា function។ សូមផ្ដល់ឈ្មោះរបស់វា ដោយគ្មាន ( )។",
    "your {name} must take exactly {count} input(s).": "{name} របស់អ្នកត្រូវតែទទួល input ចំនួន {count} គត់។",
    "it returned {result}; expected one of {choices}": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺមួយក្នុងចំណោម {choices}",
    "it returned {result}; expected True or False": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ True ឬ False",
    "it returned {result}; expected a dictionary": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ dictionary",
    "it should return two values: (offer, errors)": "វាគួរតែ return តម្លៃពីរ: (offer, errors)",
    "errors should be a list of messages": "errors គួរតែជា list នៃសារ",
    "with no errors, offer should be a dictionary": "ពេលគ្មាន errors, offer គួរតែជា dictionary",
    "offer[{field}] should be {kind}": "offer[{field}] គួរតែជា {kind}",

    # ---- input checks (validation.py) ---------------------------------------------
    "{field} is required.": "ត្រូវតែបំពេញ {field}។",
    "portions must be a whole number, for example 12.": "portions ត្រូវតែជាចំនួនគត់ ឧទាហរណ៍ 12។",
    "portions must be between {low} and {high}.": "portions ត្រូវតែនៅចន្លោះ {low} និង {high}។",
    "hours_left must be a whole number of hours.": "hours_left ត្រូវតែជាចំនួនម៉ោងគត់។",
    "too late to collect: {hours} hours left, the minimum is {minimum}.":
        "យឺតពេកក្នុងការទៅយក: នៅសល់ {hours} ម៉ោង តែអប្បបរមាគឺ {minimum}។",
    "category must be one of: {categories}.": "category ត្រូវតែជាមួយក្នុងចំណោម: {categories}។",

    # ---- settings (settings.py) -------------------------------------------------------
    "⚠️ Setting ignored: {problem}": "⚠️ Setting មិនត្រូវបានប្រើ: {problem}",
    "⚠️ Setting conflict: {problem}": "⚠️ Settings ផ្ទុយគ្នា: {problem}",
    "{name} is not a known setting.": "{name} មិនមែនជា setting ដែលប្រព័ន្ធស្គាល់ទេ។",
    "{name} must be {expected}, not {actual} ({value}).": "{name} ត្រូវតែជា {expected} មិនមែន {actual} ({value}) ទេ។",
    "{name} must be a list of text values.": "{name} ត្រូវតែជា list នៃ text។",
    "{name} cannot be negative.": "{name} មិនអាចជាលេខអវិជ្ជមានបានទេ។",
    "REPORT_SORT must be one of {choices}.": "REPORT_SORT ត្រូវតែជាមួយក្នុងចំណោម {choices}។",
    "LANGUAGE must be one of {choices}.": "LANGUAGE ត្រូវតែជាមួយក្នុងចំណោម {choices}។",
    "SOON_HOURS is smaller than URGENT_HOURS.": "SOON_HOURS តូចជាង URGENT_HOURS។",
    "MIN_PORTIONS is larger than MAX_PORTIONS.": "MIN_PORTIONS ធំជាង MAX_PORTIONS។",
    "CATEGORIES and PARTNERS need at least one value.": "CATEGORIES និង PARTNERS ត្រូវការតម្លៃយ៉ាងហោចណាស់មួយ។",

    # ---- the text menu (menu.py) -------------------------------------------------------
    "\n1 Coordinator view   2 Public board   3 Summary   4 History\n5 Add an offer       6 Move an offer  q Quit":
        "\n1 ទិដ្ឋភាពអ្នកសម្របសម្រួល   2 ក្ដារព័ត៌មានសាធារណៈ   3 សេចក្ដីសង្ខេប   4 ប្រវត្តិ\n"
        "5 បញ្ចូលសំណើ   6 ប្ដូរស្ថានភាពសំណើ   q ចាកចេញ",
    "Goodbye!": "លាហើយ!",
    "Unknown choice {choice}. Please type 1-6 or q.": "មិនស្គាល់ជម្រើស {choice} ទេ។ សូមវាយ 1-6 ឬ q។",
    "Choose: ": "ជ្រើសរើស: ",
    "✅ Added {id}": "✅ បានបញ្ចូល {id}",
    "🚫 Refused: {errors}": "🚫 បានបដិសេធ: {errors}",
    "  offer ID (e.g. F001): ": "  ID របស់សំណើ (ឧ. F001): ",
    "  new status (approved, rejected, picked_up, delivered, cancelled): ":
        "  status ថ្មី (approved, rejected, picked_up, delivered, cancelled): ",
    "  partner ({partners}): ": "  អង្គការដៃគូ ({partners}): ",

    # ---- files, download, web page ------------------------------------------------
    "Settings changed: {settings} | Your hooks: {hooks}": "Settings ដែលបានប្ដូរ: {settings} | Hooks របស់អ្នក: {hooks}",
    "none": "គ្មាន",
    "✅ Download started: {name}": "✅ ចាប់ផ្ដើមទាញយក: {name}",
    "✅ Saved: {path}": "✅ បានរក្សាទុក: {path}",
    "On your computer: unzip it, open a terminal in foodbridge_kit, run:  python run_web.py":
        "នៅលើកុំព្យូទ័ររបស់អ្នក: unzip វា បើក terminal ក្នុង folder foodbridge_kit រួច run:  python run_web.py",
    "⚠️ Approval is switched off: food can move without a coordinator decision.":
        "⚠️ ការអនុម័តត្រូវបានបិទ: អាហារអាចផ្លាស់ទីដោយគ្មានការសម្រេចចិត្តពីអ្នកសម្របសម្រួល។",
    "Coordinator": "អ្នកសម្របសម្រួល",
    "Public board": "ក្ដារព័ត៌មានសាធារណៈ",
    "History": "ប្រវត្តិ",
    "offers": "សំណើ",
    "portions offered": "ចំណែកដែលបានផ្ដល់",
    "portions open": "ចំណែកមិនទាន់បញ្ចប់",
    "portions picked up": "ចំណែកបានទៅយក",
    "portions delivered": "ចំណែកបានប្រគល់",
    "rejected or cancelled": "បានបដិសេធ ឬលុបចោល",
    "inputs refused": "input ដែលបានបដិសេធ",
    "partner…": "អង្គការដៃគូ…",
    "Move": "ប្ដូរ",
    "Add an offer": "បញ្ចូលសំណើ",
    "Check and add": "ពិនិត្យ ហើយបញ្ចូល",
    "Open offers": "សំណើដែលមិនទាន់បញ្ចប់",
    "Finished offers": "សំណើដែលបានបញ្ចប់",
    "Coordinator view": "ទិដ្ឋភាពអ្នកសម្របសម្រួល",
    "History (newest first)": "ប្រវត្តិ (ថ្មីបំផុតនៅខាងលើ)",
    "Not found": "រកមិនឃើញ",
    "No such page.": "គ្មានទំព័រនេះទេ។",
    "Added {id}": "បានបញ្ចូល {id}",
    "Refused: {errors}": "បានបដិសេធ: {errors}",
    "Unknown action.": "សកម្មភាពដែលមិនស្គាល់។",
    "✅ Web page running. Click the link to open it in a new tab (stop it with bridge.stop_web()).":
        "✅ ទំព័រ web កំពុងដំណើរការ។ ចុច link ដើម្បីបើកវាក្នុង tab ថ្មី (បញ្ឈប់វាដោយ bridge.stop_web())។",
    "✅ Your web page:": "✅ ទំព័រ web របស់អ្នក:",
    "Open the FoodBridge page ↗": "បើកទំព័រ FoodBridge ↗",
    "Open http://localhost:{port}/ in your browser. Press Ctrl+C to stop.":
        "បើក http://localhost:{port}/ ក្នុង browser របស់អ្នក។ ចុច Ctrl+C ដើម្បីបញ្ឈប់។",
    "Stopped.": "បានបញ្ឈប់។",

    # ---- bridge.check (check.py) ------------------------------------------------------------
    "I have no check called {name}.": "គ្មាន check ឈ្មោះ {name} ទេ។",
    "{name} must be a function. Pass its name without ( ), like check('{name}', {name}).":
        "{name} ត្រូវតែជា function។ សូមផ្ដល់ឈ្មោះរបស់វាដោយគ្មាន ( ) ដូចជា check('{name}', {name})។",
    "{name} should take {count} input(s). Check the line that starts with def.":
        "{name} គួរតែទទួល input ចំនួន {count}។ សូមពិនិត្យបន្ទាត់ដែលចាប់ផ្ដើមដោយ def។",
    "Checking {name} …": "កំពុងពិនិត្យ {name} …",
    "{passed}/{total} cases passed.": "ជាប់ {passed}/{total} ករណី។",
    "error: {error}": "error: {error}",
    "unchanged": "មិនប្រែប្រួល",
    "the list was changed": "list ត្រូវបានកែប្រែ",
    "Volunteers are whole people. Return an int: use // and %, not /.":
        "អ្នកស្ម័គ្រចិត្តគឺជាមនុស្សទាំងមូល។ សូម return int: ប្រើ // និង % មិនមែន / ទេ។",
    "Build an Offer and copy status and partner too.": "សូមបង្កើត Offer ហើយចម្លង status និង partner ផងដែរ។",
    "Return a helpful message for unknown choices.": "សូម return សារដែលមានប្រយោជន៍ សម្រាប់ជម្រើសដែលមិនស្គាល់។",
    "Return two values: return offer, errors": "សូម return តម្លៃពីរ: return offer, errors",
    "A good row needs offer as a dict (numbers as int, text stripped, category lowercase) and errors == [].":
        "ជួរត្រឹមត្រូវត្រូវការ offer ជា dict (លេខជា int, text គ្មានដកឃ្លាខាងមុខខាងក្រោយ, category ជាអក្សរតូច) និង errors == []។",
    "offer + {count} error(s)": "offer + error {count}",
    "refused: {errors}": "បានបដិសេធ: {errors}",
    "A bad row must return None and at least one clear error message.":
        "ជួរមិនត្រឹមត្រូវត្រូវតែ return None និងសារ error ច្បាស់លាស់យ៉ាងហោចណាស់មួយ។",
    "Your function printed but returned None. Use return instead of print.":
        "function របស់អ្នកបាន print តែ return None។ សូមប្រើ return ជំនួស print។",
    "Your function returned None. Does every branch end with return?":
        "function របស់អ្នក return None។ តើគ្រប់ branch បញ្ចប់ដោយ return ឬទេ?",
    "Very close! Return exactly {expect} (same spelling, lowercase, no spaces).":
        "ជិតត្រូវហើយ! សូម return {expect} ឱ្យចំ (សរសេរដូចគ្នា អក្សរតូច គ្មានដកឃ្លា)។",
    "You returned text {result}. Expected a {kind}.": "អ្នក return text {result}។ តម្លៃដែលរំពឹងទុកគឺ {kind}។",
    "You returned text {result}. Expected a {kind}: None (no answer).":
        "អ្នក return text {result}។ តម្លៃដែលរំពឹងទុកគឺ {kind}: None (គ្មានចម្លើយ)។",
    "whole number": "ចំនួនគត់ (int)",
    "number": "លេខ",
    "list": "list",
    "dictionary": "dictionary",
    "True or False": "True ឬ False",
    "Expected keys {expected}; you returned keys {got}.": "keys ដែលរំពឹងទុកគឺ {expected}; អ្នក return keys {got}។",
    "{key} (expected {expected}, got {got})": "{key} (រំពឹងទុក {expected} តែបាន {got})",
    "Check {wrong}.": "សូមពិនិត្យ {wrong}។",
    "Expected None (no answer), for example when nothing is found.":
        "រំពឹងទុក None (គ្មានចម្លើយ) ឧទាហរណ៍ ពេលរកមិនឃើញអ្វីសោះ។",
    "Expected {value}.": "រំពឹងទុក {value}។",
    "Check the types: are you mixing text and numbers, or calling with the wrong inputs?":
        "សូមពិនិត្យប្រភេទ (type): តើអ្នកលាយ text ជាមួយលេខ ឬហៅ function ជាមួយ input ខុសឬទេ?",
    "A dictionary key is missing or misspelled. Keys are case-sensitive.":
        "key មួយក្នុង dictionary បាត់ ឬសរសេរខុស។ Keys បែងចែកអក្សរធំ និងអក្សរតូច។",
    "A name is not defined. Run the cell that defines it, or check the spelling.":
        "ឈ្មោះមួយមិនទាន់បានកំណត់ (not defined)។ សូម run cell ដែលកំណត់វា ឬពិនិត្យអក្ខរាវិរុទ្ធ។",
    "That object has no such attribute or method. Check the spelling.":
        "object នោះគ្មាន attribute ឬ method បែបនេះទេ។ សូមពិនិត្យអក្ខរាវិរុទ្ធ។",
    "A list position does not exist. Lists start at 0.": "ទីតាំងនោះមិនមាននៅក្នុង list ទេ។ List ចាប់ផ្ដើមពី 0។",

    # ---- why each case matters (check.py) ---------------------------------------
    "one below your team minimum": "ខ្វះ 1 ទៀត ទើបដល់ចំនួនអប្បបរមាសម្រាប់ក្រុមរបស់អ្នក",
    "exactly your team minimum": "ស្មើនឹងចំនួនអប្បបរមាសម្រាប់ក្រុមរបស់អ្នក",
    "one above": "លើសចំនួនអប្បបរមា 1",
    "not approved yet": "មិនទាន់អនុម័ត",
    "small and not approved": "តិច ហើយមិនទាន់អនុម័ត",
    "no time left": "គ្មានពេលនៅសល់",
    "exactly URGENT_HOURS": "ស្មើនឹង URGENT_HOURS",
    "one hour more": "លើស URGENT_HOURS 1 ម៉ោង",
    "exactly SOON_HOURS": "ស្មើនឹង SOON_HOURS",
    "beyond SOON_HOURS": "លើស SOON_HOURS",
    "the sample list": "list គំរូ",
    "an empty list": "list ទទេ",
    "an ID that exists": "ID ដែលមាន",
    "an ID that does not exist": "ID ដែលមិនមាន",
    "a correct offer": "សំណើត្រឹមត្រូវ",
    "not a whole number": "មិនមែនជាចំនួនគត់",
    "below MIN_PORTIONS": "តិចជាង MIN_PORTIONS",
    "above MAX_PORTIONS": "លើស MAX_PORTIONS",
    "too late to collect": "យឺតពេកក្នុងការទៅយក",
    "not in CATEGORIES": "មិននៅក្នុង CATEGORIES",
    "a required field is blank": "field ដែលត្រូវតែបំពេញនៅទទេ",
    "a status that does not exist": "status ដែលមិនមាន",
    "follow the lifecycle arrows": "ធ្វើតាមព្រួញនៃ lifecycle",
    "every field, same values": "គ្រប់ field តម្លៃដូចគ្នា",
    "an Offer with the same fields": "Offer ដែលមាន fields ដូចគ្នា",
    "only PUBLIC_FIELDS": "តែ PUBLIC_FIELDS ប៉ុណ្ណោះ",
    "fewest hours left first": "ម៉ោងនៅសល់តិចបំផុតមុនគេ",
    "history": "ប្រវត្តិ",
    "an unknown choice": "ជម្រើសដែលមិនស្គាល់",

    # ---- the midterm (midterm.py) ---------------------------------------------------
    "PORTIONS_PER_VOLUNTEER must be a whole number of portions, 1 or more (you have {value}).":
        "PORTIONS_PER_VOLUNTEER ត្រូវតែជាចំនួនគត់នៃចំណែក ចាប់ពី 1 ឡើងទៅ (អ្នកមាន {value})។",
    "no portions, no volunteers": "គ្មានចំណែក គ្មានអ្នកស្ម័គ្រចិត្ត",
    "one portion still needs a volunteer": "ចំណែកមួយក៏ត្រូវការអ្នកស្ម័គ្រចិត្តម្នាក់ដែរ",
    "one below a full load": "ខ្វះ 1 ចំណែក ទើបពេញបន្ទុកមួយ",
    "exactly one full load": "ពេញបន្ទុកមួយគត់",
    "one portion more than a full load": "លើសបន្ទុកពេញមួយ 1 ចំណែក",
    "exactly two full loads": "ពេញបន្ទុកពីរគត់",
    "one more than two loads": "លើសបន្ទុកពេញពីរ 1 ចំណែក",
    "approved offers only; IDs of waiting offers": "តែសំណើដែលបានអនុម័ត; ID នៃសំណើដែលកំពុងរង់ចាំ",
    "nothing approved yet": "មិនទាន់មានអ្វីត្រូវបានអនុម័តទេ",
    "plan_day must not change the list it is given": "plan_day មិនត្រូវកែប្រែ list ដែលគេឱ្យវាទេ",
    "rounds down (2 full loads + 1 portion → 2 volunteers)": "បង្គត់ចុះ (បន្ទុកពេញ 2 + 1 ចំណែក → អ្នកស្ម័គ្រចិត្ត 2 នាក់)",
    "a normal case that is not an exact multiple": "ករណីធម្មតាដែលមិនមែនជាពហុគុណគត់",
    "one volunteer too many at an exact full load": "អ្នកស្ម័គ្រចិត្តលើស 1 នាក់ ពេលចំណែកពេញបន្ទុកគត់",
    "a boundary case: exactly PORTIONS_PER_VOLUNTEER portions": "ករណីព្រំដែន (boundary case): ចំណែកស្មើនឹង PORTIONS_PER_VOLUNTEER គត់",
    "counts portions of offers that are not approved": "រាប់ចំណែកនៃសំណើដែលមិនទាន់អនុម័ត",
    "checking approved_portions when one offer is not approved": "ពិនិត្យ approved_portions ពេលមានសំណើមួយមិនទាន់អនុម័ត",
    "returns None for an empty list": "return None សម្រាប់ list ទទេ",
    "plan_day([])": "plan_day([])",
    "assert failed": "assert មិនជាប់",
    "Give a list of your test functions without ( ), like catch_bugs([test_normal, test_empty]).":
        "សូមផ្ដល់ list នៃ test functions របស់អ្នក ដោយគ្មាន ( ) ដូចជា catch_bugs([test_normal, test_empty])។",
    "Run the cells that define {names} first.": "សូម run cells ដែលកំណត់ {names} ជាមុនសិន។",
    "1) Your tests on your own code": "1) តេស្ត (tests) របស់អ្នក លើកូដរបស់អ្នកផ្ទាល់",
    "A failing test means the test or the function is wrong. Find out which before you go on.":
        "តេស្ត (test) ដែលធ្លាក់មានន័យថា តេស្ត ឬ function ខុស។ សូមរកឱ្យឃើញថាមួយណាខុស មុននឹងបន្ត។",
    "{names} passed even with no working code. Does it really check something?":
        "{names} ជាប់ ទោះបីគ្មានកូដដែលដំណើរការក៏ដោយ។ តើវាពិតជាពិនិត្យអ្វីមួយឬទេ?",
    "2) Your tests against planted bugs": "2) តេស្ត (tests) របស់អ្នក ទល់នឹងកំហុស (bugs) ដែលបានដាក់ទុក",
    "Bug {number} · {story}: ✅ caught by {tests}": "Bug {number} · {story}: ✅ ចាប់បានដោយ {tests}",
    "Bug {number} · {story}: ❌ not caught. 💡 Try {idea}.": "Bug {number} · {story}: ❌ មិនទាន់ចាប់បាន។ 💡 សាកល្បង {idea}។",
    "{caught}/{total} bugs caught.": "ចាប់បានកំហុស (bugs) {caught}/{total}។",
    "3) Your code and tests with a different decision (PORTIONS_PER_VOLUNTEER = {other})":
        "3) កូដ និងតេស្តរបស់អ្នក ជាមួយការសម្រេចចិត្តផ្សេង (PORTIONS_PER_VOLUNTEER = {other})",
    "{names} fail(s) when the number changes. A raw number may be hidden in your function or your test. "
    "Use PORTIONS_PER_VOLUNTEER instead (see Part F).":
        "{names} ធ្លាក់ ពេលលេខប្រែប្រួល។ ប្រហែលជាមានលេខផ្ទាល់ (magic number) លាក់នៅក្នុង function ឬតេស្តរបស់អ្នក។ "
        "សូមប្រើ PORTIONS_PER_VOLUNTEER ជំនួសវិញ (មើលផ្នែក F)។",
    "Your code and tests follow the constant: no hidden magic numbers.":
        "កូដ និងតេស្តរបស់អ្នកប្រើតម្លៃថេរ (constant): គ្មានលេខដែលសរសេរផ្ទាល់ (magic numbers) លាក់ទុកទេ។",
    # ---- your system folder (folder.py) — AI draft, waiting for review ----------------
    "{file}, line {line}: Python cannot read this line ({error}).":
        "{file} បន្ទាត់ទី {line}: Python មិនអាចអានបន្ទាត់នេះបានទេ ({error})។",
    "{file}, line {line}: {error}": "{file} បន្ទាត់ទី {line}: {error}",
    "{file}: {name} is not a setting. Did you mean {close}?":
        "{file}: {name} មិនមែនជា setting ទេ។ តើអ្នកចង់សំដៅលើ {close} ឬ?",
    "There is no folder {folder}/ yet. Run bridge.my_folder() first.":
        "មិនទាន់មាន folder {folder}/ នៅឡើយទេ។ សូម run bridge.my_folder() ជាមុនសិន។",
    "No function called {name} in {folder}/. Run the %%writefile cell again, and check the name after def.":
        "រកមិនឃើញ function ឈ្មោះ {name} នៅក្នុង {folder}/ ទេ។ សូម run cell %%writefile ម្ដងទៀត "
        "ហើយពិនិត្យឈ្មោះនៅក្រោយ def។",
    "(new, empty folder)": "(folder ថ្មី មិនទាន់មានអ្វីទេ)",
    "No files yet. A %%writefile cell saves a file here.":
        "មិនទាន់មាន file នៅឡើយទេ។ cell %%writefile នឹងរក្សាទុក file នៅទីនេះ។",
    "functions: {names}": "function: {names}",
    "settings: {names}": "setting: {names}",
    "(nothing the system uses yet)": "(មិនទាន់មានអ្វីដែលប្រព័ន្ធប្រើនៅឡើយទេ)",
    "Parts of the system:": "ផ្នែកនៃប្រព័ន្ធ:",
    "yours, from {file}": "របស់អ្នក ពី {file}",
    "the kit's version": "កំណែរបស់ kit",
    "printed:": "បាន print:",
    "{name} from {folder}/": "{name} ពី {folder}/",
    # ---- code puzzles (puzzles.py) — AI draft, waiting for review ---------------------
    "I have no puzzle called {name}.": "គ្មានល្បែងផ្គុំកូដ (code puzzle) ឈ្មោះ {name} ទេ។",
    "Code puzzle": "ល្បែងផ្គុំកូដ (code puzzle)",
    "Subgoal: {subgoal}": "គោលដៅរង (subgoal): {subgoal}",
    "The lines are shuffled, and one of them does not belong:":
        "បន្ទាត់ត្រូវបានរៀបមិនតាមលំដាប់ ហើយមានមួយបន្ទាត់ដែលមិនមែនជារបស់កូដនេះ:",
    "Write the letters in the right order. In Colab you can click the lines instead.":
        "សូមសរសេរអក្សរតាមលំដាប់ត្រឹមត្រូវ។ នៅក្នុង Colab អ្នកអាចចុចលើបន្ទាត់ជំនួសវិញ។",
    "Not finished yet: {count} more line(s) to place.": "មិនទាន់រួចទេ: នៅសល់ {count} បន្ទាត់ទៀតដែលត្រូវដាក់។",
    "Line {number} is not in the right place yet.": "បន្ទាត់ទី {number} មិនទាន់នៅកន្លែងត្រឹមត្រូវទេ។",
    "This line does not belong:": "បន្ទាត់នេះមិនមែនជារបស់កូដនេះទេ:",
    "Lines (shuffled · one of them does not belong)": "បន្ទាត់ (រៀបមិនតាមលំដាប់ · មានមួយមិនត្រូវប្រើ)",
    "Your code (click a line to take it back)": "កូដរបស់អ្នក (ចុចលើបន្ទាត់ ដើម្បីដកវាចេញវិញ)",
    "Click the lines in the order the code needs them.": "សូមចុចលើបន្ទាត់ តាមលំដាប់ដែលកូដត្រូវការ។",
    "Check": "ពិនិត្យ",
    "Start again": "ចាប់ផ្ដើមម្ដងទៀត",
    "Build check_category(raw, errors)": "បង្កើត check_category(raw, errors)",
    "clean, then compare": "សម្អាតសិន រួចប្រៀបធៀប",
    'Tidy the category first, then compare it with CATEGORIES. A blank category adds '
    '"category is required."; an unknown one adds the list of allowed categories. '
    'Return the tidy category.':
        'សម្អាត category ជាមុនសិន រួចប្រៀបធៀបវាជាមួយ CATEGORIES។ បើ category ទទេ ត្រូវបន្ថែម '
        '"category is required."; បើមិនស្គាល់ ត្រូវបន្ថែមបញ្ជី category ដែលអនុញ្ញាត។ '
        'សូម return category ដែលបានសម្អាតរួច។',
    'raw["category"] stops with a KeyError when the key is missing, and it does not tidy '
    'the text, so " Bread " would never match "bread".':
        'raw["category"] គាំងដោយ KeyError ពេលគ្មាន key នោះ ហើយវាមិនសម្អាត text ទេ '
        'ដូច្នេះ " Bread " នឹងមិនដែលត្រូវនឹង "bread" ឡើយ។',
    "Correct: clean, then compare. The tidy text is what you compare, a blank category "
    "gets one message, and an unknown one gets the list of allowed categories.":
        "ត្រឹមត្រូវ: សម្អាតសិន រួចប្រៀបធៀប។ អ្នកប្រៀបធៀប text ដែលបានសម្អាតរួច "
        "category ទទេទទួលបានសារមួយ ហើយ category ដែលមិនស្គាល់ទទួលបានបញ្ជី category ដែលអនុញ្ញាត។",
    # ---- Weeks 4–10: checks of the new parts (check.py) — AI draft, waiting for review ----
    "Fill in the blank ____ first.": "សូមបំពេញចន្លោះ ____ ជាមុនសិន។",
    "Return the new list: return sorted(records, key=your_key_function).":
        "សូម return list ថ្មី: return sorted(records, key=your_key_function)។",
    "Return a list of records (dictionaries), not {kind}.": "សូម return list នៃ records (dictionaries) មិនមែន {kind} ទេ។",
    "Expected the order {expected}.": "លំដាប់ដែលរំពឹងទុកគឺ {expected}។",
    "Return the text to show (a str), not print it.": "សូម return text ដែលត្រូវបង្ហាញ (str) កុំ print វា។",
    "Show them in this order: {words}.": "សូមបង្ហាញវាតាមលំដាប់នេះ: {words}។",
    "The text should include {words}.": "text គួរតែមាន {words}។",
    "The text should not include {words}.": "text មិនគួរមាន {words} ទេ។",
    "Do not remove, add, sort or edit the records in the list you are given. Build a new list.":
        "កុំលុប បន្ថែម តម្រៀប (sort) ឬកែ records នៅក្នុង list ដែលគេឱ្យអ្នក។ សូមបង្កើត list ថ្មីវិញ។",
    "expected {value}": "រំពឹងទុក {value}",
    "no file": "គ្មាន file",
    "{count} records in the file": "មាន records {count} នៅក្នុង file",
    "{count} line(s) in the file": "មាន {count} បន្ទាត់នៅក្នុង file",
    "the file is not valid JSON": "file នេះមិនមែនជា JSON ត្រឹមត្រូវទេ",
    "a line is not valid JSON": "មានបន្ទាត់មួយមិនមែនជា JSON ត្រឹមត្រូវទេ",
    'Write to a temporary file with open(path + ".tmp", "w") and json.dump, then os.replace(path + ".tmp", path).':
        'សូមសរសេរទៅ file បណ្ដោះអាសន្នដោយ open(path + ".tmp", "w") និង json.dump រួចប្រើ os.replace(path + ".tmp", path)។',
    "The file should hold exactly the list you saved.": "file គួរតែមានដូច list ដែលអ្នកបានរក្សាទុកបេះបិទ។",
    'Use "w" (write), not "a" (append), and json.dump(records, file).':
        'សូមប្រើ "w" (write) មិនមែន "a" (append) ទេ ហើយប្រើ json.dump(records, file)។',
    'Open the file with open(path, "a") and write one line.':
        'សូមបើក file ដោយ open(path, "a") ហើយសរសេរមួយបន្ទាត់។',
    'Open with "a" (append) so earlier lines stay, and end each line with "\\n".':
        'សូមបើកដោយ "a" (append) ដើម្បីឱ្យបន្ទាត់មុនៗនៅដដែល ហើយបញ្ចប់បន្ទាត់នីមួយៗដោយ "\\n"។',
    'Write json.dumps(event) and then "\\n", so each event is one line.':
        'សូមសរសេរ json.dumps(event) រួចបន្ថែម "\\n" ដើម្បីឱ្យ event នីមួយៗនៅលើមួយបន្ទាត់។',
    "Open means new, approved or picked up.": "មិនទាន់បញ្ចប់ (open) មានន័យថា ថ្មី បានអនុម័ត ឬបានទៅយក។",
    "build a new list; do not sort in place": "បង្កើត list ថ្មី; កុំតម្រៀប (sort) list ដើម",
    "open offers, most urgent first": "សំណើដែលមិនទាន់បញ្ចប់ បន្ទាន់បំផុតមុនគេ",
    "portions offered and still open": "ចំណែកដែលបានផ្ដល់ និងចំណែកដែលមិនទាន់បញ្ចប់",
    "the public board": "ក្ដារព័ត៌មានសាធារណៈ",
    "it returned {result}; expected a whole number": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺចំនួនគត់ (int)",
    "it returned {result}; expected a list": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ list",
    "it returned {result}; expected a list of records": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ list នៃ records",
    "{folder}/ · your parts in use: {parts}": "{folder}/ · ផ្នែករបស់អ្នកដែលកំពុងប្រើ: {parts}",
    "none yet": "មិនទាន់មាន",

    # ---- your folder in Google Drive (folder.py) — AI draft, waiting for review ----------
    "Your folder {folder}/ is kept in your Google Drive (MyDrive/{folder}), so it is still here next week.":
        "folder {folder}/ របស់អ្នកត្រូវបានរក្សាទុកក្នុង Google Drive (MyDrive/{folder}) ដូច្នេះសប្ដាហ៍ក្រោយវានៅតែមាន។",
    "Your folder {folder}/ is next to this notebook.": "folder {folder}/ របស់អ្នកនៅជាប់នឹង notebook នេះ។",
    "Google Drive is not connected, so {folder}/ is lost when this runtime stops. Run this cell again to connect it.":
        "Google Drive មិនទាន់បានភ្ជាប់ទេ ដូច្នេះ {folder}/ នឹងបាត់ពេល runtime នេះឈប់។ សូម run cell នេះម្ដងទៀត ដើម្បីភ្ជាប់វា។",

    # ---- the parts of your system (parts.py) — AI draft, waiting for review --------------
    "Copied the model version of {files} into {folder}/ (they were missing).":
        "បានចម្លងកំណែគំរូ (model version) នៃ {files} ទៅក្នុង {folder}/ (ព្រោះវាមិនទាន់មាន)។",
    "No gaps: every Week 4–8 file is already in {folder}/.": "គ្មានអ្វីខ្វះទេ: គ្រប់ file នៃសប្ដាហ៍ទី 4–8 មាននៅក្នុង {folder}/ ហើយ។",
    "Checking everything in {folder}/ …": "កំពុងពិនិត្យអ្វីៗទាំងអស់នៅក្នុង {folder}/ …",
    "{passed}/{total} cases": "{passed}/{total} ករណី",
    "the model version, copied by the kit (not yours yet)": "កំណែគំរូ ដែល kit បានចម្លងឱ្យ (មិនទាន់ជារបស់អ្នកទេ)",
    "run bridge.check({name}, folder={folder}) to see why": "សូម run bridge.check({name}, folder={folder}) ដើម្បីមើលមូលហេតុ",
    "not written (the model version is used)": "មិនទាន់សរសេរ (កំពុងប្រើកំណែគំរូ)",
    "Your tests ({count}):": "តេស្ត (tests) របស់អ្នក ({count}):",
    "Your decisions (settings that differ from the defaults): {count}":
        "ការសម្រេចចិត្តរបស់អ្នក (settings ដែលខុសពីតម្លៃលំនាំដើម): {count}",
    "default {value}": "លំនាំដើម {value}",
    "{yours} of {total} parts are yours.": "ផ្នែកចំនួន {yours} ក្នុងចំណោម {total} ជារបស់អ្នក។",
    "a test function takes no inputs": "test function មិនទទួល input ទេ",
    "an assert failed": "assert មួយមិនជាប់",

    # ---- the pictures of your system (show.py) — AI draft, waiting for review ------------
    "There is no view called {view}. Views: {views}.": "គ្មាន view ឈ្មោះ {view} ទេ។ Views ដែលមាន: {views}។",
    "Week {week}": "សប្ដាហ៍ទី {week}",
    "Week 10": "សប្ដាហ៍ទី 10",
    "yours ({file})": "របស់អ្នក ({file})",
    "yours · {passed}/{total} cases": "របស់អ្នក · {passed}/{total} ករណី",
    "yours in {file} needs work ({passed}/{total} cases), so the model version is used":
        "របស់អ្នកនៅក្នុង {file} ត្រូវកែបន្ថែម ({passed}/{total} ករណី) ដូច្នេះកំពុងប្រើកំណែគំរូ",
    "needs work · {passed}/{total} cases · model version in use": "ត្រូវកែបន្ថែម · {passed}/{total} ករណី · កំពុងប្រើកំណែគំរូ",
    "not written yet · model version in use": "មិនទាន់សរសេរ · កំពុងប្រើកំណែគំរូ",
    "model version": "កំណែគំរូ",
    "model version (you write it in Week {week})": "កំណែគំរូ (អ្នកនឹងសរសេរវានៅសប្ដាហ៍ទី {week})",
    "model version copied into {file} (not yours yet)": "កំណែគំរូដែលបានចម្លងទៅក្នុង {file} (មិនទាន់ជារបស់អ្នកទេ)",
    "model version copied by the kit · not yours yet": "កំណែគំរូដែល kit បានចម្លងឱ្យ · មិនទាន់ជារបស់អ្នកទេ",
    "{folder}/ · {yours} of {total} parts are yours": "{folder}/ · ផ្នែកចំនួន {yours} ក្នុងចំណោម {total} ជារបស់អ្នក",
    "✅ yours · 🔧 needs work · ⬜ not written yet · 📦 copied model version. The model version runs every part that is not yours yet.":
        "✅ របស់អ្នក · 🔧 ត្រូវកែបន្ថែម · ⬜ មិនទាន់សរសេរ · 📦 កំណែគំរូដែលបានចម្លង។ "
        "កំណែគំរូ (model version) ដំណើរការគ្រប់ផ្នែកដែលមិនទាន់ជារបស់អ្នក។",
    "   (the model version runs every part that is not yours yet)": "   (កំណែគំរូដំណើរការគ្រប់ផ្នែកដែលមិនទាន់ជារបស់អ្នក)",
    "Parts used:": "ផ្នែកដែលបានប្រើ:",
    "Your decisions:": "ការសម្រេចចិត្តរបស់អ្នក:",
    "To see what needs work, run": "ដើម្បីមើលថាអ្វីត្រូវកែបន្ថែម សូម run",
    "{name} was not written.": "{name} មិនទាន់បានសរសេរទេ។",
    "nothing": "គ្មានអ្វីទេ",
    "offers.csv through your door: {summary}": "offers.csv ឆ្លងកាត់មាត់ទ្វាររបស់អ្នក: {summary}",
    "{accepted} accepted · {refused} refused at the door": "បានទទួល {accepted} · បានបដិសេធនៅមាត់ទ្វារ {refused}",
    "{count} made your function stop with an error": "{count} បានធ្វើឱ្យ function របស់អ្នកគាំងដោយ error",
    "Every value in a CSV file arrives as text. Green rows are accepted with tidy values; red rows are refused, and the red cells are the ones your messages name.":
        "តម្លៃនីមួយៗក្នុង file CSV មកដល់ជា text។ ជួរពណ៌បៃតងត្រូវបានទទួល ជាមួយតម្លៃដែលបានសម្អាតរួច; "
        "ជួរពណ៌ក្រហមត្រូវបានបដិសេធ ហើយក្រឡាពណ៌ក្រហមគឺជាក្រឡាដែលសាររបស់អ្នកនិយាយដល់។",
    "accepted": "បានទទួល",
    "refused": "បានបដិសេធ",
    "The lifecycle your can_move allows": "lifecycle ដែល can_move របស់អ្នកអនុញ្ញាត",
    "Grey arrows: the usual lifecycle · orange: your decision · blue: a state you added · red dashes: unusual · dotted: missing.":
        "ព្រួញពណ៌ប្រផេះ: lifecycle ធម្មតា · ពណ៌ទឹកក្រូច: ការសម្រេចចិត្តរបស់អ្នក · ពណ៌ខៀវ: ស្ថានភាព (state) ដែលអ្នកបានបន្ថែម · "
        "ដាច់ៗពណ៌ក្រហម: មិនធម្មតា · ចំណុចៗ: បាត់។",
    "An offer that is {status} can move to:": "សំណើដែលមានស្ថានភាព {status} អាចប្ដូរទៅ:",
    "{status} is not a status in this lifecycle.": "{status} មិនមែនជា status នៅក្នុង lifecycle នេះទេ។",
    "moves:": "ការប្ដូរ:",
    "your decision": "ការសម្រេចចិត្តរបស់អ្នក",
    "unusual?": "មិនធម្មតា?",
    "missing?": "បាត់?",
    "can_move({old}, {new}) stopped with {error}": "can_move({old}, {new}) បានគាំងដោយ {error}",
    "Missing: {old} → {new}. Without it, an offer can get stuck.": "បាត់: {old} → {new}។ បើគ្មានវា សំណើអាចជាប់គាំង។",
    "Unusual: {old} → {new}. Should this ever happen?": "មិនធម្មតា: {old} → {new}។ តើរឿងនេះគួរកើតឡើងឬទេ?",
    "Your decision: {old} → {new} (no approval). Explain it in your decision log.":
        "ការសម្រេចចិត្តរបស់អ្នក: {old} → {new} (គ្មានការអនុម័ត)។ សូមពន្យល់វានៅក្នុង decision log របស់អ្នក។",
    "Your new state: {old} → {new}. Add a test for it.": "ស្ថានភាព (state) ថ្មីរបស់អ្នក: {old} → {new}។ សូមបន្ថែមតេស្ត (test) សម្រាប់វា។",
    "The sample day, saved with your storage.py": "ថ្ងៃគំរូ ដែលបានរក្សាទុកដោយ storage.py របស់អ្នក",
    "The files are in {folder}. They are made again each time you run this cell.":
        "files នៅក្នុង {folder}។ វាត្រូវបានបង្កើតឡើងវិញរាល់ពេលអ្នក run cell នេះ។",
    "{count} lines": "{count} បន្ទាត់",
    "{count} lines · {size} bytes": "{count} បន្ទាត់ · {size} bytes",
    "The history, read back after a restart": "ប្រវត្តិ ដែលបានអានមកវិញ បន្ទាប់ពីចាប់ផ្ដើមឡើងវិញ (restart)",
    "history after a restart: {count} events": "ប្រវត្តិបន្ទាប់ពីចាប់ផ្ដើមឡើងវិញ: events {count}",
    "Restart test: a new system loaded the saved file and got the same {count} records back.":
        "តេស្តចាប់ផ្ដើមឡើងវិញ (restart test): ប្រព័ន្ធថ្មីបាន load file ដែលបានរក្សាទុក ហើយទទួលបាន records {count} ដដែលមកវិញ។",
    "Restart test: after loading the saved file, the records were different. Check load_records.":
        "តេស្តចាប់ផ្ដើមឡើងវិញ (restart test): ក្រោយពី load file ដែលបានរក្សាទុក records បានខុសពីមុន។ សូមពិនិត្យ load_records។",
    "Coordinator view and public board": "ទិដ្ឋភាពអ្នកសម្របសម្រួល និងក្ដារព័ត៌មានសាធារណៈ",
    "Coordinator view (all records)": "ទិដ្ឋភាពអ្នកសម្របសម្រួល (records ទាំងអស់)",
    "Hidden from the public: {fields}": "លាក់ពីសាធារណៈ: {fields}",
    "The public board shows {fields}. Is that safe for the donors and partners?":
        "ក្ដារព័ត៌មានសាធារណៈបង្ហាញ {fields}។ តើវាមានសុវត្ថិភាពសម្រាប់អ្នកបរិច្ចាគ និងអង្គការដៃគូឬទេ?",
    "Portions offered": "ចំណែកដែលបានផ្ដល់",
    "portions": "ចំណែក",
    "still open": "មិនទាន់បញ្ចប់",
    "picked up": "បានទៅយក",
    "delivered": "បានប្រគល់",
    "Portions by status (your portions_by_status)": "ចំណែកតាម status (portions_by_status របស់អ្នក)",
    "Different measures: never add them together.": "រង្វាស់ខុសគ្នា: កុំបូកវាបញ្ចូលគ្នា។",
    "Your app, run with the script {script}": "app របស់អ្នក ដែល run ជាមួយ script {script}",
    'This runs your handle_choice with a script. Open the live web page with bridge.start_web(folder="{folder}"), '
    'or try the text menu with !cd {folder} && python app.py':
        'នេះ run handle_choice របស់អ្នកជាមួយ script មួយ។ បើកទំព័រ web ផ្ទាល់ដោយ bridge.start_web(folder="{folder}") '
        'ឬសាកល្បង menu ជាអក្សរដោយ !cd {folder} && python app.py',
    "{count} test function(s)": "test function {count}",
    "Your screen": "អេក្រង់របស់អ្នក",
    "Your screen (from screen.py)": "អេក្រង់របស់អ្នក (ពី screen.py)",
    "No make_page(records) yet. It goes in {folder}/screen.py (Final project Level 4, optional).":
        "មិនទាន់មាន make_page(records) នៅឡើយទេ។ វាត្រូវដាក់នៅក្នុង {folder}/screen.py (Final project កម្រិតទី 4 ជាជម្រើស)។",
    "make_page should return the page as text (a str), not {kind}.": "make_page គួរតែ return ទំព័រជា text (str) មិនមែន {kind} ទេ។",

    # ---- code puzzles, Week 4 (puzzle_bank/week_04.py) — AI draft, waiting for review ----
    "Build open_portions(records)": "បង្កើត open_portions(records)",
    "start at zero, add only the open ones, return": "ចាប់ផ្ដើមពីសូន្យ បូកតែសំណើដែលមិនទាន់បញ្ចប់ រួច return",
    "Add up the portions of the offers that are still open (status new, approved or picked_up). Return the total.":
        "បូកចំណែកនៃសំណើដែលមិនទាន់បញ្ចប់ (status new, approved ឬ picked_up)។ សូម return ផលបូកសរុប។",
    "print shows the total on the screen but gives nothing back, so the system cannot use it. "
    "A function you can trust returns its answer.":
        "print បង្ហាញផលបូកលើអេក្រង់ តែមិនផ្ដល់អ្វីមកវិញទេ ដូច្នេះប្រព័ន្ធមិនអាចប្រើវាបានទេ។ "
        "function ដែលគួរឱ្យទុកចិត្ត return ចម្លើយរបស់វា។",
    "Correct: start at zero, add only the open offers, and return the total after the loop.":
        "ត្រឹមត្រូវ: ចាប់ផ្ដើមពីសូន្យ បូកតែសំណើដែលមិនទាន់បញ្ចប់ ហើយ return ផលបូកសរុបបន្ទាប់ពី loop។",
    "Not kept in your history (LOG_EVENTS): {kinds}. Which question can nobody answer now?":
        "មិនត្រូវបានរក្សាទុកក្នុងប្រវត្តិរបស់អ្នក (LOG_EVENTS): {kinds}។ តើសំណួរណាដែលគ្មាននរណាអាចឆ្លើយបានឥឡូវនេះ?",
    "yours in {file} needs work ({passed}/{total} cases). This picture shows what your version does; "
    "the rest of the system uses the model version until it passes.":
        "របស់អ្នកនៅក្នុង {file} ត្រូវកែបន្ថែម ({passed}/{total} ករណី)។ រូបនេះបង្ហាញអ្វីដែលកំណែរបស់អ្នកធ្វើ; "
        "ផ្នែកផ្សេងទៀតនៃប្រព័ន្ធប្រើកំណែគំរូ រហូតដល់វាជាប់។",

    # ---- code puzzles, Weeks 5–8 (puzzle_bank/) — AI draft, waiting for review -------------
    "Build portions_problems(text)": "បង្កើត portions_problems(text)",
    "convert safely, then compare": "បំប្លែងដោយសុវត្ថិភាព រួចប្រៀបធៀប",
    "Turn the text into a whole number inside try. If it is a number, compare it with MIN_PORTIONS and "
    "MAX_PORTIONS. If int() fails, add a plain message. Return the list of problems.":
        "បំប្លែង text ទៅជាចំនួនគត់នៅខាងក្នុង try។ បើវាជាលេខ ប្រៀបធៀបវាជាមួយ MIN_PORTIONS និង MAX_PORTIONS។ "
        "បើ int() បរាជ័យ បន្ថែមសារដែលងាយយល់។ សូម return list នៃបញ្ហាទាំងអស់។",
    "A bare except catches every error, even a typo in your own code, and hides it. "
    "Catch only the problem you expect: int() raises a ValueError.":
        "except ទទេ (bare except) ចាប់គ្រប់ error ទាំងអស់ សូម្បីតែការសរសេរខុសក្នុងកូដរបស់អ្នក ហើយលាក់វា។ "
        "សូមចាប់តែបញ្ហាដែលអ្នករំពឹងទុក: int() បង្កើត ValueError។",
    "Correct: convert inside try, compare only when the number exists, catch only ValueError, and return every "
    "problem in one list.":
        "ត្រឹមត្រូវ: បំប្លែងនៅខាងក្នុង try ប្រៀបធៀបតែពេលមានលេខ ចាប់តែ ValueError ហើយ return គ្រប់បញ្ហាក្នុង list តែមួយ។",
    "Build can_change(old_status, new_status)": "បង្កើត can_change(old_status, new_status)",
    "look up the old status, then search its list": "រក status ចាស់ជាមុន រួចស្វែងរកក្នុង list របស់វា",
    'A bus ticket follows TICKET_MOVES = {"booked": ["paid", "cancelled"], "paid": ["used", "cancelled"], '
    '"used": [], "cancelled": []}. Return False for a status the dictionary does not know. Otherwise return True '
    "only when the new status is in the old status's list.":
        'សំបុត្រឡានក្រុងធ្វើតាម TICKET_MOVES = {"booked": ["paid", "cancelled"], "paid": ["used", "cancelled"], '
        '"used": [], "cancelled": []}។ សូម return False សម្រាប់ status ដែល dictionary មិនស្គាល់។ '
        "ក្រៅពីនោះ សូម return True តែពេល status ថ្មីនៅក្នុង list របស់ status ចាស់ប៉ុណ្ណោះ។",
    "That looks up the list of the NEW status, so it answers the wrong question. The old status's list says "
    "where a ticket may go next. With an unknown new status it would also stop with a KeyError.":
        "បន្ទាត់នោះរក list របស់ status ថ្មី ដូច្នេះវាឆ្លើយសំណួរខុស។ list របស់ status ចាស់ ទើបប្រាប់ថាសំបុត្រអាចទៅណាបន្ទាប់។ "
        "បើ status ថ្មីមិនស្គាល់ វានឹងគាំងដោយ KeyError ផងដែរ។",
    "Correct: refuse an unknown status first, look up the old status's list, and say True only when the new "
    "status is in it.":
        "ត្រឹមត្រូវ: បដិសេធ status ដែលមិនស្គាល់ជាមុន រក list របស់ status ចាស់ ហើយឆ្លើយ True តែពេល status ថ្មីនៅក្នុងនោះ។",
    "Build read_sign_ins(path)": "បង្កើត read_sign_ins(path)",
    "no file: the empty list · a file: one JSON line at a time": "គ្មាន file: list ទទេ · មាន file: អានម្ដងមួយបន្ទាត់ JSON",
    "The volunteer team keeps a sign-in history as JSON Lines: one sign-in per line. Return every sign-in as "
    "a dictionary, oldest first. When there is no file yet, return the empty list.":
        "ក្រុមអ្នកស្ម័គ្រចិត្តរក្សាប្រវត្តិចុះឈ្មោះ (sign-in) ជា JSON Lines: មួយបន្ទាត់សម្រាប់ការចុះឈ្មោះមួយ។ "
        "សូម return ការចុះឈ្មោះនីមួយៗជា dictionary ចាស់បំផុតមុនគេ។ បើមិនទាន់មាន file សូម return list ទទេ។",
    '"w" empties the file the moment it opens, so reading the history this way would erase every sign-in. '
    "To read a file, open it without a mode.":
        '"w" លុបខ្លឹមសារ file ចោលភ្លាមពេលបើក ដូច្នេះការអានប្រវត្តិតាមរបៀបនេះនឹងលុបការចុះឈ្មោះទាំងអស់។ '
        "ដើម្បីអាន file សូមបើកវាដោយមិនដាក់ mode។",
    "Correct: start with an empty list and return it when there is no file yet. Otherwise open the file to read, "
    "and turn each line into a dictionary with json.loads.":
        "ត្រឹមត្រូវ: ចាប់ផ្ដើមដោយ list ទទេ ហើយ return វាពេលមិនទាន់មាន file។ ក្រៅពីនោះ បើក file ដើម្បីអាន "
        "ហើយប្ដូរបន្ទាត់នីមួយៗទៅជា dictionary ដោយ json.loads។",
    "Build biggest_open_first(records)": "បង្កើត biggest_open_first(records)",
    "keep the open offers, then sort a new list with a named key": "រក្សាតែសំណើដែលមិនទាន់បញ្ចប់ រួចតម្រៀប list ថ្មីដោយ key function ដែលមានឈ្មោះ",
    "The team leader plans the vehicles. Keep only the open offers (status new, approved or picked_up), then "
    "return them in a new list, most portions first. The key function portions_of(record) is already written.":
        "ប្រធានក្រុមរៀបចំផែនការយានយន្ត។ សូមរក្សាតែសំណើដែលមិនទាន់បញ្ចប់ (status new, approved ឬ picked_up) "
        "រួច return វាក្នុង list ថ្មី ចំណែកច្រើនបំផុតមុនគេ។ key function portions_of(record) បានសរសេររួចហើយ។",
    "With brackets, Python calls portions_of at once, with no record, and stops with a TypeError. Give sorted "
    "the function itself (key=portions_of): sorted calls it once for each record.":
        "ពេលមានវង់ក្រចក Python ហៅ portions_of ភ្លាមៗ ដោយគ្មាន record ហើយគាំងដោយ TypeError។ "
        "សូមផ្ដល់ function ខ្លួនវាទៅ sorted (key=portions_of): sorted នឹងហៅវាម្ដងសម្រាប់ record នីមួយៗ។",
    "Correct: collect the open offers, then let sorted build a new list with your key function. The list you "
    "were given does not change.":
        "ត្រឹមត្រូវ: ប្រមូលសំណើដែលមិនទាន់បញ្ចប់ រួចឱ្យ sorted បង្កើត list ថ្មីដោយ key function របស់អ្នក។ "
        "list ដែលគេឱ្យអ្នកមិនប្រែប្រួលទេ។",
    "One row for each offer that is not rejected or cancelled, most urgent first, made by your public_row "
    "(so contacts stay private).":
        "មួយជួរសម្រាប់សំណើនីមួយៗដែលមិនត្រូវបានបដិសេធ ឬលុបចោល បន្ទាន់បំផុតមុនគេ បង្កើតដោយ public_row របស់អ្នក "
        "(ដើម្បីឱ្យព័ត៌មានទំនាក់ទំនងនៅតែជាឯកជន)។",

    # ---- code puzzles, Weeks 9–10 (puzzle_bank/) — AI draft, waiting for review ------------
    "Build menu_answer(choice, records)": "បង្កើត menu_answer(choice, records)",
    "tidy the choice, compare it with text, return the answer": "សម្អាត choice ប្រៀបធៀបវាជាមួយ text រួច return ចម្លើយ",
    'Answer one menu choice. Choice "1" returns the total portions as text. Any other choice returns a helpful message.':
        'ឆ្លើយជម្រើសមួយនៃ menu។ ជម្រើស "1" return ចំណែកសរុបជា text។ ជម្រើសផ្សេងទៀត return សារដែលមានប្រយោជន៍។',
    'input() always gives text. The text "1" is not the number 1, so this branch would never run, and every choice '
    "would get the help message.":
        'input() តែងតែផ្ដល់ text។ text "1" មិនមែនជាលេខ 1 ទេ ដូច្នេះ branch នេះនឹងមិនដែលដំណើរការឡើយ '
        "ហើយគ្រប់ជម្រើសនឹងទទួលបានសារជំនួយ។",
    'Correct: tidy the choice first, compare it with the text "1", add up the portions, and return the answer as '
    "text. Any other choice falls through to the help message.":
        'ត្រឹមត្រូវ: សម្អាត choice ជាមុនសិន ប្រៀបធៀបវាជាមួយ text "1" បូកចំណែក ហើយ return ចម្លើយជា text។ '
        "ជម្រើសផ្សេងទៀតធ្លាក់ចុះទៅសារជំនួយ។",
    "Build test_most_urgent_first(most_urgent_first)": "បង្កើត test_most_urgent_first(most_urgent_first)",
    "make the data, call the function, compare with the contract": "បង្កើតទិន្នន័យ ហៅ function រួចប្រៀបធៀបជាមួយកិច្ចសន្យា (contract)",
    "Write a test for most_urgent_first: two records, then check that the one with the fewest hours left comes first.":
        "សរសេរតេស្ត (test) សម្រាប់ most_urgent_first: records ពីរ រួចពិនិត្យថា record ដែលមានម៉ោងនៅសល់តិចបំផុតនៅមុនគេ។",
    "This compares the function with itself, so it passes even when the order is wrong. The expected answer must "
    "come from the contract (fewest hours left first), not from the code.":
        "បន្ទាត់នេះប្រៀបធៀប function ជាមួយខ្លួនវាផ្ទាល់ ដូច្នេះវាជាប់ ទោះបីលំដាប់ខុសក៏ដោយ។ "
        "ចម្លើយដែលរំពឹងទុកត្រូវតែមកពីកិច្ចសន្យា (ម៉ោងនៅសល់តិចបំផុតមុនគេ) មិនមែនពីកូដទេ។",
    "Correct: make a small list where you know the answer, call the function once, and compare the result with "
    "what the contract promises (F2, with 2 hours left, comes first).":
        "ត្រឹមត្រូវ: បង្កើត list តូចមួយដែលអ្នកដឹងចម្លើយ ហៅ function ម្ដង ហើយប្រៀបធៀបលទ្ធផលជាមួយអ្វីដែលកិច្ចសន្យាសន្យា "
        "(F2 ដែលនៅសល់ 2 ម៉ោង នៅមុនគេ)។",
    "Build test_save_then_load()": "បង្កើត test_save_then_load()",
    "save, load, compare": "រក្សាទុក load រួចប្រៀបធៀប",
    "Write a test for storage.py: save one record, load the file again, and check that the same record comes back.":
        "សរសេរតេស្ត (test) សម្រាប់ storage.py: រក្សាទុក record មួយ load file ម្ដងទៀត ហើយពិនិត្យថា record ដដែលត្រឡប់មកវិញ។",
    "The inputs are in the wrong order. The contract is save_records(records, path): the records first, then the path.":
        "inputs ស្ថិតក្នុងលំដាប់ខុស។ កិច្ចសន្យាគឺ save_records(records, path): records មុន រួចទើប path។",
    "Correct: save, load, compare. If the record comes back unchanged, your save and your load agree with each other.":
        "ត្រឹមត្រូវ: រក្សាទុក load រួចប្រៀបធៀប។ បើ record ត្រឡប់មកវិញដោយមិនប្រែប្រួល នោះ save និង load របស់អ្នកស៊ីគ្នា។",

    # ---- Midterm v2 · Campus Library Desk (midterm.py) -----------------------------------
    "MAX_LATE_DAYS must be a whole number, 1 or more (you have {value}).":
        "MAX_LATE_DAYS ត្រូវតែជាចំនួនគត់ ចាប់ពី 1 ឡើងទៅ (អ្នកមាន {value})។",
    "MAX_RENEWALS must be a whole number, 1 or more (you have {value}).":
        "MAX_RENEWALS ត្រូវតែជាចំនួនគត់ ចាប់ពី 1 ឡើងទៅ (អ្នកមាន {value})។",
    "negative late days: invalid input": "ចំនួនថ្ងៃយឺតអវិជ្ជមាន: input មិនត្រឹមត្រូវ",
    "negative renewals: invalid input": "ចំនួនដងបន្តខ្ចីអវិជ្ជមាន: input មិនត្រឹមត្រូវ",
    "reserved and 1 day late": "មានអ្នកកក់ទុក និងយឺត 1 ថ្ងៃ",
    "reserved, but 0 days late": "មានអ្នកកក់ទុក ប៉ុន្តែយឺត 0 ថ្ងៃ",
    "reserved overdue takes priority over MAX_LATE_DAYS": "សៀវភៅមានអ្នកកក់ទុកដែលយឺត មានអាទិភាពខ្ពស់ជាង MAX_LATE_DAYS",
    "exactly at MAX_LATE_DAYS": "ស្មើនឹង MAX_LATE_DAYS គ្រប់ល្មម",
    "exactly at MAX_RENEWALS": "ស្មើនឹង MAX_RENEWALS គ្រប់ល្មម",
    "just below both limits": "ទាបជាងដែនកំណត់ទាំងពីរ",
    "unreturned count, recall IDs and returned IDs": "ចំនួនមិនទាន់សង IDs ត្រូវហៅសងវិញ និង IDs ដែលបានសង",
    "every book already returned": "សៀវភៅទាំងអស់ត្រូវបានសងរួចហើយ",
    "reserved with 0 days late is not recalled; keep ID order":
        "សៀវភៅមានអ្នកកក់ទុកដែលយឺត 0 ថ្ងៃ មិនត្រូវហៅសងភ្លាមទេ; រក្សាលំដាប់ ID ដើម",
    "desk_summary must not change the list it is given":
        "desk_summary មិនត្រូវកែប្រែ list ដែលបានផ្ដល់ឱ្យទេ",
    "highest unreturned days_late": "សៀវភៅមិនទាន់សង ដែលមាន days_late ខ្ពស់បំផុត",
    "any loan 1 or more days late counts (not only > 5)":
        "ការខ្ចីណាដែលយឺតចាប់ពី 1 ថ្ងៃឡើងទៅ ត្រូវតែរាប់ (មិនមែនតែ > 5 ទេ)",
    "missing 'returned' must be treated as still out (False)":
        "បើបាត់ key 'returned' ត្រូវចាត់ទុកថានៅមិនទាន់សង (False)",
    "no overdue unreturned book returns None": "បើគ្មានសៀវភៅមិនទាន់សងដែលយឺត ត្រូវ return None",
    "most_overdue_id must not change the list it is given":
        "most_overdue_id មិនត្រូវកែប្រែ list ដែលបានផ្ដល់ឱ្យទេ",
    "starts worst_days at 5 (ignores books 1–5 days late)":
        "ចាប់ផ្ដើម worst_days ពី 5 (រំលងសៀវភៅដែលយឺត 1–5 ថ្ងៃ)",
    "a loan that is 1 to 5 days late": "ការខ្ចីមួយដែលយឺតពី 1 ដល់ 5 ថ្ងៃ",
    "uses loan.get('returned', True) (skips loans missing 'returned')":
        "ប្រើ loan.get('returned', True) (រំលងការខ្ចីដែលបាត់ 'returned')",
    "a loan dictionary without the 'returned' key": "dictionary នៃការខ្ចីមួយដែលគ្មាន key 'returned'",
    "returns loan['title'] instead of loan['id']": "return loan['title'] ជំនួសឱ្យ loan['id']",
    "checking that the returned value equals the copy id (not the title)":
        "ពិនិត្យថាតម្លៃដែល return ស្មើនឹង copy id (មិនមែន title ទេ)",
    "Give a list of your test functions without ( ), like catch_library_bugs([test_one, test_two]).":
        "សូមផ្ដល់ list នៃ test functions របស់អ្នកដោយគ្មាន ( ) ដូចជា catch_library_bugs([test_one, test_two])។",
    "Define most_overdue_id first, then run this check.":
        "សូមបង្កើត most_overdue_id ជាមុនសិន រួច run ការពិនិត្យនេះ។",
    "Your tests on your repaired most_overdue_id":
        "តេស្តរបស់អ្នក លើ most_overdue_id ដែលអ្នកបានកែសម្រួល",
    "A failing test means either your test or your repaired function still has a bug.":
        "តេស្តដែលធ្លាក់ មានន័យថាតេស្តរបស់អ្នក ឬ function ដែលអ្នកបានកែ នៅតែមាន bug។",
    "1) Your tests on a correct most_overdue_id":
        "1) តេស្តរបស់អ្នក លើ most_overdue_id ដែលត្រឹមត្រូវ",
    "A test failed even on a correct most_overdue_id. Check your expected value.":
        "តេស្តមួយបានធ្លាក់ សូម្បីលើ most_overdue_id ដែលត្រឹមត្រូវ។ សូមពិនិត្យតម្លៃរំពឹងទុករបស់អ្នក។",
    "2) Your tests against the 3 bugs in the AI code":
        "2) តេស្តរបស់អ្នក ទល់នឹង bugs ទាំង 3 ក្នុងកូដរបស់ AI",
}

