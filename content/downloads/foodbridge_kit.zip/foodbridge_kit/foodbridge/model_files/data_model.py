# data_model.py · Week 5: what a good offer looks like, and the check at the door
REQUIRED_FIELDS = ["donor", "food", "category", "portions", "hours_left"]
CATEGORIES = ["bread", "rice meals", "fruit", "vegetables", "snacks"]
MIN_PORTIONS = 1
MAX_PORTIONS = 200
REJECT_IF_HOURS_LEFT_BELOW = 1


def clean_offer(raw):
    """Check one raw row. Return (offer, []) or (None, errors)."""
    errors = []
    offer = {}
    for field in ["donor", "contact", "food", "category"]:
        offer[field] = raw.get(field, "").strip()
    offer["category"] = offer["category"].lower()
    for field in REQUIRED_FIELDS:
        if str(raw.get(field, "")).strip() == "":
            errors.append(field + " is required.")
    if offer["category"] != "" and offer["category"] not in CATEGORIES:
        errors.append("category must be one of: " + ", ".join(CATEGORIES) + ".")
    try:
        offer["portions"] = int(raw.get("portions", ""))
        if offer["portions"] < MIN_PORTIONS or offer["portions"] > MAX_PORTIONS:
            errors.append("portions must be between " + str(MIN_PORTIONS) + " and " + str(MAX_PORTIONS) + ".")
    except ValueError:
        if str(raw.get("portions", "")).strip() != "":
            errors.append("portions must be a whole number.")
    try:
        offer["hours_left"] = int(raw.get("hours_left", ""))
        if offer["hours_left"] < REJECT_IF_HOURS_LEFT_BELOW:
            errors.append("hours left is too short to collect it safely.")
    except ValueError:
        if str(raw.get("hours_left", "")).strip() != "":
            errors.append("hours_left must be a whole number.")
    if errors:
        return None, errors
    return offer, []
