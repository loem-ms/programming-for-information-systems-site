# records.py · Week 3 records, moved into a file in Week 4


def total_portions(records):
    """Return the total portions in these records."""
    total = 0
    for record in records:
        total = total + record["portions"]
    return total


def find_offer(records, offer_id):
    """Return the record with this ID, or None when there is none."""
    for record in records:
        if record["id"] == offer_id:
            return record
    return None


def open_portions(records):
    """Return the portions still waiting: status new, approved or picked_up."""
    total = 0
    for record in records:
        if record["status"] in ["new", "approved", "picked_up"]:
            total = total + record["portions"]
    return total
