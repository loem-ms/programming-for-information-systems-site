# rules.py · Week 2 rules, moved into a file in Week 4
TEAM_PICKUP_MIN_PORTIONS = 20   # this many portions or more needs a team
URGENT_HOURS = 3                # hours left at or below this = urgent
SOON_HOURS = 12                 # hours left at or below this = soon


def pickup_label(portions, approved):
    """Return "hold", "team" or "standard" for one offer."""
    if not approved:
        return "hold"
    if portions >= TEAM_PICKUP_MIN_PORTIONS:
        return "team"
    return "standard"


def urgency(hours_left):
    """Return "urgent", "soon" or "later"."""
    if hours_left <= URGENT_HOURS:
        return "urgent"
    if hours_left <= SOON_HOURS:
        return "soon"
    return "later"
