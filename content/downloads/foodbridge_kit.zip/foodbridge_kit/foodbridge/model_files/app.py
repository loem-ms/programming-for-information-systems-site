# app.py · Week 9: my own menu, built from my own files
from records import open_portions, total_portions
from report import most_urgent_first, public_row
from rules import pickup_label, urgency
from storage import load_records

MENU = "1 open offers · 2 totals · 3 public board · q quit"


def handle_choice(choice, records):
    """Return the text to show for one menu choice."""
    if choice == "1":
        lines = []
        for record in most_urgent_first(records):
            if record["status"] in ["new", "approved", "picked_up"]:
                label = pickup_label(record["portions"], record["status"] != "new")
                lines.append(f'{record["id"]}  {record["food"]} · {record["portions"]} portions · '
                             f'{urgency(record["hours_left"])} · pickup: {label}')
        if not lines:
            return "No open offers."
        return "\n".join(lines)
    if choice == "2":
        return f"Portions offered: {total_portions(records)}\nPortions still open: {open_portions(records)}"
    if choice == "3":
        lines = []
        for record in most_urgent_first(records):
            if record["status"] not in ["rejected", "cancelled"]:
                lines.append(str(public_row(record)))
        return "\n".join(lines)
    return "Please choose 1, 2, 3 or q."


def main():
    records = load_records("saved/offers.json")
    print(MENU)
    while True:
        choice = input("> ").strip().lower()
        if choice == "q":
            print("Goodbye!")
            break
        print(handle_choice(choice, records))


if __name__ == "__main__":
    main()
