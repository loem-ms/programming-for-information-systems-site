# storage.py · Week 7: never lose data, and keep a history
import json
import os

LOG_EVENTS = ["added", "input_rejected", "moved"]


def save_records(records, path):
    """Save every record as JSON. Write a temporary file first, then swap it in."""
    temp_path = path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=2)
    os.replace(temp_path, path)


def load_records(path):
    """Return the saved records, or [] when nothing is saved yet."""
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as file:
        return json.load(file)


def append_event(path, event):
    """Add one event to the end of the history file (one JSON line)."""
    with open(path, "a", encoding="utf-8") as file:
        file.write(json.dumps(event) + "\n")


def read_events(path):
    """Return every event in the history file, oldest first."""
    if not os.path.exists(path):
        return []
    events = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            if line.strip() != "":
                events.append(json.loads(line))
    return events
