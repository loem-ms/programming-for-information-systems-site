# report.py · Week 8: the right information for the right person
PUBLIC_FIELDS = ["id", "food", "category", "portions", "status"]


def public_row(record):
    """Return a new dictionary with only the fields the public may see."""
    row = {}
    for field in PUBLIC_FIELDS:
        row[field] = record.get(field, "")
    return row


def hours_left_of(record):
    return record["hours_left"]


def most_urgent_first(records):
    """Return a new list, fewest hours left first."""
    return sorted(records, key=hours_left_of)


def portions_by_status(records):
    """Return {status: total portions}."""
    totals = {}
    for record in records:
        status = record["status"]
        totals[status] = totals.get(status, 0) + record["portions"]
    return totals
