# lifecycle.py · Week 6: the moves an offer may make
REQUIRE_APPROVAL = True         # a coordinator approves before pickup

ALLOWED_MOVES = {
    "new": ["approved", "rejected"],
    "approved": ["picked_up", "cancelled"],
    "picked_up": ["delivered"],
    "delivered": [],
    "rejected": [],
    "cancelled": [],
}
if not REQUIRE_APPROVAL:
    ALLOWED_MOVES["new"].append("picked_up")


def can_move(old_status, new_status):
    """Return True when an offer may move from old_status to new_status."""
    return new_status in ALLOWED_MOVES.get(old_status, [])
