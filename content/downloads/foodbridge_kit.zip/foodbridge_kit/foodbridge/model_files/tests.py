# tests.py · Week 10: my own tests, written from the contracts
from rules import TEAM_PICKUP_MIN_PORTIONS, URGENT_HOURS, SOON_HOURS, pickup_label, urgency
from records import total_portions, open_portions
from data_model import clean_offer
from report import most_urgent_first


def test_team_minimum_boundary():
    assert pickup_label(TEAM_PICKUP_MIN_PORTIONS - 1, True) == "standard", "one below the team minimum"
    assert pickup_label(TEAM_PICKUP_MIN_PORTIONS, True) == "team", "exactly the team minimum needs a team"
    assert pickup_label(TEAM_PICKUP_MIN_PORTIONS, False) == "hold", "an offer that is not approved waits"


def test_urgency_boundaries():
    assert urgency(URGENT_HOURS) == "urgent"
    assert urgency(URGENT_HOURS + 1) == "soon"
    assert urgency(SOON_HOURS) == "soon", "the edge itself is still soon"
    assert urgency(SOON_HOURS + 1) == "later", "one hour beyond SOON_HOURS is later"


def test_totals_of_an_empty_list():
    assert total_portions([]) == 0, "no records, no portions"
    assert open_portions([]) == 0, "no records, nothing open"


def test_door_refuses_a_word_for_portions():
    raw = {"donor": "Campus Canteen", "contact": "canteen@example.org", "food": "Fried rice boxes",
           "category": "rice meals", "portions": "many", "hours_left": "24"}
    offer, errors = clean_offer(raw)
    assert offer is None, "a word for portions must be refused"
    assert len(errors) > 0, "the door says why"


def test_most_urgent_first_keeps_my_list():
    records = [{"id": "F1", "hours_left": 9}, {"id": "F2", "hours_left": 2}]
    ordered = most_urgent_first(records)
    assert ordered[0]["id"] == "F2", "the fewest hours left come first"
    assert records[0]["id"] == "F1", "my own list keeps its order"
