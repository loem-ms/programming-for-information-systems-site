# tests.py · Week 10: my own tests
from records import open_portions, total_portions
from rules import pickup_label, urgency
from data_model import clean_offer


def test_team_minimum_boundary():
    assert pickup_label(19, True) == "standard"
    assert pickup_label(20, True) == "team"
    assert pickup_label(20, False) == "hold"


def test_urgency_boundaries():
    assert urgency(3) == "urgent"
    assert urgency(4) == "soon"
    assert urgency(12) == "soon"
    assert urgency(13) == "later"


def test_totals_of_an_empty_list():
    assert total_portions([]) == 0
    assert open_portions([]) == 0


def test_door_refuses_a_word_for_portions():
    offer, errors = clean_offer({
        "donor": "A", "contact": "a@example.org", "food": "B",
        "category": "bread", "portions": "many", "hours_left": "5",
    })
    assert offer is None
    assert len(errors) == 1
