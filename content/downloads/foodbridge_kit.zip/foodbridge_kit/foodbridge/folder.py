"""Your system folder: one file for each part you build.

    bridge.my_folder()                                   # make the folder and show what is in it
    bridge.try_part("clean_offer", row)                  # call one of your functions once
    bridge.check("clean_offer", folder="my_foodbridge")  # check a function that lives in a file
    my_system = bridge.System.from_folder("my_foodbridge")

A file in the folder can hold settings (UPPERCASE names such as MIN_PORTIONS)
and functions. The files are read again every time, so the newest version is
always used. A file with a mistake is reported in plain words; it never stops
your notebook.
"""
import contextlib
import difflib
import functools
import inspect
import io
import os
import pprint
import runpy
import shutil
import sys
import traceback

from .messages import t
from .settings import DEFAULTS
from .system import HOOKS

FOLDER = "my_foodbridge"


def _python_files(folder):
    if not os.path.isdir(folder):
        return []
    return sorted(
        name for name in os.listdir(folder)
        if name.endswith(".py") and not name.startswith(".") and not name.startswith("run_")
    )


def _bind_folder(function, folder):
    """Wrap a function from the student's folder so lazy imports inside it find sibling .py files."""
    path = os.path.abspath(folder)

    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        sys.path.insert(0, path)
        try:
            return function(*args, **kwargs)
        finally:
            if path in sys.path:
                sys.path.remove(path)

    return wrapped


def _read_file(path):
    """Return (names defined in the file, None) or (None, a plain message about the mistake).

    The folder is put on sys.path while the file runs, so app.py can import your other files,
    and those files are read fresh each time (never an old copy from an earlier run).
    """
    run_name = "my_part_" + os.path.splitext(os.path.basename(path))[0]
    folder = os.path.dirname(os.path.abspath(path))
    for name in _python_files(folder):
        sys.modules.pop(os.path.splitext(name)[0], None)
    sys.path.insert(0, folder)
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            names = runpy.run_path(path, run_name=run_name)
    except SyntaxError as error:
        return None, t("{file}, line {line}: Python cannot read this line ({error}).",
                       file=os.path.basename(path), line=error.lineno, error=error.msg)
    except Exception as error:
        line = "?"
        for frame in traceback.extract_tb(error.__traceback__):
            if os.path.abspath(frame.filename) == os.path.abspath(path):
                line = frame.lineno
        return None, t("{file}, line {line}: {error}", file=os.path.basename(path), line=line,
                       error=type(error).__name__ + ": " + str(error))
    finally:
        if folder in sys.path:
            sys.path.remove(folder)
    names["__part_name__"] = run_name
    return names, None


def load_folder(folder=FOLDER):
    """Read every .py file in the folder.

    Return {"files": [(file, setting names, function names)], "settings": {name: value},
    "functions": {name: (function, file)}, "problems": [text]}.
    """
    found = {"files": [], "settings": {}, "functions": {}, "problems": [], "values": {}}
    for name in _python_files(folder):
        names, problem = _read_file(os.path.join(folder, name))
        if problem:
            found["problems"].append(problem)
            continue
        settings, functions = [], []
        for key, value in names.items():
            if key.isupper() and not key.startswith("_"):
                found["values"][key] = value
            if key.isupper() and key in DEFAULTS:
                found["settings"][key] = value
                settings.append(key)
            elif key.isupper() and not key.startswith("_"):
                close = difflib.get_close_matches(key, list(DEFAULTS), n=1, cutoff=0.85)
                if close:
                    found["problems"].append(t("{file}: {name} is not a setting. Did you mean {close}?",
                                               file=name, name=key, close=close[0]))
            elif inspect.isfunction(value) and value.__module__ == names["__part_name__"]:
                found["functions"][key] = (_bind_folder(value, folder), name)
                functions.append(key)
        found["files"].append((name, settings, functions))
    return found


def _link_to_target(folder, target):
    """Merge any files and subfolders in folder into target, then point folder at target via a symlink."""
    os.makedirs(target, exist_ok=True)
    if os.path.islink(folder) and (not os.path.exists(folder) or os.path.realpath(folder) != os.path.realpath(target)):
        os.remove(folder)
    if os.path.isdir(folder) and not os.path.islink(folder):
        for root, _, names in os.walk(folder):           # files and subfolders written before Drive was connected
            rel = os.path.relpath(root, folder)
            dest_dir = target if rel == "." else os.path.join(target, rel)
            os.makedirs(dest_dir, exist_ok=True)
            for name in names:
                source, kept = os.path.join(root, name), os.path.join(dest_dir, name)
                if os.path.isfile(source):
                    shutil.copy2(source, kept if not os.path.exists(kept) else kept + ".runtime_copy")
        shutil.rmtree(folder)
    if not os.path.lexists(folder):
        os.symlink(target, folder)


def connect(folder=FOLDER):
    """Keep the folder between weeks. In Colab it lives in your Google Drive (Colab asks once per session)."""
    try:
        from google.colab import drive
    except ImportError:
        os.makedirs(folder, exist_ok=True)
        print("📁 " + t("Your folder {folder}/ is next to this notebook.", folder=folder))
        return "local"
    target = os.path.join("/content/drive/MyDrive", folder)
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            drive.mount("/content/drive")
        os.makedirs(target, exist_ok=True)
    except Exception:
        os.makedirs(folder, exist_ok=True)
        print("⚠️ " + t("Google Drive is not connected, so {folder}/ is lost when this runtime stops. "
                        "Run this cell again to connect it.", folder=folder))
        return "runtime"
    _link_to_target(folder, target)
    print("📁 " + t("Your folder {folder}/ is kept in your Google Drive (MyDrive/{folder}), so it is still "
                   "here next week.", folder=folder))
    return "drive"


def function_from_folder(name, folder=FOLDER):
    """Return (function, settings) for one function in the folder, or (None, None) with a message."""
    found = load_folder(folder)
    for problem in found["problems"]:
        print("⚠️ " + problem)
    if not os.path.isdir(folder):
        print("❌ " + t("There is no folder {folder}/ yet. Run bridge.my_folder() first.", folder=folder))
        return None, None
    if name not in found["functions"]:
        print("❌ " + t("No function called {name} in {folder}/. Run the %%writefile cell again, "
                        "and check the name after def.", name=name, folder=folder))
        return None, None
    return found["functions"][name][0], found["settings"]


def my_folder(folder=FOLDER):
    """Make the folder if it is missing, then show its files and which parts of the system are yours."""
    created = not os.path.isdir(folder)
    os.makedirs(folder, exist_ok=True)
    found = load_folder(folder)
    print("📁 " + folder + "/" + ("   " + t("(new, empty folder)") if created else ""))
    if not found["files"] and not found["problems"]:
        print("   " + t("No files yet. A %%writefile cell saves a file here."))
    for name, settings, functions in found["files"]:
        parts = []
        if functions:
            parts.append(t("functions: {names}", names=", ".join(functions)))
        if settings:
            parts.append(t("settings: {names}", names=", ".join(settings)))
        print("   📄 " + name + "   " + (" · ".join(parts) if parts else t("(nothing the system uses yet)")))
    for problem in found["problems"]:
        print("   ⚠️ " + problem)
    print(t("Parts of the system:"))
    for hook in HOOKS:
        if hook in found["functions"]:
            print("   ✅ " + hook + "  " + t("yours, from {file}", file=found["functions"][hook][1]))
        else:
            print("   ⬜ " + hook + "  " + t("the kit's version"))


def try_part(name, *args, folder=FOLDER):
    """Call one function from your folder with these inputs, and show what it returns."""
    function, _ = function_from_folder(name, folder)
    if function is None:
        return
    shown = ", ".join(_short(arg) for arg in args)
    print(name + "(" + shown + ")")
    try:
        with contextlib.redirect_stdout(io.StringIO()) as printed:
            result = function(*args)
    except Exception as error:
        print("   ❌ " + t("error: {error}", error=type(error).__name__ + ": " + str(error)))
        return
    if printed.getvalue().strip():
        print("   " + t("printed:") + " " + printed.getvalue().strip())
    for index, line in enumerate(pprint.pformat(result, width=88, sort_dicts=False).splitlines()):
        print(("   → " if index == 0 else "     ") + line)


def system_hooks(found):
    """The hooks a folder provides, ready for System(..., hooks=...)."""
    return {name: function for name, (function, _) in found["functions"].items() if name in HOOKS}


def _short(value):
    text = repr(value)
    return text if len(text) < 60 else text[:56] + "…"
