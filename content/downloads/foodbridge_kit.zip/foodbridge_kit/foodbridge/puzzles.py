"""Code puzzles (Parsons problems): put real lines of code back in working order.

    bridge.parsons("category_check")

In Colab (or Jupyter) you click the lines in order and press Check. Anywhere
else the shuffled lines are printed with letters. One line in every puzzle
does not belong: a plausible mistake to spot and leave out.
"""
import difflib
import html
import json
import random
import uuid

from .messages import t

PUZZLES = {
    "category_check": {
        "title": "Build check_category(raw, errors)",
        "subgoal": "clean, then compare",
        "goal": 'Tidy the category first, then compare it with CATEGORIES. A blank category adds '
                '"category is required."; an unknown one adds the list of allowed categories. '
                'Return the tidy category.',
        "lines": [
            'def check_category(raw, errors):',
            '    category = raw.get("category", "").strip().lower()',
            '    if category == "":',
            '        errors.append("category is required.")',
            '    elif category not in CATEGORIES:',
            '        errors.append("category must be one of: " + ", ".join(CATEGORIES) + ".")',
            '    return category',
        ],
        "wrong": '    category = raw["category"]',
        "why": 'raw["category"] stops with a KeyError when the key is missing, and it does not tidy '
               'the text, so " Bread " would never match "bread".',
        "done": "Correct: clean, then compare. The tidy text is what you compare, a blank category "
                "gets one message, and an unknown one gets the list of allowed categories.",
    },
}

_STYLE = ("font-family:system-ui,-apple-system,'Segoe UI',sans-serif;color:#1f2933;background:#ffffff;"
          "border:1px solid #d6dde4;border-radius:10px;padding:14px 16px;max-width:1000px;line-height:1.45")
_LINE = ("display:block;width:100%;text-align:left;margin:0 0 6px;padding:6px 10px;border:1px solid #c9d3dc;"
         "border-radius:6px;background:#f7f9fb;color:#1f2933;cursor:pointer;"
         "font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;white-space:pre;overflow-x:auto")
_BUTTON = ("margin:6px 8px 0 0;padding:6px 14px;border-radius:6px;border:1px solid #1f6f4a;cursor:pointer;"
           "font-size:13px")


def _shuffled(name, puzzle):
    """The lines in a fixed shuffled order: [(key, text)]. key is the position in the answer, or "wrong"."""
    items = [(str(index), text) for index, text in enumerate(puzzle["lines"])] + [("wrong", puzzle["wrong"])]
    order = list(items)
    random.Random(name).shuffle(order)
    if [key for key, _ in order if key != "wrong"] == [key for key, _ in items if key != "wrong"]:
        order.reverse()                       # never start in the right order
    return order


def _in_notebook():
    try:
        from IPython import get_ipython
    except ImportError:
        return False
    shell = get_ipython()
    return shell is not None and type(shell).__name__ != "TerminalInteractiveShell"


def all_puzzles():
    """The puzzles in this file plus every file in puzzle_bank/."""
    import importlib
    import pkgutil
    from . import puzzle_bank
    found = dict(PUZZLES)
    for info in sorted(pkgutil.iter_modules(puzzle_bank.__path__), key=lambda item: item.name):
        module = importlib.import_module(puzzle_bank.__name__ + "." + info.name)
        found.update(getattr(module, "PUZZLES", {}))
    return found


def parsons(name):
    """Show the code puzzle called `name`."""
    puzzles = all_puzzles()
    if name not in puzzles:
        close = difflib.get_close_matches(name, list(puzzles), n=1)
        print("❌ " + t("I have no puzzle called {name}.", name=repr(name)) +
              (t(" Did you mean {close}?", close=repr(close[0])) if close else ""))
        return
    puzzle = puzzles[name]
    order = _shuffled(name, puzzle)
    if _in_notebook():
        from IPython.display import HTML, display
        display(HTML(_html(puzzle, order)))
    else:
        _print(puzzle, order)


def _print(puzzle, order):
    print("🧩 " + t("Code puzzle") + " · " + t(puzzle["title"]))
    print("   " + t("Subgoal: {subgoal}", subgoal=t(puzzle["subgoal"])))
    print("   " + t(puzzle["goal"]))
    print("   " + t("The lines are shuffled, and one of them does not belong:"))
    for letter, (_, text) in zip("ABCDEFGHIJKLMNOP", order):
        print("   " + letter + " │ " + text)
    print("   " + t("Write the letters in the right order. In Colab you can click the lines instead."))


def _html(puzzle, order):
    box = "fbpz-" + uuid.uuid4().hex[:10]
    data = {
        "items": [{"key": key, "text": text} for key, text in order],
        "correct": [str(index) for index in range(len(puzzle["lines"]))],
        "why": t(puzzle["why"]), "done": t(puzzle["done"]),
        "more": t("Not finished yet: {count} more line(s) to place."),
        "place": t("Line {number} is not in the right place yet."),
        "subgoal": t("Subgoal: {subgoal}", subgoal=t(puzzle["subgoal"])),
        "wrong": t("This line does not belong:"),
    }
    words = {key: html.escape(value) for key, value in {
        "title": t("Code puzzle") + " · " + t(puzzle["title"]),
        "subgoal": t("Subgoal: {subgoal}", subgoal=t(puzzle["subgoal"])),
        "goal": t(puzzle["goal"]),
        "pool": t("Lines (shuffled · one of them does not belong)"),
        "answer": t("Your code (click a line to take it back)"),
        "hint": t("Click the lines in the order the code needs them."),
        "check": t("Check"), "reset": t("Start again"),
    }.items()}
    payload = json.dumps(data).replace("</", "<\\/")      # keep "</script>" out of the data
    return f"""<div id="{box}" style="{_STYLE}">
<div style="font-weight:650;font-size:15px">🧩 {words["title"]}
<span style="margin-left:8px;padding:2px 8px;border-radius:6px;background:#fdf1d6;color:#7a4b00;font-size:12px;font-weight:600">{words["subgoal"]}</span></div>
<div style="color:#52606d;margin:4px 0 12px;font-size:13px">{words["goal"]}</div>
<div style="display:flex;gap:18px;flex-wrap:wrap">
<div style="flex:1 1 520px;min-width:0"><div style="font-size:12px;color:#52606d;margin-bottom:6px">{words["pool"]}</div><div data-role="pool"></div></div>
<div style="flex:1 1 520px;min-width:0"><div style="font-size:12px;color:#52606d;margin-bottom:6px">{words["answer"]}</div>
<div data-role="answer" style="min-height:40px;border:1px dashed #9fb3c8;border-radius:8px;padding:6px"></div></div>
</div>
<div style="font-size:12px;color:#52606d;margin-top:8px">{words["hint"]}</div>
<button data-role="check" style="{_BUTTON};background:#1f6f4a;color:#ffffff">{words["check"]}</button>
<button data-role="reset" style="{_BUTTON};background:#ffffff;color:#1f6f4a">{words["reset"]}</button>
<div data-role="feedback" style="margin-top:10px;font-size:13px"></div>
</div>
<script>
(function () {{
  var data = {payload};
  var root = document.getElementById("{box}");
  var pool = root.querySelector('[data-role="pool"]');
  var answer = root.querySelector('[data-role="answer"]');
  var feedback = root.querySelector('[data-role="feedback"]');
  var chosen = [];
  function say(text, good) {{
    feedback.textContent = text;
    feedback.style.padding = text ? "8px 12px" : "0";
    feedback.style.borderRadius = "6px";
    feedback.style.background = text ? (good ? "#e5f4ea" : "#fbe9e7") : "transparent";
  }}
  function line(text, prefix) {{
    var button = document.createElement("button");
    button.setAttribute("style", {json.dumps(_LINE)});
    button.textContent = (prefix || "") + text;
    return button;
  }}
  function draw() {{
    pool.innerHTML = ""; answer.innerHTML = "";
    data.items.forEach(function (item) {{
      if (chosen.indexOf(item.key) >= 0) return;
      var button = line(item.text);
      button.onclick = function () {{ chosen.push(item.key); say(""); draw(); }};
      pool.appendChild(button);
    }});
    chosen.forEach(function (key, index) {{
      var item = data.items.filter(function (i) {{ return i.key === key; }})[0];
      var button = line(item.text, String(index + 1).padStart(2, " ") + " │ ");
      button.style.background = "#eef6f1";
      button.onclick = function () {{ chosen.splice(index, 1); say(""); draw(); }};
      answer.appendChild(button);
    }});
  }}
  root.querySelector('[data-role="check"]').onclick = function () {{
    if (chosen.indexOf("wrong") >= 0) {{
      var text = data.items.filter(function (i) {{ return i.key === "wrong"; }})[0].text.trim();
      say("❌ " + data.wrong + " " + text + " — " + data.why, false); return;
    }}
    if (chosen.length < data.correct.length) {{
      say("⏳ " + data.more.replace("{{count}}", data.correct.length - chosen.length), false); return;
    }}
    for (var i = 0; i < data.correct.length; i++) {{
      if (chosen[i] !== data.correct[i]) {{
        say("❌ " + data.place.replace("{{number}}", i + 1) + " " + data.subgoal + ".", false); return;
      }}
    }}
    say("✅ " + data.done, true);
  }};
  root.querySelector('[data-role="reset"]').onclick = function () {{ chosen = []; say(""); draw(); }};
  draw();
}})();
</script>"""
