"""Helpers for the Week 4 midterm (you do not need to read this file).

    offers = bridge.midterm_offers()
    bridge.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 15})
    bridge.check("plan_day", plan_day, {"PORTIONS_PER_VOLUNTEER": 15})
    bridge.catch_bugs([test_normal, test_boundary, test_waiting, test_empty])
"""
import contextlib
import io

from .messages import t

DEFAULT_PER = 15
NAMES = ("volunteers_needed", "plan_day")


def midterm_offers():
    """Four offers for the midterm: three approved, one waiting."""
    return [{"id": "F001", "food": "Bread rolls", "portions": 30, "approved": True},
            {"id": "F002", "food": "Fried rice boxes", "portions": 18, "approved": True},
            {"id": "F003", "food": "Bananas", "portions": 40, "approved": False},
            {"id": "F004", "food": "Vegetable curry", "portions": 12, "approved": True}]


def per_problem(per):
    """Return a message when PORTIONS_PER_VOLUNTEER is not a sensible whole number."""
    if type(per) is not int or per < 1:
        return t("PORTIONS_PER_VOLUNTEER must be a whole number of portions, 1 or more (you have {value}).", value=repr(per))
    return None


def _need(portions, per):
    return (portions + per - 1) // per


def _case(args, show, expect, why):
    return {"args": args, "show": show, "expect": expect, "why": why}


def volunteers_cases(s):
    per = s["PORTIONS_PER_VOLUNTEER"]
    rows = [(0, 0, "no portions, no volunteers"), (1, 1, "one portion still needs a volunteer")]
    if per > 1:
        rows.append((per - 1, 1, "one below a full load"))
    rows += [(per, 1, "exactly one full load"), (per + 1, 2, "one portion more than a full load"),
             (2 * per, 2, "exactly two full loads"), (2 * per + 1, 3, "one more than two loads")]
    return [_case((n,), "volunteers_needed(" + str(n) + ")", expect, why) for n, expect, why in rows]


def plan_cases(s):
    per = s["PORTIONS_PER_VOLUNTEER"]
    offers = midterm_offers()
    full = {"offers": 4, "approved_portions": 60, "volunteers": _need(30, per) + _need(18, per) + _need(12, per),
            "waiting": ["F003"]}
    waiting = [offers[2], {"id": "F005", "food": "Mangoes", "portions": 25, "approved": False}]
    return [_case((offers,), "plan_day(4 midterm offers)", full, "approved offers only; IDs of waiting offers"),
            _case(([],), "plan_day([])", {"offers": 0, "approved_portions": 0, "volunteers": 0, "waiting": []},
                  "an empty list"),
            _case((waiting,), "plan_day(2 waiting offers)",
                  {"offers": 2, "approved_portions": 0, "volunteers": 0, "waiting": ["F003", "F005"]},
                  "nothing approved yet"),
            _case((offers,), "the list after plan_day(...)", "input unchanged",
                  "plan_day must not change the list it is given")]


@contextlib.contextmanager
def correct_volunteers(function, per):
    """While checking plan_day, use a correct volunteers_needed so one mistake is not marked twice."""
    names = getattr(function, "__globals__", {})
    had = "volunteers_needed" in names
    old = names.get("volunteers_needed")
    if had:
        names["volunteers_needed"] = lambda portions: _need(portions, per)
    try:
        yield
    finally:
        if had:
            names["volunteers_needed"] = old


# ---------------------------------------------------------------- catch_bugs

def _bug_rounds_down(names):
    def volunteers_needed(portions):
        return portions // names["PORTIONS_PER_VOLUNTEER"]
    return volunteers_needed


def _bug_one_too_many(names):
    def volunteers_needed(portions):
        return portions // names["PORTIONS_PER_VOLUNTEER"] + 1
    return volunteers_needed


def _bug_counts_waiting(names):
    def plan_day(offers):
        result = {"offers": len(offers), "approved_portions": 0, "volunteers": 0, "waiting": []}
        for offer in offers:
            result["approved_portions"] += offer["portions"]
            result["volunteers"] += names["volunteers_needed"](offer["portions"])
            if not offer["approved"]:
                result["waiting"].append(offer["id"])
        return result
    return plan_day


def _bug_empty_list(names):
    def plan_day(offers):
        if len(offers) == 0:
            return None
        result = {"offers": len(offers), "approved_portions": 0, "volunteers": 0, "waiting": []}
        for offer in offers:
            if offer["approved"]:
                result["approved_portions"] += offer["portions"]
                result["volunteers"] += names["volunteers_needed"](offer["portions"])
            else:
                result["waiting"].append(offer["id"])
        return result
    return plan_day


BUGS = [("volunteers_needed", _bug_rounds_down, "rounds down (2 full loads + 1 portion → 2 volunteers)",
         "a normal case that is not an exact multiple"),
        ("volunteers_needed", _bug_one_too_many, "one volunteer too many at an exact full load",
         "a boundary case: exactly PORTIONS_PER_VOLUNTEER portions"),
        ("plan_day", _bug_counts_waiting, "counts portions of offers that are not approved",
         "checking approved_portions when one offer is not approved"),
        ("plan_day", _bug_empty_list, "returns None for an empty list",
         "plan_day([])")]


def _run_tests(tests):
    """Run each test quietly. Return a list of (name, problem or None)."""
    results = []
    for test in tests:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                test()
            results.append((test.__name__, None))
        except AssertionError as error:
            results.append((test.__name__, t("assert failed") + (": " + str(error) if str(error) else "")))
        except Exception as error:
            results.append((test.__name__, type(error).__name__ + ": " + str(error)))
    return results


@contextlib.contextmanager
def _swapped(names, name, value):
    old = names[name]
    names[name] = value
    try:
        yield
    finally:
        names[name] = old


def catch_bugs(tests):
    """Run your tests on your code, then on planted buggy versions. Return how many bugs were caught."""
    if callable(tests):
        tests = [tests]
    if not isinstance(tests, (list, tuple)) or not tests or not all(callable(t) for t in tests):
        print("❌ " + t("Give a list of your test functions without ( ), like catch_bugs([test_normal, test_empty])."))
        return 0
    names = tests[0].__globals__
    missing = [n for n in NAMES + ("PORTIONS_PER_VOLUNTEER",) if n not in names]
    if missing:
        print("❌ " + t("Run the cells that define {names} first.", names=", ".join(missing)))
        return 0
    with contextlib.redirect_stdout(io.StringIO()):
        empty = [t.__name__ for t in tests if _passes_without_code(t, names)]

    print(t("1) Your tests on your own code"))
    own = _run_tests(tests)
    for test_name, problem in own:
        print(("  ✅ " if problem is None else "  ❌ ") + test_name + ("" if problem is None else " → " + problem))
    if any(problem for _, problem in own):
        print("  💡 " + t("A failing test means the test or the function is wrong. Find out which before you go on."))
    if empty:
        print("  ⚠️ " + t("{names} passed even with no working code. Does it really check something?",
                          names=", ".join(empty)))

    print("\n" + t("2) Your tests against planted bugs"))
    caught = 0
    for number, (target, make_bug, story, idea) in enumerate(BUGS, 1):
        with _swapped(names, target, make_bug(names)):
            failed = [n for n, problem in _run_tests(tests) if problem]
        caught += bool(failed)
        if failed:
            print("  🐛 " + t("Bug {number} · {story}: ✅ caught by {tests}", number=number, story=t(story),
                              tests=", ".join(failed)))
        else:
            print("  🐛 " + t("Bug {number} · {story}: ❌ not caught. 💡 Try {idea}.", number=number,
                              story=t(story), idea=t(idea)))
    print("  " + t("{caught}/{total} bugs caught.", caught=caught, total=len(BUGS)) +
          (" 🎉" if caught == len(BUGS) else ""))

    per = names["PORTIONS_PER_VOLUNTEER"]
    other = 8 if per != 8 else 10
    print("\n" + t("3) Your code and tests with a different decision (PORTIONS_PER_VOLUNTEER = {other})", other=other))
    with _swapped(names, "PORTIONS_PER_VOLUNTEER", other):
        broken = [n for n, problem in _run_tests(tests) if problem]
    if broken:
        print("  ⚠️ " + t("{names} fail(s) when the number changes. A raw number may be hidden in "
                          "your function or your test. Use PORTIONS_PER_VOLUNTEER instead (see Part F).",
                          names=", ".join(broken)))
    else:
        print("  ✅ " + t("Your code and tests follow the constant: no hidden magic numbers."))
    return caught


def _passes_without_code(test, names):
    """True when a test passes even if both functions do nothing (it checks nothing)."""
    nothing = lambda *args: None  # noqa: E731
    with _swapped(names, "volunteers_needed", nothing), _swapped(names, "plan_day", nothing):
        try:
            test()
            return True
        except Exception:
            return False


# ---------------------------------------------------------------- Midterm v2 · Campus Library Desk

DEFAULT_MAX_LATE = 7
DEFAULT_MAX_RENEWALS = 2
LIBRARY_NAMES = ("loan_action", "desk_summary")


def midterm_loans():
    """Five library loans for Midterm v2 (Campus Library Desk)."""
    return [
        {"id": "B01", "title": "Data Basics", "days_late": 2, "is_reserved": True, "renewals": 0, "returned": False},
        {"id": "B02", "title": "Python Guide", "days_late": 8, "is_reserved": False, "renewals": 1, "returned": False},
        {"id": "B03", "title": "Web Design", "days_late": 0, "is_reserved": False, "renewals": 2, "returned": False},
        {"id": "B04", "title": "SQL Intro", "days_late": 3, "is_reserved": False, "renewals": 1, "returned": False},
        {"id": "B05", "title": "Data Basics", "days_late": 5, "is_reserved": True, "renewals": 0, "returned": True},
    ]


def library_settings_problem(max_late, max_renewals):
    """Return a message when MAX_LATE_DAYS or MAX_RENEWALS is not a whole number >= 1."""
    if type(max_late) is not int or max_late < 1:
        return t("MAX_LATE_DAYS must be a whole number, 1 or more (you have {value}).", value=repr(max_late))
    if type(max_renewals) is not int or max_renewals < 1:
        return t("MAX_RENEWALS must be a whole number, 1 or more (you have {value}).", value=repr(max_renewals))
    return None


def _loan_action(days_late, is_reserved, renewals, max_late, max_renewals):
    if days_late < 0 or renewals < 0:
        return None
    if is_reserved and days_late >= 1:
        return "recall_now"
    if days_late >= max_late or renewals >= max_renewals:
        return "return_only"
    return "allow_renew"


def loan_action_cases(s):
    ml = s["MAX_LATE_DAYS"]
    mr = s["MAX_RENEWALS"]
    rows = [
        ((-1, False, 0), None, "negative late days: invalid input"),
        ((0, False, -1), None, "negative renewals: invalid input"),
        ((1, True, 0), "recall_now", "reserved and 1 day late"),
        ((0, True, 0), "allow_renew", "reserved, but 0 days late"),
        ((ml, True, 0), "recall_now", "reserved overdue takes priority over MAX_LATE_DAYS"),
        ((ml, False, 0), "return_only", "exactly at MAX_LATE_DAYS"),
        ((ml - 1, False, mr), "return_only", "exactly at MAX_RENEWALS"),
        ((ml - 1, False, mr - 1), "allow_renew", "just below both limits"),
    ]
    return [_case(args, "loan_action" + str(args), expect, why) for args, expect, why in rows]


def desk_summary_cases(s):
    loans = midterm_loans()
    all_returned = [
        {"id": "B05", "title": "Data Basics", "days_late": 5, "is_reserved": True, "renewals": 0, "returned": True},
        {"id": "B06", "title": "Ethics", "days_late": 0, "is_reserved": False, "renewals": 0, "returned": True},
    ]
    mixed = [
        {"id": "B07", "title": "Logic", "days_late": 0, "is_reserved": True, "renewals": 0, "returned": False},
        {"id": "B08", "title": "Stats", "days_late": 1, "is_reserved": True, "renewals": 0, "returned": False},
        {"id": "B09", "title": "Stats", "days_late": 4, "is_reserved": True, "renewals": 1, "returned": False},
    ]
    return [
        _case((loans,), "desk_summary(5 midterm loans)",
              {"still_out": 4, "recall_ids": ["B01"], "returned_ids": ["B05"]},
              "unreturned count, recall IDs and returned IDs"),
        _case(([],), "desk_summary([])",
              {"still_out": 0, "recall_ids": [], "returned_ids": []},
              "an empty list"),
        _case((all_returned,), "desk_summary(2 returned loans)",
              {"still_out": 0, "recall_ids": [], "returned_ids": ["B05", "B06"]},
              "every book already returned"),
        _case((mixed,), "desk_summary(3 reserved loans)",
              {"still_out": 3, "recall_ids": ["B08", "B09"], "returned_ids": []},
              "reserved with 0 days late is not recalled; keep ID order"),
        _case((loans,), "the list after desk_summary(...)", "input unchanged",
              "desk_summary must not change the list it is given"),
    ]


def _ref_most_overdue_id(loans):
    worst_id = None
    worst_days = 0
    for loan in loans:
        if not loan.get("returned", False):
            if loan["days_late"] > worst_days:
                worst_days = loan["days_late"]
                worst_id = loan["id"]
    return worst_id


def most_overdue_id_cases(s):
    loans = midterm_loans()
    short_late = [{"id": "B10", "title": "Networks", "days_late": 2, "returned": False}]
    missing_flag = [{"id": "B11", "title": "Databases", "days_late": 4}]
    none_late = [
        {"id": "B12", "title": "History", "days_late": 0, "returned": False},
        {"id": "B13", "title": "History", "days_late": 9, "returned": True},
    ]
    return [
        _case((loans,), "most_overdue_id(5 midterm loans)", "B02", "highest unreturned days_late"),
        _case((short_late,), "most_overdue_id(1 loan, 2 days late)", "B10",
              "any loan 1 or more days late counts (not only > 5)"),
        _case((missing_flag,), "most_overdue_id(loan missing 'returned')", "B11",
              "missing 'returned' must be treated as still out (False)"),
        _case((none_late,), "most_overdue_id(none late or all returned)", None,
              "no overdue unreturned book returns None"),
        _case(([],), "most_overdue_id([])", None, "an empty list"),
        _case((loans,), "the list after most_overdue_id(...)", "input unchanged",
              "most_overdue_id must not change the list it is given"),
    ]


@contextlib.contextmanager
def correct_loan_action(function, max_late, max_renewals):
    """While checking desk_summary, use a correct loan_action so a Part 2 mistake is not marked twice."""
    names = getattr(function, "__globals__", {})
    had = "loan_action" in names
    old = names.get("loan_action")
    if had:
        names["loan_action"] = lambda d, r, n: _loan_action(d, r, n, max_late, max_renewals)
    try:
        yield
    finally:
        if had:
            names["loan_action"] = old


def _lib_bug_magic_five(loans):
    worst_id = None
    worst_days = 5
    for loan in loans:
        if not loan.get("returned", False):
            if loan["days_late"] > worst_days:
                worst_days = loan["days_late"]
                worst_id = loan["id"]
    return worst_id


def _lib_bug_unsafe_default(loans):
    worst_id = None
    worst_days = 0
    for loan in loans:
        if not loan.get("returned", True):
            if loan["days_late"] > worst_days:
                worst_days = loan["days_late"]
                worst_id = loan["id"]
    return worst_id


def _lib_bug_returns_title(loans):
    worst_id = None
    worst_days = 0
    for loan in loans:
        if not loan.get("returned", False):
            if loan["days_late"] > worst_days:
                worst_days = loan["days_late"]
                worst_id = loan["title"]
    return worst_id


LIBRARY_BUGS = [
    (_lib_bug_magic_five, "starts worst_days at 5 (ignores books 1–5 days late)",
     "a loan that is 1 to 5 days late"),
    (_lib_bug_unsafe_default, "uses loan.get('returned', True) (skips loans missing 'returned')",
     "a loan dictionary without the 'returned' key"),
    (_lib_bug_returns_title, "returns loan['title'] instead of loan['id']",
     "checking that the returned value equals the copy id (not the title)"),
]


@contextlib.contextmanager
def _swapped_optional(names, name, value):
    had = name in names
    old = names.get(name)
    names[name] = value
    try:
        yield
    finally:
        if had:
            names[name] = old
        elif name in names:
            del names[name]


def _lib_passes_without_code(test, names):
    nothing = lambda *args: None  # noqa: E731
    with _swapped_optional(names, "most_overdue_id", nothing):
        try:
            test()
            return True
        except Exception:
            return False


def catch_library_bugs(tests, check_yours=False):
    """Run your Part 4A tests against a correct most_overdue_id and the 3 AI bugs.

    When check_yours=True (Part 4B), also run your tests against your repaired most_overdue_id.
    Return how many of the 3 bugs were caught.
    """
    if callable(tests):
        tests = [tests]
    if not isinstance(tests, (list, tuple)) or not tests or not all(callable(fn) for fn in tests):
        print("❌ " + t("Give a list of your test functions without ( ), like catch_library_bugs([test_one, test_two])."))
        return 0
    names = tests[0].__globals__
    with contextlib.redirect_stdout(io.StringIO()):
        empty = [fn.__name__ for fn in tests if _lib_passes_without_code(fn, names)]

    if check_yours:
        if "most_overdue_id" not in names or not callable(names["most_overdue_id"]):
            print("❌ " + t("Define most_overdue_id first, then run this check."))
            return 0
        print(t("Your tests on your repaired most_overdue_id"))
        own = _run_tests(tests)
        for test_name, problem in own:
            print(("  ✅ " if problem is None else "  ❌ ") + test_name + ("" if problem is None else " → " + problem))
        if any(problem for _, problem in own):
            print("  💡 " + t("A failing test means either your test or your repaired function still has a bug."))
        return sum(problem is None for _, problem in own)

    print(t("1) Your tests on a correct most_overdue_id"))
    with _swapped_optional(names, "most_overdue_id", _ref_most_overdue_id):
        ref = _run_tests(tests)
    for test_name, problem in ref:
        print(("  ✅ " if problem is None else "  ❌ ") + test_name + ("" if problem is None else " → " + problem))
    if any(problem for _, problem in ref):
        print("  💡 " + t("A test failed even on a correct most_overdue_id. Check your expected value."))
    if empty:
        print("  ⚠️ " + t("{names} passed even with no working code. Does it really check something?",
                          names=", ".join(empty)))

    print("\n" + t("2) Your tests against the 3 bugs in the AI code"))
    caught = 0
    for number, (bug_fn, story, idea) in enumerate(LIBRARY_BUGS, 1):
        with _swapped_optional(names, "most_overdue_id", bug_fn):
            failed = [n for n, problem in _run_tests(tests) if problem]
        caught += bool(failed)
        if failed:
            print("  🐛 " + t("Bug {number} · {story}: ✅ caught by {tests}", number=number, story=t(story),
                              tests=", ".join(failed)))
        else:
            print("  🐛 " + t("Bug {number} · {story}: ❌ not caught. 💡 Try {idea}.", number=number,
                              story=t(story), idea=t(idea)))
    print("  " + t("{caught}/{total} bugs caught.", caught=caught, total=len(LIBRARY_BUGS)) +
          (" 🎉" if caught == len(LIBRARY_BUGS) else ""))
    return caught

