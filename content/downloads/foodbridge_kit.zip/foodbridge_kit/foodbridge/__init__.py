"""Campus FoodBridge: a small information system for learning.

In a notebook, use one import:

    import foodbridge as bridge
    s = bridge.System()      # the whole system with default settings
    s.run_day()              # replay a sample day
    print(s.report())        # what the coordinator sees

All organisations, people and numbers are fictional.
"""
from . import models, records, reports, rules, storage, validation
from .check import check, sample_records
from .export import download_my_system, make_zip
from .messages import current_language, set_language
from .menu import handle_choice, run_menu
from .midterm import catch_bugs, midterm_offers
from .models import ALLOWED_MOVES, Offer
from .settings import DEFAULTS, make_settings
from .system import HOOKS, System
from .web import start_web, stop_web, web_link

KIT_VERSION = "2026.11.3"
