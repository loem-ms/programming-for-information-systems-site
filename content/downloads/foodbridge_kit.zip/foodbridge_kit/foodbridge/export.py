"""Package your own system as a ZIP that runs on any computer with Python 3.

You do NOT need to read this file for the course.
"""
import inspect
import os
import textwrap
import zipfile

from .loader import KIT_DIR
from .messages import current_language, t
from .settings import DEFAULTS
from .system import HOOKS

SKIP_DIRS = {"__pycache__", "saved_data", ".ipynb_checkpoints"}


def settings_file_text(settings):
    lines = ['"""My decisions. Each line changes one default in foodbridge/settings.py."""', ""]
    settings = dict(settings or {})
    if current_language() != "en":
        settings.setdefault("LANGUAGE", current_language())    # keep the screens in your edition's language
    for name, value in settings.items():
        if name in DEFAULTS:
            lines.append(name + " = " + repr(value))
    if len(lines) == 2:
        lines.append("# No changes yet: the defaults are used.")
    return "\n".join(lines) + "\n"


def _global_names(code):
    """Every global name a function's code reads, including inside loops like [x for x in ...]."""
    names = list(code.co_names)
    for const in code.co_consts:
        if inspect.iscode(const):
            names += _global_names(const)
    return names


def _import_line(used, module):
    """The import that gives the name `used`, e.g. "import foodbridge as bridge" or "from foodbridge import validation"."""
    if module.startswith("foodbridge."):
        part = module.split(".", 1)[1]
        return "from foodbridge import " + part + ("" if part == used else " as " + used)
    return "import " + module + ("" if module == used else " as " + used)


def _source(function):
    return textwrap.dedent(inspect.getsource(function))


def rules_file_text(hooks):
    """my_rules.py: your hooks, plus the helper functions, imports and CONSTANTS they use."""
    lines = ['"""My own rules. The System plugs in every function here whose name is a hook."""', ""]
    imports, constants, helpers, sources = [], {}, {}, []

    def collect(function):
        for used in _global_names(function.__code__):
            value = function.__globals__.get(used)
            if inspect.ismodule(value):
                line = _import_line(used, value.__name__)
                if line not in imports:
                    imports.append(line)
            elif used.isupper() and isinstance(value, (int, float, str, bool, list, dict, tuple)):
                constants[used] = value
            elif (inspect.isfunction(value) and value.__module__ == function.__module__
                  and used not in helpers and used not in HOOKS and value is not function):
                try:
                    helpers[used] = _source(value)
                except (OSError, TypeError):
                    helpers[used] = "# Could not copy the helper " + used + ". Paste it here by hand.\n"
                    continue
                collect(value)

    for name, function in (hooks or {}).items():
        if name not in HOOKS:
            continue
        try:
            source = _source(function)
        except (OSError, TypeError):
            sources.append("# Could not copy the source of " + name + ". Paste it here by hand.\n")
            continue
        if function.__name__ != name:
            source += "\n" + name + " = " + function.__name__ + "\n"
        sources.append(source)
        collect(function)
    for section in (imports, [name + " = " + repr(value) for name, value in constants.items()]):
        if section:
            lines += section + [""]
    if helpers:
        lines += ["# Helper functions your rules use"] + list(helpers.values())
    lines += sources or ["# No hooks yet: the default rules are used."]
    return "\n".join(lines) + "\n"


def make_zip(settings=None, hooks=None, filename="my_foodbridge.zip"):
    """Write the ZIP next to the notebook and return its path."""
    path = os.path.abspath(filename)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for folder, dirs, files in os.walk(KIT_DIR):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            for name in sorted(files):
                full = os.path.join(folder, name)
                relative = os.path.relpath(full, KIT_DIR)
                if relative in ("my_settings.py", "my_rules.py") or name.endswith((".pyc", ".tmp")):
                    continue
                archive.write(full, os.path.join("foodbridge_kit", relative))
        archive.writestr("foodbridge_kit/my_settings.py", settings_file_text(settings))
        archive.writestr("foodbridge_kit/my_rules.py", rules_file_text(hooks))
    return path


def download_my_system(settings=None, hooks=None, filename="my_foodbridge.zip"):
    """Make the ZIP; in Colab, also start the download."""
    path = make_zip(settings, hooks, filename)
    try:
        from google.colab import files     # only exists inside Google Colab
        files.download(path)
        print(t("✅ Download started: {name}", name=os.path.basename(path)))
    except ImportError:
        print(t("✅ Saved: {path}", path=path))
    print(t("On your computer: unzip it, open a terminal in foodbridge_kit, run:  python run_web.py"))
    return path
