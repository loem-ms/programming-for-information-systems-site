"""A small web page for the System (optional, Level 4).

You do NOT need to read or understand this file for the course. It uses only
Python's standard library. Every value shown on the page is escaped, and every
action goes through the same System methods (and your hooks) as the notebook.

    bridge.start_web(system)  # in a notebook (in Colab, click the link it shows)
    python run_web.py         # on your own computer, then open http://localhost:8000
    bridge.web_link(8000)     # in Colab, after starting run_web.py in the terminal
"""
import html
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

from .messages import COLUMNS, t, word

STATUSES = ["new", "approved", "picked_up", "delivered", "rejected", "cancelled"]
_running = {"server": None, "thread": None}

STYLE = """
body{font-family:system-ui,-apple-system,"Segoe UI","Noto Sans Khmer","Khmer OS Battambang","Khmer Sangam MN",sans-serif;margin:0;background:#f5f7fa;color:#1f2d3a}
header{background:#213449;color:#fff;padding:14px 24px}header a{color:#cfe0ef;margin-right:16px}
main{padding:16px 24px;max-width:1200px}h1{font-size:22px;margin:0 0 6px}h2{font-size:18px;margin:22px 0 8px}
table{border-collapse:collapse;width:100%;background:#fff}th,td{border-bottom:1px solid #e3e8ee;padding:6px 8px;text-align:left;font-size:14px}
th{background:#edf3f8}.cards{display:flex;gap:10px;flex-wrap:wrap}.card{background:#fff;border:1px solid #e3e8ee;border-radius:8px;padding:8px 12px;min-width:120px}
.card b{display:block;font-size:20px}.msg{padding:8px 12px;border-radius:6px;margin:10px 0}.ok{background:#e5f4ea}.bad{background:#fbe9e7}
.risky{background:#fff4d6;padding:8px 12px;border-radius:6px}form.inline{display:flex;gap:6px;align-items:center}
input,select,button{font-size:14px;padding:4px 6px}button{background:#426583;color:#fff;border:0;border-radius:4px;padding:5px 10px;cursor:pointer}
.urgent{color:#b3261e;font-weight:600}
"""


def _e(value):
    return html.escape(str(value))


def _statuses_for(system):
    statuses = list(STATUSES)
    folder_info = getattr(system, "folder", None) or {}
    custom = folder_info.get("values", {}).get("ALLOWED_MOVES")
    if isinstance(custom, dict):
        for key, targets in custom.items():
            for st in [key] + (list(targets) if isinstance(targets, (list, tuple, set)) else []):
                if isinstance(st, str) and st not in statuses:
                    statuses.append(st)
    return statuses


def _page(system, title, body, message="", ok=True):
    name, lang = system.settings["SYSTEM_NAME"], system.lang
    note = ""
    if message:
        note = '<p class="msg ' + ("ok" if ok else "bad") + '">' + _e(message) + "</p>"
    risky = ""
    if not system.settings["REQUIRE_APPROVAL"]:
        risky = ('<p class="risky">' + _e(t("⚠️ Approval is switched off: food can move without a coordinator decision.",
                                             lang)) + "</p>")
    return ("<!doctype html><html lang='" + lang + "'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width'>"
            "<title>" + _e(name) + "</title><style>" + STYLE + "</style></head><body><header><h1>" + _e(name)
            + "</h1><a href='./'>" + _e(t("Coordinator", lang)) + "</a><a href='public'>" + _e(t("Public board", lang))
            + "</a><a href='history'>" + _e(t("History", lang)) + "</a>"
            + "</header><main><h2>" + _e(title) + "</h2>" + risky + note + body + "</main></body></html>")


def _table(rows, columns, lang="en"):
    titles = COLUMNS.get(lang, {})
    head = "".join("<th>" + _e(titles.get(c, c)) + "</th>" for c in columns)
    body = ""
    for row in rows:
        body += "<tr>" + "".join("<td>" + row.get(c, "") + "</td>" for c in columns) + "</tr>"
    return ("<table><tr>" + head + "</tr>" + (body or "<tr><td>" + _e(t("(nothing to show)", lang)) + "</td></tr>")
            + "</table>")


def _options(values, labels=None):
    return "".join("<option value='" + _e(v) + "'>" + _e(labels[i] if labels else v) + "</option>"
                   for i, v in enumerate(values))


def coordinator_page(system, message="", ok=True):
    lang = system.settings["LANGUAGE"]
    numbers = system.numbers()
    if numbers["inputs_refused"] == "not logged":
        numbers["inputs_refused"] = t("not logged", lang)
    cards = "".join("<div class='card'>" + _e(t(k.replace("_", " "), lang)) + "<b>" + _e(v) + "</b></div>"
                    for k, v in numbers.items())
    statuses = _statuses_for(system)
    ordered_offers = [system.get(r["id"]) for r in system.ordered()]
    ordered_offers = [o for o in ordered_offers if o is not None]
    rows = []
    for offer in ordered_offers:
        if not offer.is_open():
            continue
        nexts = [s for s in statuses if system._can_move(offer.status, s)]
        partner = ""
        if "approved" in nexts or ("picked_up" in nexts and not offer.partner):
            partner = ("<select name='partner'><option value=''>" + _e(t("partner…", lang)) + "</option>"
                       + _options(system.settings["PARTNERS"]) + "</select>")
        action = ("<form class='inline' method='post' action='move'><input type='hidden' name='id' value='" + _e(offer.id)
                  + "'><select name='status'>" + _options(nexts, [word(s, lang) for s in nexts]) + "</select>"
                  + partner + "<button>" + _e(t("Move", lang)) + "</button></form>") if nexts else ""
        level = system.urgency(offer)
        rows.append({"id": _e(offer.id), "food": _e(offer.food), "portions": _e(offer.portions),
                     "hours left": _e(offer.hours_left),
                     "urgency": "<span class='" + _e(level) + "'>" + _e(word(level, lang)) + "</span>",
                     "pickup": _e(word(system.label(offer), lang)), "status": _e(word(offer.status, lang)),
                     "partner": _e(offer.partner), "donor": _e(offer.donor), "contact": _e(offer.contact),
                     "action": action})
    columns = ["id", "food", "portions", "hours left", "urgency", "pickup", "status", "partner", "donor", "contact", "action"]
    fields = ""
    titles = COLUMNS.get(lang, {})
    for field in ["donor", "contact", "food", "portions", "hours_left"]:
        fields += "<label>" + _e(titles.get(field, field)) + " <input name='" + field + "' size='12'></label> "
    fields += ("<label>" + _e(titles.get("category", "category")) + " <select name='category'>"
               + _options(system.settings["CATEGORIES"]) + "</select></label> ")
    add = ("<h2>" + _e(t("Add an offer", lang)) + "</h2><form method='post' action='add'>" + fields + "<button>"
           + _e(t("Check and add", lang)) + "</button></form>")
    closed = [{"id": _e(o.id), "food": _e(o.food), "portions": _e(o.portions), "status": _e(word(o.status, lang)),
               "partner": _e(o.partner)} for o in ordered_offers if not o.is_open()]
    body = ("<div class='cards'>" + cards + "</div><h2>" + _e(t("Open offers", lang)) + "</h2>"
            + _table(rows, columns, lang) + add + "<h2>" + _e(t("Finished offers", lang)) + "</h2>"
            + _table(closed, ["id", "food", "portions", "status", "partner"], lang))
    return _page(system, t("Coordinator view", lang), body, message, ok)


def public_page(system):
    rows = []
    columns = []
    for record in system.ordered():
        if record["status"] in ("rejected", "cancelled"):
            continue
        row = system._public(record)
        columns += [c for c in row if c not in columns]
        rows.append({k: _e(v) for k, v in row.items()})
    return _page(system, t("Public board", system.lang), _table(rows, columns, system.lang))


def history_page(system):
    lang = system.lang
    rows = []
    for event in reversed(system.history):
        row = {k: _e(v) for k, v in event.items()}
        row["event"] = _e(word(event["event"], lang)) if lang != "en" else row["event"]
        rows.append(row)
    return _page(system, t("History (newest first)", lang), _table(rows, ["step", "time", "event", "offer", "detail"], lang))


def make_handler(system):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, text, status=200):
            data = text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            url = urlparse(self.path)
            query = parse_qs(url.query)
            message = query.get("msg", [""])[0]
            ok = query.get("ok", ["1"])[0] == "1"
            page = url.path.rstrip("/").split("/")[-1]
            if page == "public":
                self._send(public_page(system))
            elif page == "history":
                self._send(history_page(system))
            elif page in ("", "index.html"):
                self._send(coordinator_page(system, message, ok))
            else:
                self._send(_page(system, t("Not found", system.lang), "<p>" + _e(t("No such page.", system.lang))
                                 + "</p>"), 404)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0) or 0)
            form = {k: v[0] for k, v in parse_qs(self.rfile.read(length).decode("utf-8")).items()}
            page = urlparse(self.path).path.rstrip("/").split("/")[-1]
            if page == "add":
                offer_id, errors = system.add_offer(form)
                ok, message = bool(offer_id), (t("Added {id}", system.lang, id=offer_id) if offer_id else
                                               t("Refused: {errors}", system.lang, errors=" ".join(errors)))
            elif page == "move":
                ok, message = system.move(form.get("id", ""), form.get("status", ""), form.get("partner", ""))
            else:
                ok, message = False, t("Unknown action.", system.lang)
            self.send_response(303)   # redirect, so a page refresh does not repeat the action
            self.send_header("Location", "./?ok=" + ("1" if ok else "0") + "&msg=" + quote(message))
            self.end_headers()

        def log_message(self, *args):
            return None

    return Handler


def _bind(system, port, host):
    for candidate in range(port, port + 10):
        try:
            return ThreadingHTTPServer((host, candidate), make_handler(system)), candidate
        except OSError:
            continue
    raise OSError("No free port between " + str(port) + " and " + str(port + 9))


def start_web(system=None, port=8000, host="127.0.0.1", folder=None):
    """Start the web page in the background. Running it again restarts it.

    bridge.start_web(folder="my_foodbridge")   build from your folder
    bridge.start_web(my_system)                use a System you already built
    """
    if isinstance(system, str) and folder is None:
        folder, system = system, None
    if system is None:
        from .system import System
        if folder is not None:
            saved = os.path.join(folder, "saved")
            data_dir = saved if os.path.isdir(saved) else None
            system = System.from_folder(folder, data_dir=data_dir)
            if not system.offers:
                system.run_day(show=False)
        else:
            system = System()
            system.run_day(show=False)
    stop_web()
    server, port = _bind(system, port, host)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    _running["server"], _running["thread"] = server, thread
    web_link(port, t("✅ Web page running. Click the link to open it in a new tab (stop it with bridge.stop_web())."))


def web_link(port=8000, message=None):
    """Show a link to a web page running on this computer (in Colab: a link through Colab)."""
    message = message or t("✅ Your web page:")
    try:
        from google.colab.output import eval_js   # only exists inside Google Colab
    except ImportError:
        print(message, "http://localhost:" + str(port) + "/")
        return
    url = eval_js("google.colab.kernel.proxyPort(" + str(int(port)) + ")")
    from IPython.display import HTML, display
    print(message)
    display(HTML('<a href="' + html.escape(url) + '" target="_blank">' + html.escape(t("Open the FoodBridge page ↗"))
                 + "</a>"))


def stop_web():
    """Stop the background web page if one is running."""
    server = _running["server"]
    if server is not None:
        server.shutdown()
        server.server_close()
        _running["server"] = _running["thread"] = None


def serve(system, port=8000, host="127.0.0.1"):
    """Run the web page until you press Ctrl+C (used by run_web.py)."""
    server, port = _bind(system, port, host)
    print(t("Open http://localhost:{port}/ in your browser. Press Ctrl+C to stop.", system.lang, port=port))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n" + t("Stopped.", system.lang))
    finally:
        server.server_close()
