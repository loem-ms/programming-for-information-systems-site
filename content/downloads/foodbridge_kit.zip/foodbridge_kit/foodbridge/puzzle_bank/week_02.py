"""Week 2 puzzles."""
PUZZLES = {
    "pickup_rule": {
        "title": "Build pickup_label(portions, approved)",
        "subgoal": "not approved first, then the team rule, then everything else",
        "goal": 'An offer that is not approved gets "hold". An approved offer of at least '
                'TEAM_PICKUP_MIN_PORTIONS portions gets "team". Every other offer gets "standard".',
        "lines": [
            "def pickup_label(portions, approved):",
            "    if not approved:",
            '        return "hold"',
            "    if portions >= TEAM_PICKUP_MIN_PORTIONS:",
            '        return "team"',
            '    return "standard"',
        ],
        "wrong": "    if portions > TEAM_PICKUP_MIN_PORTIONS:",
        "why": 'With > the rule leaves out the boundary itself: an approved offer of exactly 20 portions '
               '(TEAM_PICKUP_MIN_PORTIONS) gets "standard" instead of "team". "At least" means >=.',
        "done": 'Correct: hold first, so an offer nobody approved is never picked up. Then >= includes exactly '
                'TEAM_PICKUP_MIN_PORTIONS, and every other offer is "standard".',
    },
}
