"""Week 8 puzzles."""
PUZZLES = {
    "vehicle_plan": {
        "title": "Build biggest_open_first(records)",
        "subgoal": "keep the open offers, then sort a new list with a named key",
        "goal": "The team leader plans the vehicles. Keep only the open offers (status new, approved or picked_up), "
                "then return them in a new list, most portions first. The key function portions_of(record) "
                "is already written.",
        "lines": [
            "def biggest_open_first(records):",
            "    open_records = []",
            "    for record in records:",
            '        if record["status"] in ["new", "approved", "picked_up"]:',
            "            open_records.append(record)",
            "    return sorted(open_records, key=portions_of, reverse=True)",
        ],
        "wrong": "    return sorted(open_records, key=portions_of(), reverse=True)",
        "why": "With brackets, Python calls portions_of at once, with no record, and stops with a TypeError. "
               "Give sorted the function itself (key=portions_of): sorted calls it once for each record.",
        "done": "Correct: collect the open offers, then let sorted build a new list with your key function. "
                "The list you were given does not change.",
    },
}
