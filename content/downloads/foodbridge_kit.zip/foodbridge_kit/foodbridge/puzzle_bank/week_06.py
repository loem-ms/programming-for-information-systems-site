"""Week 6 puzzles."""
PUZZLES = {
    "ticket_moves": {
        "title": "Build can_change(old_status, new_status)",
        "subgoal": "look up the old status, then search its list",
        "goal": 'A bus ticket follows TICKET_MOVES = {"booked": ["paid", "cancelled"], "paid": ["used", "cancelled"], '
                '"used": [], "cancelled": []}. Return False for a status the dictionary does not know. '
                "Otherwise return True only when the new status is in the old status's list.",
        "lines": [
            "def can_change(old_status, new_status):",
            "    if old_status not in TICKET_MOVES:",
            "        return False",
            "    allowed = TICKET_MOVES[old_status]",
            "    if new_status in allowed:",
            "        return True",
            "    return False",
        ],
        "wrong": "    allowed = TICKET_MOVES[new_status]",
        "why": "That looks up the list of the NEW status, so it answers the wrong question. "
               "The old status's list says where a ticket may go next. With an unknown new status "
               "it would also stop with a KeyError.",
        "done": "Correct: refuse an unknown status first, look up the old status's list, and say True "
                "only when the new status is in it.",
    },
}
