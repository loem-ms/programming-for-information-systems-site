"""Week 5 puzzles."""
PUZZLES = {
    "portions_check": {
        "title": "Build portions_problems(text)",
        "subgoal": "convert safely, then compare",
        "goal": "Turn the text into a whole number inside try. If it is a number, compare it with "
                "MIN_PORTIONS and MAX_PORTIONS. If int() fails, add a plain message. Return the list of problems.",
        "lines": [
            "def portions_problems(text):",
            "    errors = []",
            "    try:",
            "        portions = int(text)",
            "        if portions < MIN_PORTIONS or portions > MAX_PORTIONS:",
            '            errors.append("portions must be between 1 and 200.")',
            "    except ValueError:",
            '        errors.append("portions must be a whole number.")',
            "    return errors",
        ],
        "wrong": "    except:",
        "why": "A bare except catches every error, even a typo in your own code, and hides it. "
               "Catch only the problem you expect: int() raises a ValueError.",
        "done": "Correct: convert inside try, compare only when the number exists, catch only ValueError, "
                "and return every problem in one list.",
    },
}
