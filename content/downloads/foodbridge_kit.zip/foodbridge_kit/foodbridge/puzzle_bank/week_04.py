"""Week 4 puzzles."""
PUZZLES = {
    "open_portions": {
        "title": "Build open_portions(records)",
        "subgoal": "start at zero, add only the open ones, return",
        "goal": "Add up the portions of the offers that are still open (status new, approved or picked_up). "
                "Return the total.",
        "lines": [
            "def open_portions(records):",
            "    total = 0",
            "    for record in records:",
            '        if record["status"] in ["new", "approved", "picked_up"]:',
            '            total = total + record["portions"]',
            "    return total",
        ],
        "wrong": "    print(total)",
        "why": "print shows the total on the screen but gives nothing back, so the system cannot use it. "
               "A function you can trust returns its answer.",
        "done": "Correct: start at zero, add only the open offers, and return the total after the loop.",
    },
}
