"""Week 7 puzzles."""
PUZZLES = {
    "sign_in_history": {
        "title": "Build read_sign_ins(path)",
        "subgoal": "no file: the empty list · a file: one JSON line at a time",
        "goal": "The volunteer team keeps a sign-in history as JSON Lines: one sign-in per line. "
                "Return every sign-in as a dictionary, oldest first. When there is no file yet, return the empty list.",
        "lines": [
            "def read_sign_ins(path):",
            "    sign_ins = []",
            "    if not os.path.exists(path):",
            "        return sign_ins",
            '    with open(path, encoding="utf-8") as file:',
            "        for line in file:",
            "            sign_ins.append(json.loads(line))",
            "    return sign_ins",
        ],
        "wrong": '    with open(path, "w", encoding="utf-8") as file:',
        "why": '"w" empties the file the moment it opens, so reading the history this way would erase every sign-in. '
               "To read a file, open it without a mode.",
        "done": "Correct: start with an empty list and return it when there is no file yet. Otherwise open the file "
                "to read, and turn each line into a dictionary with json.loads.",
    },
}
