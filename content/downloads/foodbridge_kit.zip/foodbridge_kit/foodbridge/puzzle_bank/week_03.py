"""Week 3 puzzles."""
PUZZLES = {
    "find_by_id": {
        "title": "Build find_offer(records, offer_id)",
        "subgoal": "check every record; give up only after the loop",
        "goal": 'Search a list of offer records for the one whose "id" is offer_id, and return that record. '
                "Return None only after you have checked every record.",
        "lines": [
            "def find_offer(records, offer_id):",
            "    for record in records:",
            '        if record["id"] == offer_id:',
            "            return record",
            "    return None",
        ],
        "wrong": "        else: return None",
        "why": "else: return None inside the loop stops after the very first record: if F001 is not the one, "
               "the function gives up and never looks at F002, F003 or F004. return None belongs after the loop.",
        "done": "Correct: return the record as soon as the IDs match. return None comes after the loop, "
                "when every record has been checked.",
    },
}
