"""More code puzzles, one file per week (week_04.py, week_05.py, …). Each file has PUZZLES = {name: puzzle}.

A puzzle is a dict with: title, subgoal, goal, lines (the answer, in order), wrong (one plausible
line that does not belong), why (why that line is wrong) and done (shown when it is solved).
"""
