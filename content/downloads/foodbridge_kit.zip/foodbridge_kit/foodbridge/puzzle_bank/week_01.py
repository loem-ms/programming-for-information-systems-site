"""Week 1 puzzles."""
PUZZLES = {
    "share_portions": {
        "title": "Share 30 portions between 4 volunteers",
        "subgoal": "text to a number, whole shares, what is left, one clear line",
        "goal": 'The offer form gives the portions as text ("30"). Turn it into a whole number, give each of the '
                "4 volunteers the same whole number of portions with //, keep what is left with %, and print "
                "one line with the units.",
        "lines": [
            'portions = int("30")',
            "volunteers = 4",
            "each = portions // volunteers",
            "left_over = portions % volunteers",
            'print(f"{each} portions each, {left_over} left over")',
        ],
        "wrong": "each = portions / volunteers",
        "why": "/ always gives a float: 30 / 4 is 7.5, and nobody can carry half a portion. "
               "// gives the whole portions (7), and % gives what is left (2).",
        "done": 'Correct: turn the text into an int first, share with // and keep the rest with %. '
                'The line says "7 portions each, 2 left over", with its units.',
    },
}
