"""Week 9 puzzles."""
PUZZLES = {
    "menu_answer": {
        "title": "Build menu_answer(choice, records)",
        "subgoal": "tidy the choice, compare it with text, return the answer",
        "goal": 'Answer one menu choice. Choice "1" returns the total portions as text. '
                "Any other choice returns a helpful message.",
        "lines": [
            "def menu_answer(choice, records):",
            "    choice = choice.strip()",
            '    if choice == "1":',
            "        total = 0",
            "        for record in records:",
            '            total = total + record["portions"]',
            '        return "Portions offered: " + str(total)',
            '    return "Please choose 1 or q."',
        ],
        "wrong": "    if choice == 1:",
        "why": 'input() always gives text. The text "1" is not the number 1, so this branch would never run, '
               "and every choice would get the help message.",
        "done": "Correct: tidy the choice first, compare it with the text \"1\", add up the portions, and return "
                "the answer as text. Any other choice falls through to the help message.",
    },
}
