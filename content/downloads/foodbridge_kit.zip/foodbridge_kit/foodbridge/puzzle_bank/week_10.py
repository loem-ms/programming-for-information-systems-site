"""Week 10 puzzles."""
PUZZLES = {
    "urgent_first_test": {
        "title": "Build test_most_urgent_first(most_urgent_first)",
        "subgoal": "make the data, call the function, compare with the contract",
        "goal": "Write a test for most_urgent_first: two records, then check that the one with the fewest "
                "hours left comes first.",
        "lines": [
            "def test_most_urgent_first(most_urgent_first):",
            '    records = [{"id": "F1", "hours_left": 9}, {"id": "F2", "hours_left": 2}]',
            "    ordered = most_urgent_first(records)",
            '    assert ordered[0]["id"] == "F2"',
        ],
        "wrong": "    assert ordered == most_urgent_first(records)",
        "why": "This compares the function with itself, so it passes even when the order is wrong. "
               "The expected answer must come from the contract (fewest hours left first), not from the code.",
        "done": "Correct: make a small list where you know the answer, call the function once, and compare the "
                "result with what the contract promises (F2, with 2 hours left, comes first).",
    },
    "save_then_load_test": {
        "title": "Build test_save_then_load()",
        "subgoal": "save, load, compare",
        "goal": "Write a test for storage.py: save one record, load the file again, and check that the same "
                "record comes back.",
        "lines": [
            "def test_save_then_load():",
            '    records = [{"id": "F1", "portions": 10}]',
            '    save_records(records, "test_offers.json")',
            '    loaded = load_records("test_offers.json")',
            "    assert loaded == records",
        ],
        "wrong": '    save_records("test_offers.json", records)',
        "why": "The inputs are in the wrong order. The contract is save_records(records, path): the records "
               "first, then the path.",
        "done": "Correct: save, load, compare. If the record comes back unchanged, your save and your load "
                "agree with each other.",
    },
}
