"""My own rules (optional).

Define a function with one of these names and the System uses it instead of
the default: pickup_label, urgency, clean_offer, can_move, public_row.
If your function crashes, the System explains why and uses the default.
"""

# Example: send a team for large OR very urgent offers.
#
# def pickup_label(portions, approved):
#     if not approved:
#         return "hold"
#     if portions >= 20:
#         return "team"
#     return "standard"
