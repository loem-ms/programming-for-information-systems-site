"""Settings: the decisions a coordinator can change without touching the code.

Change a copy, not this file: put only the names you want to change in
MY_SETTINGS (in a notebook) or in my_settings.py (in the downloaded kit).
"""
import difflib

DEFAULTS = {
    # Week 1 · how the system introduces itself (cosmetic, not a design decision)
    "SYSTEM_NAME": "Campus Food Rescue",
    # Week 2 · rules
    "TEAM_PICKUP_MIN_PORTIONS": 20,  # this many portions or more needs a team
    "URGENT_HOURS": 3,               # hours left at or below this = urgent
    "SOON_HOURS": 12,                # hours left at or below this = soon
    # Week 3 · data model
    "CATEGORIES": ["bread", "rice meals", "fruit", "vegetables", "snacks"],
    "PARTNERS": ["Hope Children's Centre", "Riverside Community Kitchen",
                 "Old Market Elders' Group"],
    # Week 5 · input checks
    "REQUIRED_FIELDS": ["donor", "food", "category", "portions", "hours_left"],
    "MIN_PORTIONS": 1,
    "MAX_PORTIONS": 200,
    "REJECT_IF_HOURS_LEFT_BELOW": 1,
    # Week 6 · workflow
    "REQUIRE_APPROVAL": True,        # a coordinator approves before pickup
    # Week 7 · history
    "LOG_EVENTS": ["added", "input_rejected", "moved"],
    # Week 8 · reports and privacy
    "PUBLIC_FIELDS": ["id", "food", "category", "portions", "status"],
    "REPORT_SORT": "urgency",        # "urgency", "portions" or "id"
    # Final · words used by the menu and web page: "en" or "km"
    "LANGUAGE": "en",
}

SORT_CHOICES = ["urgency", "portions", "id"]
LANGUAGES = ["en", "km"]


def make_settings(custom=None, quiet=False):
    """Return a complete settings dictionary: DEFAULTS plus valid changes."""
    settings = {}
    for name, value in DEFAULTS.items():
        settings[name] = list(value) if isinstance(value, list) else value
    for name, value in (custom or {}).items():
        problem = _problem(name, value)
        if problem:
            if not quiet:
                print("⚠️ Setting ignored:", problem)
            continue
        settings[name] = list(value) if isinstance(value, list) else value
    for problem in _conflicts(settings):
        if not quiet:
            print("⚠️ Setting conflict:", problem)
    return settings


def _problem(name, value):
    if name not in DEFAULTS:
        close = difflib.get_close_matches(name, list(DEFAULTS), n=1)
        hint = " Did you mean " + close[0] + "?" if close else ""
        return name + " is not a known setting." + hint
    default = DEFAULTS[name]
    if type(value) is not type(default):
        return (name + " must be " + type(default).__name__ + ", not "
                + type(value).__name__ + " (" + repr(value) + ").")
    if isinstance(value, list) and not all(isinstance(v, str) for v in value):
        return name + " must be a list of text values."
    if isinstance(value, int) and not isinstance(value, bool) and value < 0:
        return name + " cannot be negative."
    if name == "REPORT_SORT" and value not in SORT_CHOICES:
        return "REPORT_SORT must be one of " + ", ".join(SORT_CHOICES) + "."
    if name == "LANGUAGE" and value not in LANGUAGES:
        return "LANGUAGE must be one of " + ", ".join(LANGUAGES) + "."
    return None


def _conflicts(settings):
    problems = []
    if settings["SOON_HOURS"] < settings["URGENT_HOURS"]:
        problems.append("SOON_HOURS is smaller than URGENT_HOURS.")
    if settings["MIN_PORTIONS"] > settings["MAX_PORTIONS"]:
        problems.append("MIN_PORTIONS is larger than MAX_PORTIONS.")
    if not settings["CATEGORIES"] or not settings["PARTNERS"]:
        problems.append("CATEGORIES and PARTNERS need at least one value.")
    return problems


def changed_settings(settings):
    """Return {name: (default, yours)} for every setting that differs."""
    changes = {}
    for name, default in DEFAULTS.items():
        if settings.get(name) != default:
            changes[name] = (default, settings.get(name))
    return changes
