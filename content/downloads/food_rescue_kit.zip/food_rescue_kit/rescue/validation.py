"""Input checks (Week 5).

Never trust input. Check it at the door, explain every problem in plain words,
and change nothing when something is wrong.
"""
import csv

from .messages import t

TEXT_FIELDS = ["donor", "contact", "food", "category"]
NUMBER_FIELDS = ["portions", "hours_left"]


def read_offers_csv(path):
    """Return a list of raw rows. Every value in a raw row is text."""
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def to_whole_number(text):
    """Return an int, or None when the text is not a whole number."""
    try:
        return int(str(text).strip())
    except ValueError:
        return None


def clean_offer(raw, settings):
    """Return (offer, errors). offer is None whenever errors is not empty."""
    errors = []
    offer = {}
    for field in TEXT_FIELDS:
        offer[field] = str(raw.get(field, "")).strip()
    offer["category"] = offer["category"].lower()

    lang = settings.get("LANGUAGE", "en")
    required = list(settings["REQUIRED_FIELDS"])
    for field in NUMBER_FIELDS:          # numbers are always needed
        if field not in required:
            required.append(field)
    for field in required:
        if str(raw.get(field, "")).strip() == "":
            errors.append(t("{field} is required.", lang, field=field))

    portions_text = str(raw.get("portions", "")).strip()
    portions = to_whole_number(portions_text)
    low, high = settings["MIN_PORTIONS"], settings["MAX_PORTIONS"]
    if portions_text and portions is None:
        errors.append(t("portions must be a whole number, for example 12.", lang))
    elif portions is not None and not low <= portions <= high:
        errors.append(t("portions must be between {low} and {high}.", lang, low=low, high=high))

    hours_text = str(raw.get("hours_left", "")).strip()
    hours_left = to_whole_number(hours_text)
    too_late = settings["REJECT_IF_HOURS_LEFT_BELOW"]
    if hours_text and hours_left is None:
        errors.append(t("hours_left must be a whole number of hours.", lang))
    elif hours_left is not None and hours_left < too_late:
        errors.append(t("too late to collect: {hours} hours left, the minimum is {minimum}.", lang,
                        hours=hours_left, minimum=too_late))

    if offer["category"] and offer["category"] not in settings["CATEGORIES"]:
        errors.append(t("category must be one of: {categories}.", lang, categories=", ".join(settings["CATEGORIES"])))

    if errors:
        return None, errors
    offer["portions"] = portions
    offer["hours_left"] = hours_left
    return offer, []
