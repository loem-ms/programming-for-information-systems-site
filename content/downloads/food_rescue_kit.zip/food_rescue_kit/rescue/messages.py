"""Words shown to people, kept apart from the logic (Principle 9).

The code always stores English codes such as "approved". Only the words on
the screen change with the language. To add a language, add its words; no
rule has to change.

    t("Goodbye!")                       -> "Goodbye!" (or the Khmer words)
    t("{id} added", id="F001")          -> fills in the {names}
    word("picked_up")                   -> "picked up" on screens
"""
from .messages_km import KM, KM_COLUMNS, KM_WORDS

WORDS = {
    "en": {
        "new": "new", "approved": "approved", "picked_up": "picked up",
        "delivered": "delivered", "rejected": "rejected", "cancelled": "cancelled",
        "hold": "hold", "team": "team", "standard": "standard",
        "urgent": "urgent", "soon": "soon", "later": "later",
    },
    "km": KM_WORDS,
}
TEXTS = {"km": KM}
COLUMNS = {"km": KM_COLUMNS}      # table headings; English shows the field names
_STATE = {"language": "en"}


def set_language(language):
    """Choose the language of screens and checks: "en" or "km"."""
    if language not in WORDS:
        raise ValueError("language must be one of " + ", ".join(WORDS))
    _STATE["language"] = language


def current_language():
    return _STATE["language"]


def t(text, language=None, **values):
    """Return text in the chosen language, with any {names} filled in."""
    language = language or _STATE["language"]
    text = TEXTS.get(language, {}).get(text, text)
    return text.format(**values) if values else text


def word(code, language=None):
    """Return the display word for a stored code. Unknown codes are shown as they are."""
    language = language or _STATE["language"]
    return WORDS.get(language, WORDS["en"]).get(code, code)


def width(text):
    """How many columns text takes in a terminal (Khmer signs stacked under a letter take none)."""
    count, skip = 0, False
    for character in str(text):
        if skip:
            skip = False
        elif character == "្":          # COENG: the next letter is written below
            skip = True
        elif not ("ា" <= character <= "៓" or character in "​‌‍"):
            count += 1
    return count
