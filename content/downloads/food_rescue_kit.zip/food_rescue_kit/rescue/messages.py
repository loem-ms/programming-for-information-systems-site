"""Words shown to people, kept apart from the logic.

The code always stores English status codes such as "approved". Only the
words on the screen change with the LANGUAGE setting. To add a language,
add a dictionary; no rule has to change.
"""

WORDS = {
    "en": {
        "new": "new", "approved": "approved", "picked_up": "picked up",
        "delivered": "delivered", "rejected": "rejected", "cancelled": "cancelled",
        "hold": "hold", "team": "team", "standard": "standard",
        "urgent": "urgent", "soon": "soon", "later": "later",
    },
    "km": {
        "new": "ថ្មី", "approved": "បានអនុម័ត", "picked_up": "បានប្រមូល",
        "delivered": "បានប្រគល់", "rejected": "បានបដិសេធ", "cancelled": "បានលុបចោល",
        "hold": "រង់ចាំការអនុម័ត", "team": "ក្រុមបន្ថែម", "standard": "ក្រុមធម្មតា",
        "urgent": "បន្ទាន់", "soon": "ឆាប់ៗ", "later": "ពេលក្រោយ",
    },
}


def word(code, language="en"):
    """Return the display word for a stored code. Unknown codes are shown as they are."""
    return WORDS.get(language, WORDS["en"]).get(code, code)
