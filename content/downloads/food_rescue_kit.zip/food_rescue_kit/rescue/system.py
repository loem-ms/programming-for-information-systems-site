"""The System connects every part (Week 9).

Each part is a plain module. The System joins them and lets you plug in your
own version of five functions, called hooks. If your function crashes or
returns something unexpected, the System explains why and uses the default
rule, so the rest of the day keeps working.
"""
import datetime
import difflib
import inspect
import os
from functools import partial

from . import demo, models, records, reports, rules, storage, validation
from .messages import COLUMNS, t, width, word
from .settings import make_settings

HOOKS = {"pickup_label": 2, "urgency": 1, "clean_offer": 1, "can_move": 2, "public_row": 1}
ANSWERS = {"pickup_label": ["hold", "team", "standard"], "urgency": ["urgent", "soon", "later"]}


class System:
    def __init__(self, settings=None, hooks=None, data_dir=None, quiet=False):
        self.settings = make_settings(settings, quiet=quiet)
        self.defaults = self._default_hooks()
        self.hooks = dict(self.defaults)
        self.offers = []      # Offer objects
        self.history = []     # one dictionary per logged event
        self.data_dir = data_dir
        self.quiet = quiet
        self.fallbacks = {}   # hook name -> problem, when the default had to be used
        for name, function in (hooks or {}).items():
            self.use(name, function)
        if data_dir:
            self._load()
        if not self.settings["REQUIRE_APPROVAL"] and not quiet:
            print(t("⚠️ Risky setting: REQUIRE_APPROVAL is False, so food can be picked up "
                    "without a coordinator's approval. Explain why in your decision log.", self.lang))

    @property
    def lang(self):
        return self.settings["LANGUAGE"]

    def _default_hooks(self):
        s = self.settings
        return {
            "pickup_label": partial(rules.pickup_label, team_min=s["TEAM_PICKUP_MIN_PORTIONS"]),
            "urgency": partial(rules.urgency, urgent_hours=s["URGENT_HOURS"],
                               soon_hours=s["SOON_HOURS"]),
            "clean_offer": partial(validation.clean_offer, settings=s),
            "can_move": partial(models.can_move,
                                allowed=models.allowed_moves(s["REQUIRE_APPROVAL"])),
            "public_row": partial(reports.public_row, public_fields=s["PUBLIC_FIELDS"]),
        }

    # ---- hooks: your functions inside the real system ----------------------
    def use(self, name, function):
        """Plug in your own function for one hook. Return True when accepted."""
        problem = hook_problem(name, function)
        if problem:
            print(t("⚠️ Not plugged in: {problem}", problem=problem))
            return False
        self.hooks[name] = function
        return True

    def custom_hooks(self):
        return {name: f for name, f in self.hooks.items() if f is not self.defaults[name]}

    def _call(self, name, *args):
        function, default = self.hooks[name], self.defaults[name]
        if function is default:
            return default(*args)
        try:
            result = function(*args)
            problem = result_problem(name, result)
        except Exception as error:
            problem = t("it raised {error}", error=type(error).__name__ + ": " + str(error))
        if problem is None:
            return result
        if name not in self.fallbacks and not self.quiet:
            print(t("⚠️ Your {name}{args} did not work: {problem}. The system used the default rule instead.",
                    name=name, args=_show_args(args), problem=problem))
        self.fallbacks.setdefault(name, problem)
        return default(*args)

    # ---- records ----------------------------------------------------------
    def records(self):
        """Return every offer as a dictionary (copies that are safe to change)."""
        return [offer.to_record() for offer in self.offers]

    def get(self, offer_id):
        """Return the Offer with this ID, or None."""
        for offer in self.offers:
            if offer.id == offer_id:
                return offer
        return None

    def label(self, offer):
        approved = offer.status != "new" or not self.settings["REQUIRE_APPROVAL"]
        return self._call("pickup_label", offer.portions, approved)

    def urgency(self, offer):
        return self._call("urgency", offer.hours_left)

    # ---- actions ----------------------------------------------------------
    def add_offer(self, raw):
        """Check raw input and add it. Return (offer_id, []) or (None, errors)."""
        cleaned, errors = self._call("clean_offer", dict(raw))
        if errors or cleaned is None:
            errors = list(errors) or [t("the offer was not accepted.", self.lang)]
            self._log("input_rejected", "", "; ".join(errors))
            return None, errors
        offer_id = records.next_id(self.records())
        offer = models.Offer(offer_id, cleaned["donor"], cleaned["food"], cleaned["category"],
                             cleaned["portions"], cleaned["hours_left"], cleaned.get("contact", ""))
        self.offers.append(offer)
        self._log("added", offer_id, t("{portions} portions of {food}", self.lang, portions=offer.portions,
                                       food=offer.food))
        self._save()
        return offer_id, []

    def move(self, offer_id, new_status, partner="", note=""):
        """Move one offer to a new status. Return (True, message) or (False, reason)."""
        offer, lang = self.get(offer_id), self.lang
        if offer is None:
            return False, t("There is no offer with ID {id}.", lang, id=repr(offer_id))
        old_status = offer.status
        show = (lambda code: code) if lang == "en" else (lambda code: word(code, lang))
        refused = t("{id} cannot move from {old} to {new}.", lang, id=offer_id, old=show(old_status),
                    new=show(new_status))
        if not self._can_move(old_status, new_status):
            return False, refused
        needs_partner = new_status == "approved" or (new_status == "picked_up" and not offer.partner)
        if needs_partner and partner not in self.settings["PARTNERS"]:
            return False, t("Choose a partner first: {partners}.", lang, partners=", ".join(self.settings["PARTNERS"]))
        if not offer.move_to(new_status, self._can_move):
            return False, refused
        if needs_partner:
            offer.partner = partner
        detail = show(old_status) + " -> " + show(new_status)
        detail += t(" for {partner}", lang, partner=partner) if needs_partner else ""
        detail += " (" + note + ")" if note else ""
        self._log("moved", offer_id, detail)
        self._save()
        return True, offer_id + ": " + detail

    def _can_move(self, old_status, new_status):
        return self._call("can_move", old_status, new_status)

    # ---- reports ----------------------------------------------------------
    def numbers(self):
        numbers = reports.lifecycle_numbers(self.records())
        refused = [e for e in self.history if e["event"] == "input_rejected"]
        logged = "input_rejected" in self.settings["LOG_EVENTS"]
        numbers["inputs_refused"] = len(refused) if logged else "not logged"
        return numbers

    def summary_text(self):
        n = self.numbers()
        if n["inputs_refused"] == "not logged":
            n["inputs_refused"] = t("not logged", self.lang)
        return t("Offers received:        {offers}\nPortions offered:       {portions_offered}\n"
                 "Portions still open:    {portions_open}\nPortions picked up:     {portions_picked_up}\n"
                 "Portions delivered:     {portions_delivered}\n"
                 "Rejected or cancelled:  {rejected_or_cancelled}\n"
                 "Inputs refused at door: {inputs_refused}", self.lang, **n)

    def _table(self, rows, columns):
        if self.lang == "en":
            return reports.format_table(rows, columns)
        headers = {c: COLUMNS.get(self.lang, {}).get(c, c) for c in columns}
        return reports.format_table(rows, columns, headers, width, t("(nothing to show)", self.lang))

    def report(self, view="coordinator"):
        """Return a text report. view is "coordinator" or "public"."""
        lang, name = self.settings["LANGUAGE"], self.settings["SYSTEM_NAME"]
        rows = reports.sort_records(self.records(), self.settings["REPORT_SORT"])
        if view == "public":
            shown = [self._public(r) for r in rows if r["status"] not in ("rejected", "cancelled")]
            columns = []
            for row in shown:
                columns += [c for c in row if c not in columns]
            return t("{name} · public board", lang, name=name) + "\n" + self._table(shown, columns)
        table = []
        for record in rows:
            offer = self.get(record["id"])
            if offer.is_open():
                table.append({"id": offer.id, "food": offer.food, "portions": offer.portions,
                              "hours_left": offer.hours_left, "urgency": word(self.urgency(offer), lang),
                              "pickup": word(self.label(offer), lang), "status": word(offer.status, lang),
                              "partner": offer.partner, "donor": offer.donor, "contact": offer.contact})
        columns = ["id", "food", "portions", "hours_left", "urgency", "pickup", "status",
                   "partner", "donor", "contact"]
        return (t("{name} · coordinator view (open offers)", lang, name=name) + "\n" + self._table(table, columns)
                + "\n\n" + self.summary_text())

    def _public(self, record):
        row = dict(self._call("public_row", record))
        if "status" in row:
            row["status"] = word(row["status"], self.settings["LANGUAGE"])
        return row

    def history_text(self, last=12):
        lines = []
        for e in self.history[-last:]:
            event = e["event"] if self.lang == "en" else word(e["event"], self.lang)
            lines.append("#" + str(e["step"]) + " " + event + " " + e["offer"] + " " + e["detail"])
        return "\n".join(lines) if lines else t("(no events logged)", self.lang)

    # ---- the demo day and the checks live in demo.py -----------------------
    def run_day(self, show=True):
        """Replay one sample day: offers arrive, coordinators decide, food moves."""
        return demo.run_day(self, show)

    def verify(self, show=True):
        """Check the kit with default settings, then report on your own decisions."""
        return demo.verify(self, show)

    # ---- history and saving -----------------------------------------------
    def _log(self, event, offer_id, detail):
        if event not in self.settings["LOG_EVENTS"]:
            return
        entry = {"step": len(self.history) + 1, "event": event, "offer": offer_id, "detail": detail,
                 "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self.history.append(entry)
        if self.data_dir:
            storage.append_event(os.path.join(self.data_dir, "history.jsonl"), entry)

    def _save(self):
        if self.data_dir:
            os.makedirs(self.data_dir, exist_ok=True)
            storage.save_records(self.records(), os.path.join(self.data_dir, "offers.json"))

    def _load(self):
        os.makedirs(self.data_dir, exist_ok=True)
        saved = storage.load_records(os.path.join(self.data_dir, "offers.json"))
        self.offers = [models.from_record(record) for record in saved]
        self.history = storage.read_events(os.path.join(self.data_dir, "history.jsonl"))


# ---- helpers shared with check.py -----------------------------------------
def accepts(function, count):
    """Return True when function can be called with `count` positional inputs."""
    try:
        inspect.signature(function).bind(*range(count))
        return True
    except TypeError:
        return False
    except ValueError:      # some built-ins have no signature; let them try
        return True


def hook_problem(name, function):
    if name not in HOOKS:
        close = difflib.get_close_matches(name, list(HOOKS), n=1)
        hint = t(" Did you mean {close}?", close=repr(close[0])) if close else ""
        return t("{name} is not a hook. Hooks: {hooks}.", name=repr(name), hooks=", ".join(HOOKS)) + hint
    if not callable(function):
        return t("{name} must be a function. Pass its name without ( ).", name=name)
    if not accepts(function, HOOKS[name]):
        return t("your {name} must take exactly {count} input(s).", name=name, count=HOOKS[name])
    return None


def result_problem(name, result):
    """Return None when a hook's answer has the right shape, else a reason."""
    if name in ANSWERS and result not in ANSWERS[name]:
        return t("it returned {result}; expected one of {choices}", result=repr(result),
                 choices=", ".join(map(repr, ANSWERS[name])))
    if name == "can_move" and not isinstance(result, bool):
        return t("it returned {result}; expected True or False", result=repr(result))
    if name == "public_row" and not isinstance(result, dict):
        return t("it returned {result}; expected a dictionary", result=repr(result))
    if name == "clean_offer":
        if not isinstance(result, (tuple, list)) or len(result) != 2:
            return t("it should return two values: (offer, errors)")
        offer, errors = result
        if not isinstance(errors, list):
            return t("errors should be a list of messages")
        if not errors:
            if not isinstance(offer, dict):
                return t("with no errors, offer should be a dictionary")
            for field, kind in [("donor", str), ("food", str), ("category", str),
                                ("portions", int), ("hours_left", int)]:
                if not isinstance(offer.get(field), kind):
                    return t("offer[{field}] should be {kind}", field=repr(field), kind=kind.__name__)
    return None


def _show_args(args):
    text = "(" + ", ".join(repr(a) for a in args) + ")"
    return text if len(text) < 70 else text[:66] + "...)"
