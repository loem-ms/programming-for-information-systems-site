"""The Offer and its lifecycle (Week 6).

Make wrong states hard to reach: an offer changes status only through
move_to(), and only along the arrows in ALLOWED_MOVES.

    new ──> approved ──> picked_up ──> delivered
     │          │
     v          v
  rejected   cancelled
"""

ALLOWED_MOVES = {
    "new": ["approved", "rejected"],
    "approved": ["picked_up", "cancelled"],
    "picked_up": ["delivered"],
    "delivered": [],
    "rejected": [],
    "cancelled": [],
}
OPEN_STATUSES = ["new", "approved", "picked_up"]
FIELDS = ["id", "donor", "contact", "food", "category", "portions",
          "hours_left", "status", "partner"]


def allowed_moves(require_approval=True):
    """Return the lifecycle. Without approval, a new offer may be picked up directly."""
    moves = {}
    for status, targets in ALLOWED_MOVES.items():
        moves[status] = list(targets)
    if not require_approval:
        moves["new"].append("picked_up")
    return moves


def can_move(old_status, new_status, allowed=ALLOWED_MOVES):
    """Return True when the lifecycle allows old_status -> new_status."""
    return new_status in allowed.get(old_status, [])


class Offer:
    """One food offer from a donor. Change its status only with move_to()."""

    def __init__(self, offer_id, donor, food, category, portions, hours_left, contact=""):
        self.id = offer_id
        self.donor = donor
        self.contact = contact
        self.food = food
        self.category = category
        self.portions = portions
        self.hours_left = hours_left
        self.status = "new"
        self.partner = ""

    def describe(self):
        """Return one readable line about this offer."""
        return f"{self.id} · {self.food} · {self.portions} portions · {self.status}"

    def is_open(self):
        """An open offer still needs work from the team."""
        return self.status in OPEN_STATUSES

    def move_to(self, new_status, is_allowed):
        """Change status only if is_allowed(old, new) is True. Return True or False."""
        if not is_allowed(self.status, new_status):
            return False
        self.status = new_status
        return True

    def to_record(self):
        """Return a plain dictionary that can be saved as JSON (Week 7)."""
        record = {}
        for field in FIELDS:
            record[field] = getattr(self, field)
        return record


def from_record(record):
    """Build an Offer from a saved dictionary (Week 7)."""
    offer = Offer(record["id"], record["donor"], record["food"], record["category"],
                  record["portions"], record["hours_left"], record.get("contact", ""))
    offer.status = record.get("status", "new")
    offer.partner = record.get("partner", "")
    return offer
