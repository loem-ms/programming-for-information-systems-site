"""Reports (Week 8): the right information for the right person, with honest numbers.

The coordinator needs contact details to arrange a pickup. The public board
must not show them. Offered, picked up and delivered portions are different
measures, so they are reported separately and never added together.
"""


def public_row(record, public_fields):
    """Return only the fields that are safe to show to everyone."""
    row = {}
    for field in public_fields:
        row[field] = record.get(field, "")
    return row


def by_hours_left(record):
    return record["hours_left"]


def by_portions_largest_first(record):
    return -record["portions"]


def by_id(record):
    return record["id"]


SORT_KEYS = {"urgency": by_hours_left, "portions": by_portions_largest_first, "id": by_id}


def sort_records(records, how="urgency"):
    """Return a new sorted list. The original list is not changed."""
    return sorted(records, key=SORT_KEYS[how])


def lifecycle_numbers(records):
    """Count offers and portions at each stage of the lifecycle."""
    numbers = {"offers": len(records), "portions_offered": 0, "portions_open": 0,
               "portions_picked_up": 0, "portions_delivered": 0, "rejected_or_cancelled": 0}
    for record in records:
        status = record["status"]
        numbers["portions_offered"] += record["portions"]
        if status in ("new", "approved", "picked_up"):
            numbers["portions_open"] += record["portions"]
        if status in ("picked_up", "delivered"):
            numbers["portions_picked_up"] += record["portions"]
        if status == "delivered":
            numbers["portions_delivered"] += record["portions"]
        if status in ("rejected", "cancelled"):
            numbers["rejected_or_cancelled"] += 1
    return numbers


def format_table(rows, columns, headers=None, measure=len, empty="(nothing to show)"):
    """Return rows (a list of dictionaries) as a plain-text table.

    headers: optional {column: title} for another language; measure: how wide a text is.
    """
    if not rows:
        return empty
    headers = headers or {}
    titles = {column: headers.get(column, column) for column in columns}
    widths = {}
    for column in columns:
        widths[column] = measure(titles[column])
        for row in rows:
            widths[column] = max(widths[column], measure(str(row.get(column, ""))))

    def cell(text, column):
        return text + " " * (widths[column] - measure(text))
    lines = ["  ".join(cell(titles[column], column) for column in columns)]
    lines.append("  ".join("-" * widths[column] for column in columns))
    for row in rows:
        lines.append("  ".join(cell(str(row.get(column, "")), column) for column in columns))
    return "\n".join(lines)
