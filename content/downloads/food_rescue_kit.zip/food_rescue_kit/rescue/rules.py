"""Business rules (Week 2).

A rule is a small function: it takes inputs and returns one answer.
The numbers come from settings, so a coordinator can change a decision
without editing the rule.
"""


def pickup_label(portions, approved, team_min=20):
    """Return "hold", "team" or "standard" for one offer.

    An offer waits ("hold") until a coordinator approves it. An approved offer
    with at least team_min portions needs a team; smaller offers are standard.
    """
    if not approved:
        return "hold"
    if portions >= team_min:
        return "team"
    return "standard"


def urgency(hours_left, urgent_hours=3, soon_hours=12):
    """Return "urgent", "soon" or "later" from the hours left to collect."""
    if hours_left <= urgent_hours:
        return "urgent"
    if hours_left <= soon_hours:
        return "soon"
    return "later"
