"""Saving and loading (Week 7): never lose data, and keep a history.

Records are saved as JSON. The history is a JSON Lines file: one event per
line, only ever appended to, so earlier lines are never rewritten.
"""
import json
import os


def save_records(records, path):
    """Save safely: write a temporary file first, then swap it in one step.

    If the program stops halfway, the old file is still complete.
    """
    temp_path = path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=2, ensure_ascii=False)
    os.replace(temp_path, path)


def load_records(path):
    """Return the saved records, or an empty list when nothing is saved yet."""
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as file:
        return json.load(file)


def append_event(path, event):
    """Add one event to the end of the history file."""
    with open(path, "a", encoding="utf-8") as file:
        file.write(json.dumps(event, ensure_ascii=False) + "\n")


def read_events(path):
    """Return every event in the history file, oldest first."""
    if not os.path.exists(path):
        return []
    events = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            if line.strip():
                events.append(json.loads(line))
    return events
