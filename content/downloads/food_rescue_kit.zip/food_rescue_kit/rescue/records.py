"""Records (Week 3): one dictionary per offer, and one unique ID per record.

Every function here takes a list of record dictionaries, for example
{"id": "F001", "food": "Bread rolls", "category": "bread", "portions": 30, ...}
"""


def next_id(records):
    """Return the next unused ID, such as "F005". IDs are never reused."""
    highest = 0
    for record in records:
        number = int(record["id"][1:])
        if number > highest:
            highest = number
    return "F" + str(highest + 1).zfill(3)


def find_offer(records, offer_id):
    """Return the record with this ID, or None when there is no such record."""
    for record in records:
        if record["id"] == offer_id:
            return record
    return None


def total_portions(records):
    """Return the total portions in these records."""
    total = 0
    for record in records:
        total += record["portions"]
    return total


def portions_by_category(records):
    """Return {category: total portions} for these records."""
    totals = {}
    for record in records:
        category = record["category"]
        totals[category] = totals.get(category, 0) + record["portions"]
    return totals


def with_status(records, statuses):
    """Return only the records whose status is in the given list."""
    chosen = []
    for record in records:
        if record["status"] in statuses:
            chosen.append(record)
    return chosen
