"""Helpers for the Week 4 midterm (you do not need to read this file).

    offers = fr.midterm_offers()
    fr.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 15})
    fr.check("plan_day", plan_day, {"PORTIONS_PER_VOLUNTEER": 15})
    fr.catch_bugs([test_normal, test_boundary, test_waiting, test_empty])
"""
import contextlib
import io

DEFAULT_PER = 15
NAMES = ("volunteers_needed", "plan_day")


def midterm_offers():
    """Four offers for the midterm: three approved, one waiting."""
    return [{"id": "F001", "food": "Bread rolls", "portions": 30, "approved": True},
            {"id": "F002", "food": "Fried rice boxes", "portions": 18, "approved": True},
            {"id": "F003", "food": "Bananas", "portions": 40, "approved": False},
            {"id": "F004", "food": "Vegetable curry", "portions": 12, "approved": True}]


def per_problem(per):
    """Return a message when PORTIONS_PER_VOLUNTEER is not a sensible whole number."""
    if type(per) is not int or per < 1:
        return "PORTIONS_PER_VOLUNTEER must be a whole number of portions, 1 or more (you have " + repr(per) + ")."
    return None


def _need(portions, per):
    return (portions + per - 1) // per


def _case(args, show, expect, why):
    return {"args": args, "show": show, "expect": expect, "why": why}


def volunteers_cases(s):
    per = s["PORTIONS_PER_VOLUNTEER"]
    rows = [(0, 0, "no portions, no volunteers"), (1, 1, "one portion still needs a volunteer")]
    if per > 1:
        rows.append((per - 1, 1, "one below a full load"))
    rows += [(per, 1, "exactly one full load"), (per + 1, 2, "one portion more than a full load"),
             (2 * per, 2, "exactly two full loads"), (2 * per + 1, 3, "one more than two loads")]
    return [_case((n,), "volunteers_needed(" + str(n) + ")", expect, why) for n, expect, why in rows]


def plan_cases(s):
    per = s["PORTIONS_PER_VOLUNTEER"]
    offers = midterm_offers()
    full = {"offers": 4, "approved_portions": 60, "volunteers": _need(30, per) + _need(18, per) + _need(12, per),
            "waiting": ["F003"]}
    waiting = [offers[2], {"id": "F005", "food": "Mangoes", "portions": 25, "approved": False}]
    return [_case((offers,), "plan_day(4 midterm offers)", full, "approved offers only; IDs of waiting offers"),
            _case(([],), "plan_day([])", {"offers": 0, "approved_portions": 0, "volunteers": 0, "waiting": []},
                  "an empty list"),
            _case((waiting,), "plan_day(2 waiting offers)",
                  {"offers": 2, "approved_portions": 0, "volunteers": 0, "waiting": ["F003", "F005"]},
                  "nothing approved yet"),
            _case((offers,), "the list after plan_day(...)", "input unchanged",
                  "plan_day must not change the list it is given")]


@contextlib.contextmanager
def correct_volunteers(function, per):
    """While checking plan_day, use a correct volunteers_needed so one mistake is not marked twice."""
    names = getattr(function, "__globals__", {})
    had = "volunteers_needed" in names
    old = names.get("volunteers_needed")
    if had:
        names["volunteers_needed"] = lambda portions: _need(portions, per)
    try:
        yield
    finally:
        if had:
            names["volunteers_needed"] = old


# ---------------------------------------------------------------- catch_bugs

def _bug_rounds_down(names):
    def volunteers_needed(portions):
        return portions // names["PORTIONS_PER_VOLUNTEER"]
    return volunteers_needed


def _bug_one_too_many(names):
    def volunteers_needed(portions):
        return portions // names["PORTIONS_PER_VOLUNTEER"] + 1
    return volunteers_needed


def _bug_counts_waiting(names):
    def plan_day(offers):
        result = {"offers": len(offers), "approved_portions": 0, "volunteers": 0, "waiting": []}
        for offer in offers:
            result["approved_portions"] += offer["portions"]
            result["volunteers"] += names["volunteers_needed"](offer["portions"])
            if not offer["approved"]:
                result["waiting"].append(offer["id"])
        return result
    return plan_day


def _bug_empty_list(names):
    def plan_day(offers):
        if len(offers) == 0:
            return None
        result = {"offers": len(offers), "approved_portions": 0, "volunteers": 0, "waiting": []}
        for offer in offers:
            if offer["approved"]:
                result["approved_portions"] += offer["portions"]
                result["volunteers"] += names["volunteers_needed"](offer["portions"])
            else:
                result["waiting"].append(offer["id"])
        return result
    return plan_day


BUGS = [("volunteers_needed", _bug_rounds_down, "rounds down (2 full loads + 1 portion → 2 volunteers)",
         "a normal case that is not an exact multiple"),
        ("volunteers_needed", _bug_one_too_many, "one volunteer too many at an exact full load",
         "a boundary case: exactly PORTIONS_PER_VOLUNTEER portions"),
        ("plan_day", _bug_counts_waiting, "counts portions of offers that are not approved",
         "checking approved_portions when one offer is not approved"),
        ("plan_day", _bug_empty_list, "returns None for an empty list",
         "plan_day([])")]


def _run_tests(tests):
    """Run each test quietly. Return a list of (name, problem or None)."""
    results = []
    for test in tests:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                test()
            results.append((test.__name__, None))
        except AssertionError as error:
            results.append((test.__name__, "assert failed" + (": " + str(error) if str(error) else "")))
        except Exception as error:
            results.append((test.__name__, type(error).__name__ + ": " + str(error)))
    return results


@contextlib.contextmanager
def _swapped(names, name, value):
    old = names[name]
    names[name] = value
    try:
        yield
    finally:
        names[name] = old


def catch_bugs(tests):
    """Run your tests on your code, then on planted buggy versions. Return how many bugs were caught."""
    if callable(tests):
        tests = [tests]
    if not isinstance(tests, (list, tuple)) or not tests or not all(callable(t) for t in tests):
        print("❌ Give a list of your test functions without ( ), like catch_bugs([test_normal, test_empty]).")
        return 0
    names = tests[0].__globals__
    missing = [n for n in NAMES + ("PORTIONS_PER_VOLUNTEER",) if n not in names]
    if missing:
        print("❌ Run the cells that define " + ", ".join(missing) + " first.")
        return 0
    with contextlib.redirect_stdout(io.StringIO()):
        empty = [t.__name__ for t in tests if _passes_without_code(t, names)]

    print("1) Your tests on your own code")
    own = _run_tests(tests)
    for test_name, problem in own:
        print(("  ✅ " if problem is None else "  ❌ ") + test_name + ("" if problem is None else " → " + problem))
    if any(problem for _, problem in own):
        print("  💡 A failing test means the test or the function is wrong. Find out which before you go on.")
    if empty:
        print("  ⚠️ " + ", ".join(empty) + " passed even with no working code. Does it really check something?")

    print("\n2) Your tests against planted bugs")
    caught = 0
    for number, (target, make_bug, story, idea) in enumerate(BUGS, 1):
        with _swapped(names, target, make_bug(names)):
            failed = [n for n, problem in _run_tests(tests) if problem]
        caught += bool(failed)
        if failed:
            print("  🐛 Bug " + str(number) + " · " + story + ": ✅ caught by " + ", ".join(failed))
        else:
            print("  🐛 Bug " + str(number) + " · " + story + ": ❌ not caught. 💡 Try " + idea + ".")
    print("  " + str(caught) + "/" + str(len(BUGS)) + " bugs caught." + (" 🎉" if caught == len(BUGS) else ""))

    per = names["PORTIONS_PER_VOLUNTEER"]
    other = 8 if per != 8 else 10
    print("\n3) Your code and tests with a different decision (PORTIONS_PER_VOLUNTEER = " + str(other) + ")")
    with _swapped(names, "PORTIONS_PER_VOLUNTEER", other):
        broken = [n for n, problem in _run_tests(tests) if problem]
    if broken:
        print("  ⚠️ " + ", ".join(broken) + " fail(s) when the number changes. A raw number may be hidden in "
              "your function or your test. Use PORTIONS_PER_VOLUNTEER instead (see Part F).")
    else:
        print("  ✅ Your code and tests follow the constant: no hidden magic numbers.")
    return caught


def _passes_without_code(test, names):
    """True when a test passes even if both functions do nothing (it checks nothing)."""
    nothing = lambda *args: None  # noqa: E731
    with _swapped(names, "volunteers_needed", nothing), _swapped(names, "plan_day", nothing):
        try:
            test()
            return True
        except Exception:
            return False
