"""Khmer words for the screens and checks (LANGUAGE = "km").

Each key is the English text exactly as the code writes it; each value is what
Khmer screens show. {names} are filled in by the code, so keep them unchanged.
Programming words (function, return, list, dictionary, test, input, error, hook,
setting, ID ...) stay in English, as in the course.
To check that nothing is missing:  python3 tools/km_messages.py
"""

KM_WORDS = {
    "new": "ថ្មី", "approved": "បានអនុម័ត", "picked_up": "បានទៅយក",
    "delivered": "បានប្រគល់", "rejected": "បានបដិសេធ", "cancelled": "បានលុបចោល",
    "hold": "រង់ចាំការអនុម័ត", "team": "ទៅជាក្រុម", "standard": "ធម្មតា",
    "urgent": "បន្ទាន់", "soon": "ឆាប់ៗ", "later": "ពេលក្រោយ",
    "added": "បានបញ្ចូល", "input_rejected": "បដិសេធ input", "moved": "ប្ដូរស្ថានភាព",
}

KM_COLUMNS = {
    "food": "អាហារ", "category": "ប្រភេទ", "portions": "ចំណែក", "hours_left": "ម៉ោងនៅសល់",
    "hours left": "ម៉ោងនៅសល់", "urgency": "ភាពបន្ទាន់", "pickup": "របៀបទៅយក", "status": "ស្ថានភាព",
    "partner": "អង្គការដៃគូ", "donor": "អ្នកបរិច្ចាគ", "contact": "ទំនាក់ទំនង", "action": "សកម្មភាព",
    "step": "ជំហាន", "time": "ពេលវេលា", "event": "ព្រឹត្តិការណ៍", "offer": "សំណើ", "detail": "ព័ត៌មានលម្អិត",
}

KM = {
    # ---- the sample day (demo.py) ------------------------------------------
    "🌅 A day at {name}": "🌅 មួយថ្ងៃនៅ {name}",
    "1) Offers arrive (each row is checked at the door)":
        "1) សំណើផ្ដល់អាហារមកដល់ (ជួរនីមួយៗត្រូវបានពិនិត្យនៅមាត់ទ្វារ)",
    "(no food name)": "(គ្មានឈ្មោះអាហារ)",
    "{id} added: {food}, {portions} portions": "{id} បានបញ្ចូល: {food} {portions} ចំណែក",
    "refused {food}: {errors}": "បានបដិសេធ {food}: {errors}",
    "2) The coordinator decides, then volunteers move the food":
        "2) អ្នកសម្របសម្រួលសម្រេចចិត្ត បន្ទាប់មកអ្នកស្ម័គ្រចិត្តដឹកអាហារ",
    "no cold storage for fruit today": "ថ្ងៃនេះគ្មានកន្លែងទុកត្រជាក់សម្រាប់ផ្លែឈើ",
    "urgent, so it goes first": "បន្ទាន់ ដូច្នេះទៅយកមុនគេ",
    "⏭️ skipped: that offer was refused at the door with your settings":
        "⏭️ រំលង: សំណើនោះត្រូវបានបដិសេធនៅមាត់ទ្វារ ដោយសារ settings របស់អ្នក",
    "3) A mistake the system must refuse: deliver food that was never picked up":
        "3) កំហុសដែលប្រព័ន្ធត្រូវតែបដិសេធ: ប្រគល់អាហារដែលមិនទាន់បានទៅយក",
    "⚠️ accepted (this should not happen!) ": "⚠️ បានទទួលយក (មិនគួរកើតឡើងទេ!) ",
    "🛡️ refused as expected: ": "🛡️ បានបដិសេធ ដូចការរំពឹងទុក: ",
    "4) End of the day": "4) ចុងថ្ងៃ",

    # ---- verify (demo.py) -------------------------------------------------------
    "Kit checks (default settings — these must all pass)":
        "ការពិនិត្យ kit (default settings — ត្រូវតែជាប់ទាំងអស់)",
    "the sample day gives the expected numbers": "ថ្ងៃគំរូផ្ដល់លេខដូចការរំពឹងទុក",
    "food cannot be delivered before pickup": "មិនអាចប្រគល់អាហារ មុនពេលទៅយកបានទេ",
    "bad input is refused and changes nothing": "input មិនត្រឹមត្រូវត្រូវបានបដិសេធ ហើយគ្មានអ្វីប្រែប្រួល",
    "an offer cannot be approved without a partner": "មិនអាចអនុម័តសំណើ ដោយគ្មានអង្គការដៃគូបានទេ",
    "the public board hides contact details": "ក្ដារព័ត៌មានសាធារណៈលាក់ព័ត៌មានទំនាក់ទំនង",
    "saved records load back unchanged": "records ដែលបានរក្សាទុក load មកវិញដោយមិនប្រែប្រួល",
    "default settings are intact": "default settings នៅដដែល",
    "Your system (reported so you can explain it; not pass/fail)":
        "ប្រព័ន្ធរបស់អ្នក (បង្ហាញឱ្យអ្នកពន្យល់បាន មិនមែនជាប់ ឬធ្លាក់ទេ)",
    "all settings are the defaults": "settings ទាំងអស់ជា default",
    "your own {name} is plugged in": "{name} របស់អ្នកត្រូវបានភ្ជាប់ចូលប្រព័ន្ធ",
    "your sample day ran: {count} portions delivered": "ថ្ងៃគំរូរបស់អ្នកដំណើរការបាន: បានប្រគល់ {count} ចំណែក",
    "your sample day stopped: {error}": "ថ្ងៃគំរូរបស់អ្នកបានឈប់: {error}",
    "your {name} fell back to the default: {problem}": "{name} របស់អ្នកមិនដំណើរការ ប្រព័ន្ធបានប្រើ default: {problem}",
    "the public board shows {fields}: is that a deliberate decision?":
        "ក្ដារព័ត៌មានសាធារណៈបង្ហាញ {fields}: តើនេះជាការសម្រេចចិត្តដោយចេតនាឬទេ?",
    "approval is switched off: food can move without a coordinator's decision":
        "ការអនុម័តត្រូវបានបិទ: អាហារអាចផ្លាស់ទីដោយគ្មានការសម្រេចចិត្តពីអ្នកសម្របសម្រួល",
    "✅ Kit is healthy.": "✅ Kit ដំណើរការត្រឹមត្រូវ។",
    "❌ The kit itself is damaged: get a fresh notebook.": "❌ Kit ខ្លួនឯងខូច: សូមយក notebook ថ្មីមួយ។",

    # ---- the System (system.py) ---------------------------------------------------
    "⚠️ Risky setting: REQUIRE_APPROVAL is False, so food can be picked up without a coordinator's approval. "
    "Explain why in your decision log.":
        "⚠️ Setting មានហានិភ័យ: REQUIRE_APPROVAL គឺ False ដូច្នេះអាចទៅយកអាហារ ដោយគ្មានការអនុម័តពីអ្នកសម្របសម្រួល។ "
        "សូមពន្យល់មូលហេតុនៅក្នុងកំណត់ត្រាការសម្រេចចិត្ត (decision log) របស់អ្នក។",
    "⚠️ Not plugged in: {problem}": "⚠️ មិនបានភ្ជាប់ចូល: {problem}",
    "it raised {error}": "វាបាន raise {error}",
    "⚠️ Your {name}{args} did not work: {problem}. The system used the default rule instead.":
        "⚠️ {name}{args} របស់អ្នកមិនដំណើរការ: {problem}។ ប្រព័ន្ធបានប្រើវិធាន default ជំនួសវិញ។",
    "the offer was not accepted.": "សំណើមិនត្រូវបានទទួលយកទេ។",
    "{portions} portions of {food}": "{food} {portions} ចំណែក",
    "There is no offer with ID {id}.": "គ្មានសំណើដែលមាន ID {id} ទេ។",
    "{id} cannot move from {old} to {new}.": "{id} មិនអាចប្ដូរពី {old} ទៅ {new} បានទេ។",
    "Choose a partner first: {partners}.": "សូមជ្រើសរើសអង្គការដៃគូជាមុនសិន: {partners}។",
    " for {partner}": " សម្រាប់ {partner}",
    "not logged": "មិនបានកត់ត្រា",
    "Offers received:        {offers}\nPortions offered:       {portions_offered}\n"
    "Portions still open:    {portions_open}\nPortions picked up:     {portions_picked_up}\n"
    "Portions delivered:     {portions_delivered}\n"
    "Rejected or cancelled:  {rejected_or_cancelled}\n"
    "Inputs refused at door: {inputs_refused}":
        "សំណើដែលបានទទួល: {offers}\n"
        "ចំណែកដែលបានផ្ដល់: {portions_offered}\n"
        "ចំណែកដែលមិនទាន់បញ្ចប់: {portions_open}\n"
        "ចំណែកដែលបានទៅយក: {portions_picked_up}\n"
        "ចំណែកដែលបានប្រគល់: {portions_delivered}\n"
        "បានបដិសេធ ឬលុបចោល: {rejected_or_cancelled}\n"
        "Input ដែលបានបដិសេធនៅមាត់ទ្វារ: {inputs_refused}",
    "(nothing to show)": "(គ្មានអ្វីត្រូវបង្ហាញទេ)",
    "{name} · public board": "{name} · ក្ដារព័ត៌មានសាធារណៈ",
    "{name} · coordinator view (open offers)": "{name} · ទិដ្ឋភាពអ្នកសម្របសម្រួល (សំណើដែលមិនទាន់បញ្ចប់)",
    "(no events logged)": "(មិនទាន់មានព្រឹត្តិការណ៍ដែលបានកត់ត្រាទេ)",
    " Did you mean {close}?": " តើអ្នកចង់សំដៅលើ {close} ឬ?",
    "{name} is not a hook. Hooks: {hooks}.": "{name} មិនមែនជា hook ទេ។ Hooks: {hooks}។",
    "{name} must be a function. Pass its name without ( ).": "{name} ត្រូវតែជា function។ សូមផ្ដល់ឈ្មោះរបស់វា ដោយគ្មាន ( )។",
    "your {name} must take exactly {count} input(s).": "{name} របស់អ្នកត្រូវតែទទួល input ចំនួន {count} គត់។",
    "it returned {result}; expected one of {choices}": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺមួយក្នុងចំណោម {choices}",
    "it returned {result}; expected True or False": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ True ឬ False",
    "it returned {result}; expected a dictionary": "វា return {result}; តម្លៃដែលរំពឹងទុកគឺ dictionary",
    "it should return two values: (offer, errors)": "វាគួរតែ return តម្លៃពីរ: (offer, errors)",
    "errors should be a list of messages": "errors គួរតែជា list នៃសារ",
    "with no errors, offer should be a dictionary": "ពេលគ្មាន errors, offer គួរតែជា dictionary",
    "offer[{field}] should be {kind}": "offer[{field}] គួរតែជា {kind}",

    # ---- input checks (validation.py) ---------------------------------------------
    "{field} is required.": "ត្រូវតែបំពេញ {field}។",
    "portions must be a whole number, for example 12.": "portions ត្រូវតែជាចំនួនគត់ ឧទាហរណ៍ 12។",
    "portions must be between {low} and {high}.": "portions ត្រូវតែនៅចន្លោះ {low} និង {high}។",
    "hours_left must be a whole number of hours.": "hours_left ត្រូវតែជាចំនួនម៉ោងគត់។",
    "too late to collect: {hours} hours left, the minimum is {minimum}.":
        "យឺតពេកក្នុងការទៅយក: នៅសល់ {hours} ម៉ោង តែអប្បបរមាគឺ {minimum}។",
    "category must be one of: {categories}.": "category ត្រូវតែជាមួយក្នុងចំណោម: {categories}។",

    # ---- settings (settings.py) -------------------------------------------------------
    "⚠️ Setting ignored: {problem}": "⚠️ Setting មិនត្រូវបានប្រើ: {problem}",
    "⚠️ Setting conflict: {problem}": "⚠️ Settings ផ្ទុយគ្នា: {problem}",
    "{name} is not a known setting.": "{name} មិនមែនជា setting ដែលប្រព័ន្ធស្គាល់ទេ។",
    "{name} must be {expected}, not {actual} ({value}).": "{name} ត្រូវតែជា {expected} មិនមែន {actual} ({value}) ទេ។",
    "{name} must be a list of text values.": "{name} ត្រូវតែជា list នៃ text។",
    "{name} cannot be negative.": "{name} មិនអាចជាលេខអវិជ្ជមានបានទេ។",
    "REPORT_SORT must be one of {choices}.": "REPORT_SORT ត្រូវតែជាមួយក្នុងចំណោម {choices}។",
    "LANGUAGE must be one of {choices}.": "LANGUAGE ត្រូវតែជាមួយក្នុងចំណោម {choices}។",
    "SOON_HOURS is smaller than URGENT_HOURS.": "SOON_HOURS តូចជាង URGENT_HOURS។",
    "MIN_PORTIONS is larger than MAX_PORTIONS.": "MIN_PORTIONS ធំជាង MAX_PORTIONS។",
    "CATEGORIES and PARTNERS need at least one value.": "CATEGORIES និង PARTNERS ត្រូវការតម្លៃយ៉ាងហោចណាស់មួយ។",

    # ---- the text menu (menu.py) -------------------------------------------------------
    "\n1 Coordinator view   2 Public board   3 Summary   4 History\n5 Add an offer       6 Move an offer  q Quit":
        "\n1 ទិដ្ឋភាពអ្នកសម្របសម្រួល   2 ក្ដារព័ត៌មានសាធារណៈ   3 សេចក្ដីសង្ខេប   4 ប្រវត្តិ\n"
        "5 បញ្ចូលសំណើ   6 ប្ដូរស្ថានភាពសំណើ   q ចាកចេញ",
    "Goodbye!": "លាហើយ!",
    "Unknown choice {choice}. Please type 1-6 or q.": "មិនស្គាល់ជម្រើស {choice} ទេ។ សូមវាយ 1-6 ឬ q។",
    "Choose: ": "ជ្រើសរើស: ",
    "✅ Added {id}": "✅ បានបញ្ចូល {id}",
    "🚫 Refused: {errors}": "🚫 បានបដិសេធ: {errors}",
    "  offer ID (e.g. F001): ": "  ID របស់សំណើ (ឧ. F001): ",
    "  new status (approved, rejected, picked_up, delivered, cancelled): ":
        "  status ថ្មី (approved, rejected, picked_up, delivered, cancelled): ",
    "  partner ({partners}): ": "  អង្គការដៃគូ ({partners}): ",

    # ---- files, download, web page ------------------------------------------------
    "Settings changed: {settings} | Your hooks: {hooks}": "Settings ដែលបានប្ដូរ: {settings} | Hooks របស់អ្នក: {hooks}",
    "none": "គ្មាន",
    "✅ Download started: {name}": "✅ ចាប់ផ្ដើមទាញយក: {name}",
    "✅ Saved: {path}": "✅ បានរក្សាទុក: {path}",
    "On your computer: unzip it, open a terminal in food_rescue_kit, run:  python run_web.py":
        "នៅលើកុំព្យូទ័ររបស់អ្នក: unzip វា បើក terminal ក្នុង folder food_rescue_kit រួច run:  python run_web.py",
    "⚠️ Approval is switched off: food can move without a coordinator decision.":
        "⚠️ ការអនុម័តត្រូវបានបិទ: អាហារអាចផ្លាស់ទីដោយគ្មានការសម្រេចចិត្តពីអ្នកសម្របសម្រួល។",
    "Coordinator": "អ្នកសម្របសម្រួល",
    "Public board": "ក្ដារព័ត៌មានសាធារណៈ",
    "History": "ប្រវត្តិ",
    "offers": "សំណើ",
    "portions offered": "ចំណែកដែលបានផ្ដល់",
    "portions open": "ចំណែកមិនទាន់បញ្ចប់",
    "portions picked up": "ចំណែកបានទៅយក",
    "portions delivered": "ចំណែកបានប្រគល់",
    "rejected or cancelled": "បានបដិសេធ ឬលុបចោល",
    "inputs refused": "input ដែលបានបដិសេធ",
    "partner…": "អង្គការដៃគូ…",
    "Move": "ប្ដូរ",
    "Add an offer": "បញ្ចូលសំណើ",
    "Check and add": "ពិនិត្យ ហើយបញ្ចូល",
    "Open offers": "សំណើដែលមិនទាន់បញ្ចប់",
    "Finished offers": "សំណើដែលបានបញ្ចប់",
    "Coordinator view": "ទិដ្ឋភាពអ្នកសម្របសម្រួល",
    "History (newest first)": "ប្រវត្តិ (ថ្មីបំផុតនៅខាងលើ)",
    "Not found": "រកមិនឃើញ",
    "No such page.": "គ្មានទំព័រនេះទេ។",
    "Added {id}": "បានបញ្ចូល {id}",
    "Refused: {errors}": "បានបដិសេធ: {errors}",
    "Unknown action.": "សកម្មភាពដែលមិនស្គាល់។",
    "✅ Web page running. Click the link to open it in a new tab (stop it with fr.stop_web()).":
        "✅ ទំព័រ web កំពុងដំណើរការ។ ចុច link ដើម្បីបើកវាក្នុង tab ថ្មី (បញ្ឈប់វាដោយ fr.stop_web())។",
    "✅ Your web page:": "✅ ទំព័រ web របស់អ្នក:",
    "Open the Food Rescue page ↗": "បើកទំព័រ Food Rescue ↗",
    "Open http://localhost:{port}/ in your browser. Press Ctrl+C to stop.":
        "បើក http://localhost:{port}/ ក្នុង browser របស់អ្នក។ ចុច Ctrl+C ដើម្បីបញ្ឈប់។",
    "Stopped.": "បានបញ្ឈប់។",

    # ---- fr.check (check.py) ------------------------------------------------------------
    "I have no check called {name}.": "គ្មាន check ឈ្មោះ {name} ទេ។",
    "{name} must be a function. Pass its name without ( ), like check('{name}', {name}).":
        "{name} ត្រូវតែជា function។ សូមផ្ដល់ឈ្មោះរបស់វាដោយគ្មាន ( ) ដូចជា check('{name}', {name})។",
    "{name} should take {count} input(s). Check the line that starts with def.":
        "{name} គួរតែទទួល input ចំនួន {count}។ សូមពិនិត្យបន្ទាត់ដែលចាប់ផ្ដើមដោយ def។",
    "Checking {name} …": "កំពុងពិនិត្យ {name} …",
    "{passed}/{total} cases passed.": "ជាប់ {passed}/{total} ករណី។",
    "error: {error}": "error: {error}",
    "unchanged": "មិនប្រែប្រួល",
    "the list was changed": "list ត្រូវបានកែប្រែ",
    "Do not remove, add or edit offers in the list you are given. Build new values instead.":
        "កុំលុប បន្ថែម ឬកែសំណើនៅក្នុង list ដែលគេឱ្យអ្នក។ សូមបង្កើតតម្លៃថ្មីជំនួសវិញ។",
    "Volunteers are whole people. Return an int: use // and %, not /.":
        "អ្នកស្ម័គ្រចិត្តគឺជាមនុស្សទាំងមូល។ សូម return int: ប្រើ // និង % មិនមែន / ទេ។",
    "Build an Offer and copy status and partner too.": "សូមបង្កើត Offer ហើយចម្លង status និង partner ផងដែរ។",
    "Return a helpful message for unknown choices.": "សូម return សារដែលមានប្រយោជន៍ សម្រាប់ជម្រើសដែលមិនស្គាល់។",
    "Return two values: return offer, errors": "សូម return តម្លៃពីរ: return offer, errors",
    "A good row needs offer as a dict (numbers as int, text stripped, category lowercase) and errors == [].":
        "ជួរត្រឹមត្រូវត្រូវការ offer ជា dict (លេខជា int, text គ្មានដកឃ្លាខាងមុខខាងក្រោយ, category ជាអក្សរតូច) និង errors == []។",
    "offer + {count} error(s)": "offer + error {count}",
    "refused: {errors}": "បានបដិសេធ: {errors}",
    "A bad row must return None and at least one clear error message.":
        "ជួរមិនត្រឹមត្រូវត្រូវតែ return None និងសារ error ច្បាស់លាស់យ៉ាងហោចណាស់មួយ។",
    "Your function printed but returned None. Use return instead of print.":
        "function របស់អ្នកបាន print តែ return None។ សូមប្រើ return ជំនួស print។",
    "Your function returned None. Does every branch end with return?":
        "function របស់អ្នក return None។ តើគ្រប់ branch បញ្ចប់ដោយ return ឬទេ?",
    "Very close! Return exactly {expect} (same spelling, lowercase, no spaces).":
        "ជិតត្រូវហើយ! សូម return {expect} ឱ្យចំ (សរសេរដូចគ្នា អក្សរតូច គ្មានដកឃ្លា)។",
    "You returned text {result}. Expected a {kind}.": "អ្នក return text {result}។ តម្លៃដែលរំពឹងទុកគឺ {kind}។",
    "You returned text {result}. Expected a {kind}: None (no answer).":
        "អ្នក return text {result}។ តម្លៃដែលរំពឹងទុកគឺ {kind}: None (គ្មានចម្លើយ)។",
    "whole number": "ចំនួនគត់ (int)",
    "number": "លេខ",
    "list": "list",
    "dictionary": "dictionary",
    "True or False": "True ឬ False",
    "Expected keys {expected}; you returned keys {got}.": "keys ដែលរំពឹងទុកគឺ {expected}; អ្នក return keys {got}។",
    "{key} (expected {expected}, got {got})": "{key} (រំពឹងទុក {expected} តែបាន {got})",
    "Check {wrong}.": "សូមពិនិត្យ {wrong}។",
    "Expected None (no answer), for example when nothing is found.":
        "រំពឹងទុក None (គ្មានចម្លើយ) ឧទាហរណ៍ ពេលរកមិនឃើញអ្វីសោះ។",
    "Expected {value}.": "រំពឹងទុក {value}។",
    "Check the types: are you mixing text and numbers, or calling with the wrong inputs?":
        "សូមពិនិត្យប្រភេទ (type): តើអ្នកលាយ text ជាមួយលេខ ឬហៅ function ជាមួយ input ខុសឬទេ?",
    "A dictionary key is missing or misspelled. Keys are case-sensitive.":
        "key មួយក្នុង dictionary បាត់ ឬសរសេរខុស។ Keys បែងចែកអក្សរធំ និងអក្សរតូច។",
    "A name is not defined. Run the cell that defines it, or check the spelling.":
        "ឈ្មោះមួយមិនទាន់បានកំណត់ (not defined)។ សូម run cell ដែលកំណត់វា ឬពិនិត្យអក្ខរាវិរុទ្ធ។",
    "That object has no such attribute or method. Check the spelling.":
        "object នោះគ្មាន attribute ឬ method បែបនេះទេ។ សូមពិនិត្យអក្ខរាវិរុទ្ធ។",
    "A list position does not exist. Lists start at 0.": "ទីតាំងនោះមិនមាននៅក្នុង list ទេ។ List ចាប់ផ្ដើមពី 0។",

    # ---- why each case matters (check.py) ---------------------------------------
    "one below your team minimum": "ខ្វះ 1 ទៀត ទើបដល់ចំនួនអប្បបរមាសម្រាប់ក្រុមរបស់អ្នក",
    "exactly your team minimum": "ស្មើនឹងចំនួនអប្បបរមាសម្រាប់ក្រុមរបស់អ្នក",
    "one above": "លើសចំនួនអប្បបរមា 1",
    "not approved yet": "មិនទាន់អនុម័ត",
    "small and not approved": "តិច ហើយមិនទាន់អនុម័ត",
    "no time left": "គ្មានពេលនៅសល់",
    "exactly URGENT_HOURS": "ស្មើនឹង URGENT_HOURS",
    "one hour more": "លើស URGENT_HOURS 1 ម៉ោង",
    "exactly SOON_HOURS": "ស្មើនឹង SOON_HOURS",
    "beyond SOON_HOURS": "លើស SOON_HOURS",
    "the sample list": "list គំរូ",
    "an empty list": "list ទទេ",
    "an ID that exists": "ID ដែលមាន",
    "an ID that does not exist": "ID ដែលមិនមាន",
    "a correct offer": "សំណើត្រឹមត្រូវ",
    "not a whole number": "មិនមែនជាចំនួនគត់",
    "below MIN_PORTIONS": "តិចជាង MIN_PORTIONS",
    "above MAX_PORTIONS": "លើស MAX_PORTIONS",
    "too late to collect": "យឺតពេកក្នុងការទៅយក",
    "not in CATEGORIES": "មិននៅក្នុង CATEGORIES",
    "a required field is blank": "field ដែលត្រូវតែបំពេញនៅទទេ",
    "a status that does not exist": "status ដែលមិនមាន",
    "follow the lifecycle arrows": "ធ្វើតាមព្រួញនៃ lifecycle",
    "every field, same values": "គ្រប់ field តម្លៃដូចគ្នា",
    "an Offer with the same fields": "Offer ដែលមាន fields ដូចគ្នា",
    "only PUBLIC_FIELDS": "តែ PUBLIC_FIELDS ប៉ុណ្ណោះ",
    "fewest hours left first": "ម៉ោងនៅសល់តិចបំផុតមុនគេ",
    "coordinator view": "ទិដ្ឋភាពអ្នកសម្របសម្រួល",
    "public board": "ក្ដារព័ត៌មានសាធារណៈ",
    "summary": "សេចក្ដីសង្ខេប",
    "history": "ប្រវត្តិ",
    "quit": "ចាកចេញ",
    "an unknown choice": "ជម្រើសដែលមិនស្គាល់",

    # ---- the midterm (midterm.py) ---------------------------------------------------
    "PORTIONS_PER_VOLUNTEER must be a whole number of portions, 1 or more (you have {value}).":
        "PORTIONS_PER_VOLUNTEER ត្រូវតែជាចំនួនគត់នៃចំណែក ចាប់ពី 1 ឡើងទៅ (អ្នកមាន {value})។",
    "no portions, no volunteers": "គ្មានចំណែក គ្មានអ្នកស្ម័គ្រចិត្ត",
    "one portion still needs a volunteer": "ចំណែកមួយក៏ត្រូវការអ្នកស្ម័គ្រចិត្តម្នាក់ដែរ",
    "one below a full load": "ខ្វះ 1 ចំណែក ទើបពេញបន្ទុកមួយ",
    "exactly one full load": "ពេញបន្ទុកមួយគត់",
    "one portion more than a full load": "លើសបន្ទុកពេញមួយ 1 ចំណែក",
    "exactly two full loads": "ពេញបន្ទុកពីរគត់",
    "one more than two loads": "លើសបន្ទុកពេញពីរ 1 ចំណែក",
    "approved offers only; IDs of waiting offers": "តែសំណើដែលបានអនុម័ត; ID នៃសំណើដែលកំពុងរង់ចាំ",
    "nothing approved yet": "មិនទាន់មានអ្វីត្រូវបានអនុម័តទេ",
    "plan_day must not change the list it is given": "plan_day មិនត្រូវកែប្រែ list ដែលគេឱ្យវាទេ",
    "rounds down (2 full loads + 1 portion → 2 volunteers)": "បង្គត់ចុះ (បន្ទុកពេញ 2 + 1 ចំណែក → អ្នកស្ម័គ្រចិត្ត 2 នាក់)",
    "a normal case that is not an exact multiple": "ករណីធម្មតាដែលមិនមែនជាពហុគុណគត់",
    "one volunteer too many at an exact full load": "អ្នកស្ម័គ្រចិត្តលើស 1 នាក់ ពេលចំណែកពេញបន្ទុកគត់",
    "a boundary case: exactly PORTIONS_PER_VOLUNTEER portions": "ករណីព្រំដែន (boundary case): ចំណែកស្មើនឹង PORTIONS_PER_VOLUNTEER គត់",
    "counts portions of offers that are not approved": "រាប់ចំណែកនៃសំណើដែលមិនទាន់អនុម័ត",
    "checking approved_portions when one offer is not approved": "ពិនិត្យ approved_portions ពេលមានសំណើមួយមិនទាន់អនុម័ត",
    "returns None for an empty list": "return None សម្រាប់ list ទទេ",
    "plan_day([])": "plan_day([])",
    "assert failed": "assert មិនជាប់",
    "Give a list of your test functions without ( ), like catch_bugs([test_normal, test_empty]).":
        "សូមផ្ដល់ list នៃ test functions របស់អ្នក ដោយគ្មាន ( ) ដូចជា catch_bugs([test_normal, test_empty])។",
    "Run the cells that define {names} first.": "សូម run cells ដែលកំណត់ {names} ជាមុនសិន។",
    "1) Your tests on your own code": "1) tests របស់អ្នក លើ code របស់អ្នកផ្ទាល់",
    "A failing test means the test or the function is wrong. Find out which before you go on.":
        "test ដែលធ្លាក់មានន័យថា test ឬ function ខុស។ សូមរកឱ្យឃើញថាមួយណា មុននឹងបន្ត។",
    "{names} passed even with no working code. Does it really check something?":
        "{names} ជាប់ ទោះបីគ្មាន code ដែលដំណើរការក៏ដោយ។ តើវាពិតជាពិនិត្យអ្វីមួយឬទេ?",
    "2) Your tests against planted bugs": "2) tests របស់អ្នក ទល់នឹង bugs ដែលបានដាក់ទុក",
    "Bug {number} · {story}: ✅ caught by {tests}": "Bug {number} · {story}: ✅ ចាប់បានដោយ {tests}",
    "Bug {number} · {story}: ❌ not caught. 💡 Try {idea}.": "Bug {number} · {story}: ❌ មិនទាន់ចាប់បាន។ 💡 សាកល្បង {idea}។",
    "{caught}/{total} bugs caught.": "ចាប់បាន bugs {caught}/{total}។",
    "3) Your code and tests with a different decision (PORTIONS_PER_VOLUNTEER = {other})":
        "3) code និង tests របស់អ្នក ជាមួយការសម្រេចចិត្តផ្សេង (PORTIONS_PER_VOLUNTEER = {other})",
    "{names} fail(s) when the number changes. A raw number may be hidden in your function or your test. "
    "Use PORTIONS_PER_VOLUNTEER instead (see Part F).":
        "{names} ធ្លាក់ ពេលលេខប្រែប្រួល។ ប្រហែលជាមានលេខផ្ទាល់ (magic number) លាក់នៅក្នុង function ឬ test របស់អ្នក។ "
        "សូមប្រើ PORTIONS_PER_VOLUNTEER ជំនួសវិញ (មើល Part F)។",
    "Your code and tests follow the constant: no hidden magic numbers.":
        "code និង tests របស់អ្នកប្រើ constant: គ្មាន magic numbers លាក់ទុកទេ។",
}
