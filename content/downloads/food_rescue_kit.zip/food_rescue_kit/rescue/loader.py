"""Load your decisions from my_settings.py and my_rules.py (used by run_*.py)."""
import os
import runpy
import shutil

from .messages import t
from .settings import DEFAULTS
from .system import HOOKS, System

KIT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def settings_from_file(path):
    """Return {NAME: value} for every known setting written in the file."""
    if not os.path.exists(path):
        return {}
    names = runpy.run_path(path)
    return {name: value for name, value in names.items() if name.isupper() and name in DEFAULTS}


def hooks_from_file(path):
    """Return {hook name: function} for every hook function defined in the file."""
    if not os.path.exists(path):
        return {}
    names = runpy.run_path(path)
    return {name: value for name, value in names.items() if name in HOOKS and callable(value)}


def load_my_system(data_dir="saved_data", fresh=False, empty=False):
    """Build a System from your files. Saved data is kept between runs."""
    settings = settings_from_file(os.path.join(KIT_DIR, "my_settings.py"))
    hooks = hooks_from_file(os.path.join(KIT_DIR, "my_rules.py"))
    folder = os.path.join(KIT_DIR, data_dir)
    if fresh and os.path.isdir(folder):
        shutil.rmtree(folder)
    system = System(settings, hooks, data_dir=folder)
    if not system.offers and not empty:
        system.run_day(show=False)
    print(t("Settings changed: {settings} | Your hooks: {hooks}", system.lang,
            settings=", ".join(settings) or t("none", system.lang), hooks=", ".join(hooks) or t("none", system.lang)))
    return system
