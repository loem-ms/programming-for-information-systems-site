"""Package your own system as a ZIP that runs on any computer with Python 3."""
import inspect
import os
import textwrap
import zipfile

from .loader import KIT_DIR
from .settings import DEFAULTS
from .system import HOOKS

SKIP_DIRS = {"__pycache__", "saved_data", ".ipynb_checkpoints"}


def settings_file_text(settings):
    lines = ['"""My decisions. Each line changes one default in rescue/settings.py."""', ""]
    for name, value in (settings or {}).items():
        if name in DEFAULTS:
            lines.append(name + " = " + repr(value))
    if len(lines) == 2:
        lines.append("# No changes yet: the defaults are used.")
    return "\n".join(lines) + "\n"


def rules_file_text(hooks):
    lines = ['"""My own rules. The System plugs in every function here whose name is a hook."""', ""]
    constants = {}
    sources = []
    for name, function in (hooks or {}).items():
        if name not in HOOKS:
            continue
        try:
            source = textwrap.dedent(inspect.getsource(function))
        except (OSError, TypeError):
            sources.append("# Could not copy the source of " + name + ". Paste it here by hand.\n")
            continue
        if function.__name__ != name:
            source += "\n" + name + " = " + function.__name__ + "\n"
        sources.append(source)
        for used in function.__code__.co_names:          # constants your function reads
            value = function.__globals__.get(used)
            if used.isupper() and isinstance(value, (int, float, str, bool, list, dict, tuple)):
                constants[used] = value
    for name, value in constants.items():
        lines.append(name + " = " + repr(value))
    if constants:
        lines.append("")
    lines += sources or ["# No hooks yet: the default rules are used."]
    return "\n".join(lines) + "\n"


def make_zip(settings=None, hooks=None, filename="my_food_rescue.zip"):
    """Write the ZIP next to the notebook and return its path."""
    path = os.path.abspath(filename)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for folder, dirs, files in os.walk(KIT_DIR):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            for name in sorted(files):
                full = os.path.join(folder, name)
                relative = os.path.relpath(full, KIT_DIR)
                if relative in ("my_settings.py", "my_rules.py") or name.endswith((".pyc", ".tmp")):
                    continue
                archive.write(full, os.path.join("food_rescue_kit", relative))
        archive.writestr("food_rescue_kit/my_settings.py", settings_file_text(settings))
        archive.writestr("food_rescue_kit/my_rules.py", rules_file_text(hooks))
    return path


def download_my_system(settings=None, hooks=None, filename="my_food_rescue.zip"):
    """Make the ZIP; in Colab, also start the download."""
    path = make_zip(settings, hooks, filename)
    try:
        from google.colab import files     # only exists inside Google Colab
        files.download(path)
        print("✅ Download started:", os.path.basename(path))
    except ImportError:
        print("✅ Saved:", path)
    print("On your computer: unzip it, open a terminal in food_rescue_kit, run:  python run_web.py")
    return path
