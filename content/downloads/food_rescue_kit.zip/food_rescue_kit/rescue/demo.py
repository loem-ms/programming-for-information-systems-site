"""The sample day and the system checks (you do not need to read this file).

run_day replays one fictional day. verify checks the kit itself with the
default settings (this must always pass), then reports on your decisions.
"""
import contextlib
import io
import os
import tempfile

from . import models, storage, validation
from .messages import t
from .settings import DEFAULTS, changed_settings

SAMPLE_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "offers.csv")
# The expected day with DEFAULT settings (used by verify).
EXPECTED = {"offers": 4, "portions_offered": 100, "portions_open": 42, "portions_picked_up": 48,
            "portions_delivered": 18, "rejected_or_cancelled": 1, "inputs_refused": 5}


def run_day(system, show=True):
    say = print if show else _silent
    name, lang = system.settings["SYSTEM_NAME"], system.settings["LANGUAGE"]
    partners = system.settings["PARTNERS"]
    say(t("🌅 A day at {name}", lang, name=name))
    say("\n" + t("1) Offers arrive (each row is checked at the door)", lang))
    ids = []
    for row in validation.read_offers_csv(SAMPLE_CSV):
        offer_id, errors = system.add_offer(row)
        ids.append(offer_id)
        food = row.get("food") or t("(no food name)", lang)
        if offer_id:
            say("   ✅ " + t("{id} added: {food}, {portions} portions", lang, id=offer_id, food=food,
                             portions=row["portions"]))
        else:
            say("   🚫 " + t("refused {food}: {errors}", lang, food=food, errors=" ".join(errors)))
    say("\n" + t("2) The coordinator decides, then volunteers move the food", lang))
    steps = [(1, "approved", partners[1 % len(partners)], ""),
             (0, "approved", partners[0], ""),
             (2, "rejected", "", "no cold storage for fruit today"),
             (3, "approved", partners[2 % len(partners)], ""),
             (1, "picked_up", "", "urgent, so it goes first"),
             (1, "delivered", "", ""),
             (0, "picked_up", "", "")]
    for row_number, status, partner, note in steps:
        offer_id = ids[row_number] if row_number < len(ids) else None
        if offer_id is None:
            say("   " + t("⏭️ skipped: that offer was refused at the door with your settings", lang))
            continue
        ok, message = system.move(offer_id, status, partner, t(note, lang) if note else "")
        say(("   ✅ " if ok else "   ⚠️ ") + message)
    if ids[3]:
        say("\n" + t("3) A mistake the system must refuse: deliver food that was never picked up", lang))
        ok, message = system.move(ids[3], "delivered")
        say("   " + (t("⚠️ accepted (this should not happen!) ", lang) if ok else
                     t("🛡️ refused as expected: ", lang)) + message)
    say("\n" + t("4) End of the day", lang) + "\n" + system.summary_text())
    return system.numbers()


def verify(system, show=True):
    say = print if show else _silent
    lang = system.settings["LANGUAGE"]
    say(t("Kit checks (default settings — these must all pass)", lang))
    results = _kit_checks()
    for passed, text in results:
        say(("  ✅ " if passed else "  ❌ ") + t(text, lang))
    kit_ok = all(passed for passed, _ in results)
    say("\n" + t("Your system (reported so you can explain it; not pass/fail)", lang))
    changes = changed_settings(system.settings)
    for name, (default, yours) in changes.items():
        say("  • " + name + ": " + repr(default) + " → " + repr(yours))
    if not changes:
        say("  • " + t("all settings are the defaults", lang))
    for name in system.custom_hooks():
        say("  • " + t("your own {name} is plugged in", lang, name=name))
    trial = type(system)(system.settings, system.custom_hooks(), quiet=True)
    try:
        with contextlib.redirect_stdout(io.StringIO()):   # keep your print() calls out of the report
            numbers = run_day(trial, show=False)
            trial.report("coordinator")
            trial.report("public")
        say("  • " + t("your sample day ran: {count} portions delivered", lang,
                       count=numbers["portions_delivered"]))
    except Exception as error:   # report, never crash the notebook
        say("  ⚠️ " + t("your sample day stopped: {error}", lang,
                        error=type(error).__name__ + ": " + str(error)))
    for name, problem in trial.fallbacks.items():
        say("  ⚠️ " + t("your {name} fell back to the default: {problem}", lang, name=name, problem=problem))
    private = [f for f in ("contact", "donor") if f in system.settings["PUBLIC_FIELDS"]]
    if private:
        say("  ⚠️ " + t("the public board shows {fields}: is that a deliberate decision?", lang,
                        fields=", ".join(private)))
    if not system.settings["REQUIRE_APPROVAL"]:
        say("  ⚠️ " + t("approval is switched off: food can move without a coordinator's decision", lang))
    say("\n" + (t("✅ Kit is healthy.", lang) if kit_ok else
                t("❌ The kit itself is damaged: get a fresh notebook.", lang)))
    return kit_ok


def _kit_checks():
    from .system import System
    s = System(quiet=True)
    numbers = run_day(s, show=False)
    results = [(numbers == EXPECTED, "the sample day gives the expected numbers")]
    before = s.records()
    ok, _ = s.move("F004", "delivered")
    results.append((not ok and s.records() == before, "food cannot be delivered before pickup"))
    offer_id, errors = s.add_offer({"donor": "Test", "food": "Rice", "category": "rice meals",
                                    "portions": "lots", "hours_left": "5"})
    results.append((offer_id is None and errors and s.records() == before,
                    "bad input is refused and changes nothing"))
    s.add_offer({"donor": "Test", "food": "Rice", "category": "rice meals", "portions": "5",
                 "hours_left": "5"})
    ok, _ = s.move("F005", "approved")
    results.append((not ok, "an offer cannot be approved without a partner"))
    contacts = [r["contact"] for r in s.records() if r["contact"]]
    public = s.report("public")
    results.append((not any(c in public for c in contacts), "the public board hides contact details"))
    with tempfile.TemporaryDirectory() as folder:
        path = os.path.join(folder, "offers.json")
        storage.save_records(s.records(), path)
        loaded = [models.from_record(r).to_record() for r in storage.load_records(path)]
        results.append((loaded == s.records(), "saved records load back unchanged"))
    results.append((DEFAULTS["TEAM_PICKUP_MIN_PORTIONS"] == 20, "default settings are intact"))
    return results


def _silent(*args):
    return None
