"""A text menu (Week 8).

The loop asks a question; handle_choice decides what to show. Keeping the
decision in its own function means it can be tested without typing.
"""

MENU = ("\n1 Coordinator view   2 Public board   3 Summary   4 History\n"
        "5 Add an offer       6 Move an offer  q Quit")
OFFER_FIELDS = ["donor", "contact", "food", "category", "portions", "hours_left"]


def handle_choice(choice, system):
    """Return the text to show for one menu choice (1-4, q or anything else)."""
    choice = choice.strip().lower()
    if choice == "1":
        return system.report("coordinator")
    if choice == "2":
        return system.report("public")
    if choice == "3":
        return system.summary_text()
    if choice == "4":
        return system.history_text()
    if choice == "q":
        return "Goodbye!"
    return "Unknown choice " + repr(choice) + ". Please type 1-6 or q."


def run_menu(system=None, script=None, handle=handle_choice):
    """Run the menu. script is an optional list of answers used instead of typing."""
    if system is None:
        from .system import System
        system = System()
    answers = None if script is None else list(script)

    def ask(prompt):
        if answers is None:
            return input(prompt)
        answer = answers.pop(0) if answers else "q"
        print(prompt + answer)
        return answer

    while True:
        print(MENU)
        choice = ask("Choose: ").strip().lower()
        if choice == "5":
            raw = {field: ask("  " + field + ": ") for field in OFFER_FIELDS}
            offer_id, errors = system.add_offer(raw)
            print("✅ Added " + offer_id if offer_id else "🚫 Refused: " + " ".join(errors))
        elif choice == "6":
            offer_id = ask("  offer ID (e.g. F001): ").strip().upper()
            status = ask("  new status (approved, rejected, picked_up, delivered, cancelled): ").strip()
            partner = ""
            if status in ("approved", "picked_up"):
                partner = ask("  partner (" + " / ".join(system.settings["PARTNERS"]) + "): ").strip()
            ok, message = system.move(offer_id, status, partner)
            print(("✅ " if ok else "🚫 ") + message)
        else:
            print(handle(choice, system))
        if choice == "q":
            return system
