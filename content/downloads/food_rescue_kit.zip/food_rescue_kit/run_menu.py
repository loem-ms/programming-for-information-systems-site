"""Use your Food Rescue system from a text menu in the terminal.

    python run_menu.py           # keeps your saved data between runs
    python run_menu.py --fresh   # forget saved data and replay the sample day
"""
import sys

from rescue.loader import load_my_system
from rescue.menu import run_menu


def main():
    system = load_my_system(fresh="--fresh" in sys.argv, empty="--empty" in sys.argv)
    run_menu(system)


if __name__ == "__main__":
    main()
