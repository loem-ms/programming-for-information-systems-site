"""Tests for the Food Rescue kit. Run them all with:  python run_tests.py

Each test checks one behaviour with assert. Normal cases, boundary cases
and refusals are all tested, because a system is only as trustworthy as
its worst case.
"""
import os
import tempfile

import rescue as fr
from rescue import models, records, reports, rules, storage, validation


def test_pickup_label_boundaries():
    assert rules.pickup_label(19, True) == "standard"
    assert rules.pickup_label(20, True) == "team"
    assert rules.pickup_label(21, True) == "team"
    assert rules.pickup_label(20, False) == "hold"


def test_urgency_boundaries():
    assert rules.urgency(3) == "urgent"
    assert rules.urgency(4) == "soon"
    assert rules.urgency(12) == "soon"
    assert rules.urgency(13) == "later"


def test_records_helpers():
    sample = fr.sample_records()
    assert records.total_portions(sample) == 100
    assert records.find_offer(sample, "F003")["food"] == "Bananas"
    assert records.find_offer(sample, "F999") is None
    assert records.next_id(sample) == "F005"
    assert records.next_id([]) == "F001"
    assert records.portions_by_category(sample)["rice meals"] == 30


def test_clean_offer_accepts_and_tidies_a_good_row():
    raw = {"donor": " Sunrise Bakery ", "food": "Bread", "category": "Bread ",
           "portions": " 30", "hours_left": "5"}
    offer, errors = validation.clean_offer(raw, fr.make_settings())
    assert errors == []
    assert offer["donor"] == "Sunrise Bakery"
    assert offer["category"] == "bread"
    assert offer["portions"] == 30


def test_clean_offer_refuses_bad_rows_with_messages():
    settings = fr.make_settings()
    good = {"donor": "A", "food": "B", "category": "bread", "portions": "5", "hours_left": "5"}
    for field, value in [("portions", "many"), ("portions", "0"), ("portions", "201"),
                         ("hours_left", "0"), ("category", "soup"), ("donor", " ")]:
        row = dict(good)
        row[field] = value
        offer, errors = validation.clean_offer(row, settings)
        assert offer is None and errors, (field, value)


def test_lifecycle_moves():
    assert models.can_move("new", "approved")
    assert not models.can_move("new", "delivered")
    assert not models.can_move("delivered", "new")
    assert models.can_move("new", "picked_up", models.allowed_moves(False))


def test_record_round_trip():
    offer = models.Offer("F001", "Donor", "Rice", "rice meals", 10, 4, "x@example.org")
    offer.status, offer.partner = "approved", "Hope Children's Centre"
    again = models.from_record(offer.to_record())
    assert again.to_record() == offer.to_record()


def test_safe_save_and_history():
    with tempfile.TemporaryDirectory() as folder:
        path = os.path.join(folder, "offers.json")
        storage.save_records([{"id": "F001"}], path)
        assert storage.load_records(path) == [{"id": "F001"}]
        assert not os.path.exists(path + ".tmp")
        log = os.path.join(folder, "history.jsonl")
        storage.append_event(log, {"step": 1})
        storage.append_event(log, {"step": 2})
        assert [e["step"] for e in storage.read_events(log)] == [1, 2]


def test_sample_day_numbers():
    system = fr.System(quiet=True)
    numbers = system.run_day(show=False)
    assert numbers["portions_offered"] == 100
    assert numbers["portions_delivered"] == 18
    assert numbers["inputs_refused"] == 5


def test_refusals_change_nothing():
    system = fr.System(quiet=True)
    system.run_day(show=False)
    before = system.records()
    assert system.move("F004", "delivered")[0] is False
    assert system.move("F999", "approved")[0] is False
    assert system.add_offer({"donor": "X", "food": "Y", "category": "bread",
                             "portions": "-3", "hours_left": "4"})[0] is None
    assert system.records() == before


def test_public_board_hides_contacts():
    system = fr.System(quiet=True)
    system.run_day(show=False)
    public = system.report("public")
    assert "@example.org" not in public
    assert "@example.org" in system.report("coordinator")


def test_broken_hook_falls_back_to_default():
    def broken(portions, approved):
        return portions / 0
    system = fr.System(hooks={"pickup_label": broken}, quiet=True)
    system.run_day(show=False)
    report = system.report()
    assert "pickup_label" in system.fallbacks
    assert "team" in report and "ZeroDivisionError" in system.fallbacks["pickup_label"]


def test_custom_settings_change_the_rule():
    system = fr.System({"TEAM_PICKUP_MIN_PORTIONS": 35}, quiet=True)
    system.run_day(show=False)
    assert system.label(system.get("F001")) == "standard"


def test_persistence_between_runs():
    with tempfile.TemporaryDirectory() as folder:
        first = fr.System(data_dir=folder, quiet=True)
        first.run_day(show=False)
        second = fr.System(data_dir=folder, quiet=True)
        assert second.records() == first.records()
        assert len(second.history) == len(first.history)


def test_text_menu_with_script():
    system = fr.System(quiet=True)
    system.run_day(show=False)
    fr.run_menu(system, script=["6", "F004", "picked_up", "", "q"])
    assert system.get("F004").status == "picked_up"


def test_kit_verify_passes():
    assert fr.System(quiet=True).verify(show=False) is True


def test_report_sorting():
    sample = fr.sample_records()
    assert [r["id"] for r in reports.sort_records(sample, "urgency")] == ["F002", "F004", "F001", "F003"]
    assert [r["id"] for r in reports.sort_records(sample, "portions")][0] == "F003"


def test_midterm_checks_follow_the_constant():
    def volunteers_needed(portions):
        return (portions + 9) // 10
    assert fr.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 10})
    assert not fr.check("volunteers_needed", volunteers_needed, {"PORTIONS_PER_VOLUNTEER": 15})


def test_midterm_catch_bugs_counts_caught_bugs():
    namespace = {"PORTIONS_PER_VOLUNTEER": 15}
    code = (
        "def volunteers_needed(portions):\n"
        "    return (portions + PORTIONS_PER_VOLUNTEER - 1) // PORTIONS_PER_VOLUNTEER\n"
        "def plan_day(offers):\n"
        "    approved = [o for o in offers if o['approved']]\n"
        "    return {'offers': len(offers), 'approved_portions': sum(o['portions'] for o in approved),\n"
        "            'volunteers': sum(volunteers_needed(o['portions']) for o in approved),\n"
        "            'waiting': [o['id'] for o in offers if not o['approved']]}\n"
        "def test_boundary():\n"
        "    assert volunteers_needed(PORTIONS_PER_VOLUNTEER) == 1\n"
        "    assert volunteers_needed(PORTIONS_PER_VOLUNTEER + 1) == 2\n"
        "def test_nothing():\n"
        "    pass\n")
    exec(code, namespace)
    assert fr.check("plan_day", namespace["plan_day"])
    assert fr.catch_bugs([namespace["test_boundary"]]) == 2
    assert fr.catch_bugs([namespace["test_nothing"]]) == 0


BONUS_WORDS = ["old"]


def _mentions_old(food):
    return any(word in food.lower() for word in BONUS_WORDS)


def _strict_clean_offer(raw):
    offer, errors = validation.clean_offer(raw, fr.make_settings({}, quiet=True))
    if _mentions_old(raw.get("food", "")):
        errors.append("old food")
    return (None if errors else offer), errors


def test_export_copies_helpers_constants_and_imports():
    text = fr.export.rules_file_text({"clean_offer": _strict_clean_offer})
    assert "def _mentions_old(food):" in text
    assert "BONUS_WORDS = ['old']" in text
    assert "from rescue import validation" in text
    namespace = {}
    exec(text, namespace)
    offer, errors = namespace["clean_offer"]({"donor": "A", "contact": "a@x.org", "food": "Old bread",
                                              "category": "bread", "portions": "10", "hours_left": "5"})
    assert offer is None and errors == ["old food"]
