# Campus Food Rescue — your own system

A small information system for a fictional university volunteer team. Donors offer surplus food. A coordinator checks each offer and approves it for a community partner. Volunteers pick it up and deliver it. All organisations, people and numbers are invented.

You built each part of this system during the course. This folder contains the whole system, with your decisions in two files.

## Run it on your own computer

You need Python 3.9 or newer. Nothing else needs to be installed.

1. Unzip the folder and open a terminal **inside** `food_rescue_kit`.
2. Start the web page:

   ```
   python run_web.py
   ```

   Open <http://localhost:8000> in your browser. Press `Ctrl+C` in the terminal to stop.
   On some computers the command is `python3` or `py -3`.

Other commands:

| Command | What it does |
|---|---|
| `python run_menu.py` | Use the same system from a text menu |
| `python run_tests.py` | Run every test and print ✅ or ❌ |
| `python run_web.py --fresh` | Forget saved data and replay the sample day |
| `python run_web.py --empty` | Start with no offers |

Your data is saved in `saved_data/` between runs, with a history of every change.

## Run it in Google Colab's terminal (optional)

1. In Colab, open **Files** and upload the ZIP.
2. Open the **Terminal** and run:

   ```
   unzip my_food_rescue.zip && cd food_rescue_kit && python run_web.py
   ```

3. In a notebook cell, run:

   ```python
   from google.colab import output
   output.serve_kernel_port_as_window(8000)
   ```

   Click the link it prints. The page opens in a new tab and only you can see it.

## Where your decisions live

| File | What to change |
|---|---|
| `my_settings.py` | Values: team minimum, urgency hours, categories, partners, input limits, approval, history, public fields, sort order, language |
| `my_rules.py` | Optional functions that replace a default rule: `pickup_label`, `urgency`, `clean_offer`, `can_move`, `public_row` |

Do not edit the `rescue/` folder unless you are extending the system. If one of your functions crashes, the system explains why and uses the default rule.

## Map of the parts

| File in `rescue/` | Week | Job |
|---|---|---|
| `rules.py` | 2 | Pickup label and urgency |
| `records.py` | 3 | Records, IDs, totals |
| `validation.py` | 5 | Check input at the door |
| `models.py` | 6 | The Offer and its lifecycle |
| `storage.py` | 7 | Save safely, keep history |
| `reports.py`, `menu.py` | 8 | Views for different people |
| `system.py` | 9 | Connect the parts, plug in your hooks |
| `settings.py` | 2–9 | Default decisions |
| `web.py`, `demo.py`, `check.py`, `export.py`, `loader.py` | — | Supplied helpers (you do not need to read them) |
