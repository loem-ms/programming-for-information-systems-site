"""Run every test function in tests/ and print ✅ or ❌ for each one.

    python run_tests.py

A test is a function whose name starts with test_ and that uses assert.
This is the same idea you practised in Week 4, run from a fresh process.
"""
import contextlib
import io
import os
import runpy
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    sys.path.insert(0, HERE)
    folder = os.path.join(HERE, "tests")
    passed = failed = 0
    for filename in sorted(os.listdir(folder)):
        if not (filename.startswith("test_") and filename.endswith(".py")):
            continue
        names = runpy.run_path(os.path.join(folder, filename))
        for name, function in names.items():
            if not (name.startswith("test_") and callable(function)):
                continue
            printed = io.StringIO()
            try:
                with contextlib.redirect_stdout(printed):   # keep the output short; show it only on failure
                    function()
                passed += 1
                print("✅", filename, name)
            except Exception:
                failed += 1
                print("❌", filename, name)
                print("   " + traceback.format_exc().strip().splitlines()[-1])
                if printed.getvalue().strip():
                    print("   printed: " + printed.getvalue().strip().replace("\n", "\n   "))
    print(f"\n{passed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
